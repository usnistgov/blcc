package blcc.parser;

import blcc.util.*;
import blcc.analysis.Category;
import blcc.model.ModelElement;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import org.w3c.dom.*;
import org.xml.sax.Parser;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.ParserFactory;
import com.ibm.xml.parsers.DOMParser;
import java.text.ParseException;

public class XMLParser {
  static String DEFAULT_PARSER="com.ibm.xml.parsers.DOMParser";
  Parser parser;
  static String packages[]={"blcc.model","blcc.util"};
  Hashtable nodes=new Hashtable();
  Hashtable ids = new Hashtable();

  public XMLParser(String uri)  throws Exception {
    parser = ParserFactory.makeParser(DEFAULT_PARSER);
    parser.parse(uri);
  }

  public XMLParser(InputStream stream) throws Exception {
    parser = ParserFactory.makeParser(DEFAULT_PARSER);
    parser.parse(new InputSource(stream));
  }

  public Object parse() throws Exception {
    return parseNode(null,contents(((DOMParser)parser).getDocument()),null); }

  public Object parse(Object owner, String tag) throws ParseException {
    return parse(owner,tag,null); }

  public Object parse(Object owner, String tag, Object def)
   throws ParseException {
    return parseNode(owner,getContent(owner,tag),def); }

  public Object parseNext(Object owner, Enumeration enum1)
    throws ParseException{
    return parseNode(owner,(Node) enum1.nextElement(),null); }

  Object parseNode(Object owner, Node node, Object def) throws ParseException {
    String id="";
    String idref="";

    if (node == null) return def;
    if(!(node instanceof Element))
      throw new ParseException("Expected a container but got "
			       +nodepath(node),0);
    Element el = (Element) node;

    idref=el.getAttribute("IDREF");
    if(!idref.equals(""))
     return ids.get(idref);

    String tag = el.getTagName();
    Class c=null;
    for(int i=0; (c==null) && (i<packages.length); i++){
      try { c=Class.forName(packages[i]+"."+tag);
      } catch(Exception e){}}
    if (c == null)
      throw new ParseException("Cannot find class for tag "+tag+nodepath(el),0);
    XMLIO ob;
    try { ob= (XMLIO) c.newInstance();
    } catch(Exception e){
      System.out.println("Error creating Instance "+tag+nodepath(el));
      e.printStackTrace();
      throw new ParseException("Cannot create instance for "+tag+nodepath(el),0); }
    if((owner != null) && (owner instanceof ModelElement) &&
       (ob instanceof ModelElement))
      ((ModelElement)ob).setOwner((ModelElement) owner);

    prepNode(ob,el);
    ob.parseXMLFields(this);
    finishNode(ob);

    id=el.getAttribute("ID");
    if(!id.equals(""))
     ids.put(id,ob);
    return ob; }

  public void prepNode(Object key, Node node){
    Hashtable table = new Hashtable();
    nodes.put(key,table);
    for(Enumeration e=children(node); e.hasMoreElements(); ){
      Element child= (Element)e.nextElement();
      table.put(child.getTagName(),child); }
  }

  public void finishNode(Object key) throws ParseException {
    Hashtable table = (Hashtable) nodes.get(key);
    if(table == null)
      throw new ParseException("INTERNAL: Object "+key+" is not being parsed!",0);
    if(!table.isEmpty()){
      String keys="";
      for(Enumeration e=table.keys(); e.hasMoreElements(); )
	keys += ((String) e.nextElement())+"; ";
      throw new ParseException("Unrecognized elements: "+keys,0); }
    nodes.remove(key);
    }

  public Node getContent(Object key, String tag) throws ParseException {
    Hashtable table = (Hashtable) nodes.get(key);
    Node node = (Node) table.get(tag);
    table.remove(tag);
    return (node == null ? null : contents(node)); }

  public Enumeration getContents(Object key, String tag) throws ParseException {
    Hashtable table = (Hashtable) nodes.get(key);
    Node node = (Node) table.get(tag);
    table.remove(tag);
    return children(node); }

  /* ______________________________________________________________________
     Parsers for Primitives. */

  String getString(Node node) throws ParseException{
    if(node == null) return null;
    if(node.getNodeType() != Node.TEXT_NODE)
      throw new ParseException("Content is not a TEXT_NODE!"+nodepath(node),0);
    return node.getNodeValue(); }


  public String parseString(Object owner, String tag, String def)
    throws ParseException{
   Node node = getContent(owner, tag);
   return (node==null ? def : getString(node)); }

  public String[] parseStrings(Object owner, String tag, String def[])
    throws ParseException{
   Node node = getContent(owner, tag);
   if (node==null) return def;
    Vector v = splitNode(node);
    String s[] = new String[v.size()];
    for(int i=0; i<s.length; i++)
      s[i]=(String)v.elementAt(i);
    return s; }

 public int parseInt(Object owner, String tag, int def) throws ParseException{
   Node node = getContent(owner, tag);
   return (node==null ? def : Integer.parseInt(getString(node))); }

 public double parseDouble(Object owner, String tag, double def)
   throws ParseException{
   Node node = getContent(owner, tag);
   return (node==null ? def : Double.parseDouble(getString(node))); }

 Vector splitNode(Node node) throws ParseException {
    String string = getString(node);
    Vector v = new Vector();
    string=string.trim();
    while(!string.equals("")){
      int p = string.indexOf(',');
      if (p == -1){
	v.addElement(string);
	string = ""; }
      else {
	v.addElement(string.substring(0,p));
	string = string.substring(p+1);
	string=string.trim(); }}
    return v; }

  public double[] parseDoubles(Object owner, String tag, double def[])
    throws ParseException{
   Node node = getContent(owner, tag);
   if (node==null) return def;
    Vector v = splitNode(node);
    double d[] = new double[v.size()];
    for(int i=0; i<d.length; i++)
      d[i]=Double.parseDouble((String)v.elementAt(i));
    return d; }

  public Date parseDate(Object owner, String tag, Date def)
    throws ParseException{
    Node node = getContent(owner, tag);
    return (node == null ? def : Date.valueOf(getString(node))); }

  public DateDiff parseDateDiff(Object owner, String tag, DateDiff def)
    throws ParseException{
    Node node = getContent(owner, tag);
    return (node == null ? def : DateDiff.valueOf(getString(node))); }

  public DateDiff[] parseDateDiffs(Object owner, String tag, DateDiff def[])
    throws ParseException {
    Node node = getContent(owner, tag);
    if (node==null) return def;
    Vector v = splitNode(node);
    DateDiff d[] = new DateDiff[v.size()];
    for(int i=0; i<d.length; i++)
      d[i]=DateDiff.valueOf((String)v.elementAt(i));
    return d; }

  /** Hashtable keys are strings, values are Choosable.*/
  public Choosable parseChoice(Object owner, String tag,
			       Hashtable choices, Choosable def)
    throws ParseException{
   Node node = getContent(owner, tag);
   if (node == null) return def;
   String text = getString(node);
   Choosable choice =  (Choosable) choices.get(text.toLowerCase());
   if (choice == null)
     throw new ParseException("The value "+text+" for "+tag+
			      " was not one of the available choices "+
			      nodepath(node),0);
   return choice; }

  public Choosable parseChoice(Object owner, String tag,
			       Choosable choices[], Choosable def)
    throws ParseException{
   Node node = getContent(owner, tag);
   if (node == null) return def;
   String text = getString(node);
   for(int i=0; i<choices.length; i++)
     if (text.equalsIgnoreCase(choices[i].toString()))
       return choices[i];
   throw new ParseException("The value "+text+" for "+tag+
			    " was not one of the available choices "+
			    nodepath(node),0);
  }

  /* ______________________________________________________________________
     Parsing helpers. */

  /** Return a String or Enumeration of content nodes.*/
  public Enumeration children(Object parent){
    Vector v=new Vector();
    if (parent == null) return v.elements();
    Node node = (Node)parent;
    NodeList nl=node.getChildNodes();
    int n=nl.getLength();
    // Extract the nodes we're interested in.
    for(int i=0; i<n; i++){
      Node c = nl.item(i);
      switch(c.getNodeType()){
      case Node.ELEMENT_NODE: v.add(c); break;
      case Node.CDATA_SECTION_NODE:
      case Node.TEXT_NODE:
      if(!c.getNodeValue().trim().equals(""))	// Ignore white space
	v.add(c);
      break;
      case Node.ATTRIBUTE_NODE:
      case Node.COMMENT_NODE:
      case Node.DOCUMENT_TYPE_NODE:
      case Node.NOTATION_NODE:
      case Node.PROCESSING_INSTRUCTION_NODE: break;
      }}
    return v.elements(); }

  /** This is for getting the Single content node of another node. */
  public Node contents(Object node) throws ParseException {
    Node parent = (Node)node;
    Node good=null;
    Node maybe=null;
    for(Node n=parent.getFirstChild(); n!=null; n=n.getNextSibling()){
      switch(n.getNodeType()){
      case Node.ELEMENT_NODE:
	if(good != null)
	  throw new ParseException("Too much stuff in content"+nodepath(parent),0);
	good=n; break;
      case Node.TEXT_NODE:
	if(n.getNodeValue().trim().equals(""))	// Just white space?
	  maybe=n;		// better than nothing at all.
	else if(good != null)
	  throw new ParseException("Too much stuff in content"+nodepath(parent),0);
	else
	  good=n;
	break;
      default: break; }}
    return (good != null? good : maybe); }

  static String nodepath(Node node){
    String path=" (in ";
    while((node != null) && (node.getNodeType()!=Node.DOCUMENT_NODE)){
      path += "<"+node.getNodeName()+">";
      node = node.getParentNode(); }
    return path+")";
  }

}
