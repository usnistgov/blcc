package blcc.parser;

import blcc.model.*;
import blcc.util.*;
import blcc.analysis.Category;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;

public class XMLFormatter {
  PrintWriter out;
  Hashtable idrefs= new Hashtable();
  int idcounter = 0;
  static final int INDENT=2;

  public XMLFormatter(){
    this(new PrintWriter(System.out,true)); }

  public XMLFormatter(PrintWriter outstream){
    out = outstream;
    out.println("<?xml version=\"1.0\"?>");
    // Leave this out for now. parser does enough(?) validation.
    //out.println("<!DOCTYPE Project SYSTEM \"project.dtd\">");
  }

  public void format(XMLIO object){
    format(object,0); }

  public void format(XMLIO object, int level){
    String name = object.getClass().getName();
    int p=name.lastIndexOf('.');
    String tag=name.substring(p+1);
    openTag(level,tag);
    object.formatXMLFields(this,level+1);
    closeTag(level,tag); }

  /* ______________________________________________________________________
     Helper Formatters. */

  public void formatElement(int level, String tag,
			    Object object, Object deflt){
    if((object != null) && (object != deflt)){
      openTag(level,tag);
      format((XMLIO)object,level+1);
      closeTag(level,tag); }}

  public void formatElements(int level, String tag, Enumeration enum1){
    if(enum1.hasMoreElements()){
      openTag(level,tag);
      for( ; enum1.hasMoreElements(); )
	format((XMLIO)enum1.nextElement(), level+1);
      closeTag(level,tag); }}

  /* ______________________________________________________________________
     Formatters for Primitives. */

  //  default is a reserved word!
  public void formatString(int level, String tag, String value, String defalt){
    if((value != null) && !value.equals(defalt) && !value.equals("")){
      indent(level);

      // if string contains any '&', replace with the entity references "&amp;"
      int pos = value.indexOf('&');
      if(pos != -1){
       StringBuffer newValue = new StringBuffer();
       for(int i=0;i<value.length();i++){
         if(value.charAt(i)=='&')
          newValue.append("&amp;");
         else
          newValue.append(value.charAt(i));}
      value=newValue.toString();}

      out.println("<"+tag+">"+value+"</"+tag+">"); }}

  public void formatInt(int level, String tag, int value, int defalt){
    if(value != defalt)
      formatString(level,tag,Integer.toString(value),""); }

  public void formatDouble(int level, String tag, double value, double defalt){
    if(value != defalt)
      formatString(level,tag,Double.toString(value),""); }

  public void formatDate(int level, String tag, Date value, Date defalt){
    if((value != null) && (!value.equals(defalt)))
      formatString(level,tag,Date.toString(value),""); }

  public void formatDateDiff(int level, String tag, DateDiff value, DateDiff defalt){
    if((value != null) && !value.equals(defalt))
      formatString(level,tag,DateDiff.toString(value),""); }


  public void formatStrings(int level, String tag, String values[]){
    if (values != null)
      formatStrings(level,tag,values,values.length); }

  public void formatStrings(int level, String tag, String values[], int n){
    if(values !=null) {
      indent(level);
      out.print("<"+tag+">");
      int l=INDENT*level+2+tag.length();
      String o = "";
      for(int i=0; i<n; i++) {
	if(i>0) out.print(",");
	l += values[i].length();
	if(l > 78) {
	  out.println(); indent(level+1);
	  l=INDENT*(level+1)+values[i].length(); }
	out.print(values[i]); }
      out.println();
      closeTag(level,tag);}}

  public void formatDoubles(int level, String tag, double values[]){
    if (values != null)
      formatDoubles(level, tag, values, values.length); }

  public void formatDoubles(int level, String tag, double values[], int n){
    if(values !=null) {
      String d[]=new String[n];
      for(int i=0; i<n; i++)
	d[i]=Double.toString(values[i]);
      formatStrings(level,tag,d,n); }}

  public void formatDateDiffs(int level, String tag, DateDiff values[]){
    if (values != null)
      formatDateDiffs(level, tag, values, values.length); }

  public void formatDateDiffs(int level, String tag, DateDiff values[], int n){
    if(values !=null) {
      String d[]=new String[n];
      for(int i=0; i<n; i++)
	d[i]=DateDiff.toString(values[i]);
      formatStrings(level,tag,d,n); }}


  public void formatChoice(int level, String tag,
			   Choosable choice, Choosable defalt){
    if((choice != null) && (!choice.equals(defalt)))
      formatString(level,tag,choice.toString(),""); }

  /* ______________________________________________________________________
     LowLevel Primitives. */
  public void openTag(int level, String tag){
    indent(level);
    out.println("<"+tag+">"); }

  public void closeTag(int level, String tag){
    indent(level);
    out.println("</"+tag+">"); }

  public void indent(int level){
    for(int i=0; i<level; i++)
      out.print("  "); }	// INDENT chars
}
