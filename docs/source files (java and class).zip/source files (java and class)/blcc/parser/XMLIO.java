package blcc.parser;
import java.text.ParseException;

public interface XMLIO {
  public void parseXMLFields(XMLParser parser) throws ParseException;
  public void formatXMLFields(XMLFormatter fmt, int level);
}
