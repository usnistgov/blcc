package blcc.util;
public class Sort {

  public static void sort(String strings[]) {
    sort(strings, 0, strings.length-1); }

  static void sort(String strings[], int lo0, int hi0) {
    int lo = lo0;
    int hi = hi0;
    if (lo >= hi) return;
    String mid = strings[(lo + hi) / 2];
    while (lo < hi) {
      while (lo<hi && (strings[lo].compareTo(mid)<0))
	lo++;
      while (lo<hi && strings[hi].compareTo(mid)>0)
	hi--;
      if (lo < hi) {
	String tmp = strings[lo];
	strings[lo] = strings[hi];
	strings[hi] = tmp; }
    }
    if (hi < lo) {
      int t = hi;
      hi = lo;
      lo = t; }
    sort(strings, lo0, lo);
    sort(strings, lo == lo0 ? lo+1 : lo, hi0);
  }
}
