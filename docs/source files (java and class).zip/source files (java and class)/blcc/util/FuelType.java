package blcc.util;

import java.text.ParseException;
import java.util.Hashtable;
import blcc.util.Choosable;

/** FuelType represents various kinds of fuel & thier units.
  */
public class FuelType implements Choosable{
  private final static Hashtable allfuels = new Hashtable();

  // At best, the first units in the units list should be the standard units.
  public static FuelType ELECTRICITY
    =new FuelType("Electricity","Electricity",
		  Units.KWH,
		  new Units[]{Units.KWH, Units.THERM, Units.MBTU,
			      Units.MJ, Units.GJ});
  public static FuelType DISTOIL
    =new FuelType("DistOil", "Distillate Fuel Oil (#1, #2)",
		  Units.LITER,
		  new Units[]{Units.LITER, Units.GALLON,
			      Units.KWH, Units.THERM, Units.MBTU,
			      Units.MJ, Units.GJ});
  public static FuelType RESIDOIL
    =new FuelType("ResidOil", "Residual Fuel Oil (#4, #5, #6)",
		  Units.LITER,
		  new Units[]{Units.LITER, Units.GALLON,
			      Units.KWH, Units.THERM, Units.MBTU,
			      Units.MJ, Units.GJ});
  public static FuelType NATGAS
    =new FuelType("NatGas", "Natural Gas",
		  Units.M3,
		  new Units[]{Units.M3,Units.FT3,
			      Units.KWH, Units.THERM, Units.MBTU,
			      Units.MJ, Units.GJ});
  public static FuelType LPG
    =new FuelType("LPG", "Liquified Petroleum Gas",
		  Units.LITER,
		  new Units[]{Units.LITER, Units.GALLON, Units.FT3, Units.M3,
			      // Units.LB, Units.KG,
			      Units.KWH, Units.THERM, Units.MBTU,
			      Units.MJ, Units.GJ});
  public static FuelType COAL
    =new FuelType("Coal", "Coal",
		  Units.KG,
		  new Units[]{Units.KG, Units.LB,
			  Units.KWH, Units.THERM, Units.MBTU,
			  Units.MJ, Units.GJ});
  public static FuelType STEAM
    =new FuelType("Steam", "Central Steam",
		  Units.GJ,
		  new Units[]{Units.GJ, Units.MJ, Units.KWH,
			      Units.THERM, Units.MBTU});
  public static FuelType CHILLEDWATER
    =new FuelType("ChilledWnater", "Chilled Water",
		  Units.GJ,
		  new Units[]{Units.GJ, Units.MJ, Units.KWH,
			      Units.THERM, Units.MBTU});
  // really ?
  public static FuelType OTHER
    =new FuelType("Other", "Other",
		  Units.GJ,
		  new Units[]{Units.GJ, Units.MJ, Units.KWH,
			      Units.THERM, Units.MBTU});

  // Fuels represented in Emissions data, but not selected at `top level'
  public static FuelType BITUMINOUS
    =new FuelType("BituminousCoal","Bituminous Coal",
		  Units.KG,
		  new Units[]{Units.KG, Units.LB,
			      Units.KWH, Units.THERM, Units.MBTU,
			      Units.MJ, Units.GJ});
  public static FuelType SUBBITUMINOUS
    =new FuelType("SubBituminousCoal","SubBituminous Coal",
		  Units.KG,
		  new Units[]{Units.KG, Units.LB,
			      Units.KWH, Units.THERM, Units.MBTU,
			      Units.MJ, Units.GJ});
  public static FuelType LIGNITE
    =new FuelType("Lignite", "Lignite",
		  Units.KG,
		  new Units[]{Units.KG, Units.LB,
			      Units.KWH, Units.THERM, Units.MBTU,
			      Units.MJ, Units.GJ});

  public static FuelType[] FUELS = {ELECTRICITY,DISTOIL,RESIDOIL,NATGAS,
				    LPG,COAL
				    // ,STEAM,CHILLEDWATER,OTHER
  };

  String name;
  String prettyname;
  Units stdunits;
  Units units[];

  private FuelType(String name, String prettyname,
		   Units stdunits, Units units[]){
    this.name=name;
    this.prettyname=prettyname;
    this.stdunits=stdunits;
    this.units=units;
    allfuels.put(name.toLowerCase(),this); }

  public String toString(){
    return name; }

  public String getPrettyName(){
    return prettyname; }

  public Units getStandardUnits(){
    return stdunits; }
  public Units[] getUnits(){
    return units; }

  public static Hashtable allFuels(){
    return allfuels; }

  public static String toString(FuelType fuel){
    return fuel.name; }

  public static FuelType valueOf(String text) throws ParseException {
    FuelType u = (FuelType) allfuels.get(text.toLowerCase());
    if (u != null) return u;
    throw new ParseException("FuelType not recognized: "+text,0); }
}
