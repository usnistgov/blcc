package blcc.util;

import java.util.Hashtable;
import java.io.*;

public class Defaults {

  static Hashtable defaultsTable;

  static void initializeDefaults(){
    try{
      defaultsTable = new Hashtable();
      BufferedReader buff = new BufferedReader(new InputStreamReader(
                  Defaults.class.getResourceAsStream("/blcc/resources/defaults")));
      String year = buff.readLine();
      String name;
      while ((name = buff.readLine()) != null)
         defaultsTable.put(name, buff.readLine());}
   catch(Exception e) {e.printStackTrace(System.out); }
  }

  static public double getDoubleItem(String name){
   if (defaultsTable == null) initializeDefaults();
   return Double.valueOf(((String)defaultsTable.get(name)).trim()).doubleValue();}

  static public int getIntegerItem(String name){
   if (defaultsTable == null) initializeDefaults();
    return Integer.parseInt(((String)defaultsTable.get(name)).trim());}

 static public String getStringItem(String name){
	if (defaultsTable == null) initializeDefaults();
	 return ((String)defaultsTable.get(name)).trim();}





}
