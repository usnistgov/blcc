package blcc.util;

import blcc.model.Project;
import java.text.ParseException;
import java.util.Hashtable;
import java.text.DecimalFormat;

/** Units represents various units with BLCC.
  * It also (will) handles conversion of quantities between compatible units.
  */
public class Units implements Choosable {

  public final static int MONEY=0;
  public final static int ENERGY=1;
  public final static int VOLUME=2;
  public final static int WEIGHT=3;

  private final static Hashtable allunits = new Hashtable();
  private static int NUnits=0;

  // Monetary Units.
  //public static Units USDOLLAR    =new Units("$",MONEY,"$#,##0.00");
  public static Units USDOLLAR    =new Units("$",MONEY,"$#,###");
  public static Units BRITISHPOUND=new Units("L",MONEY,"L#,###");
  public static Units GERMANMARK  =new Units("FF",MONEY,"FF#,###");
  public static Units FRENCHFRANC =new Units("DM",MONEY,"DM#,###");
  public static Units EURO        =new Units("Euro",MONEY,"E#,###");
  public static Units USUNIT      =new Units("$",Units.MONEY,"$#0.00000");  // allows for pennies if giving a unit cost of something
  public static Units MONETARY[]={USDOLLAR, BRITISHPOUND, GERMANMARK,
          FRENCHFRANC, EURO, USUNIT};

  // (Generic) Energy Units.
  public static Units GJ     =new Units("GJ",    ENERGY,"#,##0.0 GJ");
  public static Units MJ     =new Units("MJ",    ENERGY,"#,##0.0 MJ");
  public static Units KWH    =new Units("kWh",   ENERGY,"#,##0.0 kWh");
  public static Units THERM  =new Units("Therm", ENERGY,"#,##0.0 Therm");
  public static Units MBTU   =new Units("MBtu",  ENERGY,"#,##0.0 MBtu");
  public static Units ENERGIES[]={GJ, MJ, KWH, THERM, MBTU};

  // Measures of Volume
  public static Units LITER  =new Units("Liter",  VOLUME,"#,##0.0 L");
  public static Units THOUSANDL =new Units("1,000 Liters",  VOLUME,"#,##0.0 ThousL");
  public static Units M3     =new Units("Cubic Meters",VOLUME,"#,##0.0 M^3");
  public static Units GALLON =new Units("Gallon", VOLUME,"#,##0.0 Gal");
  public static Units THOUSANDGAL =new Units("1,000 Gallons", VOLUME,"#,##0.0 ThousGal");
  public static Units FT3    =new Units("Cubic Feet",   VOLUME,"#,##0.0 CuFt");
	public static Units MGAL    =new Units("1,000,000 Gallons",   VOLUME,"#,##0.0 Mgal");
  public static Units VOLUMES[]={LITER,THOUSANDL,M3,GALLON,THOUSANDGAL,FT3};

  // Measures of Weight
  public static Units KG     =new Units("kg",     WEIGHT,"#,##0.00 kg");
  public static Units LB     =new Units("Pound",  WEIGHT,"#,##0.0 Lb");
  public static Units WEIGHTS[]={KG,LB};

  String name=null;
  String prettyname;
  DecimalFormat formatter;
  String format;
  int dimension;
  int id;

  private Units(String name, int dimension, String format){
    this.name = name;
    this.prettyname=name;
    this.dimension=dimension;
    this.format=format;
    this.formatter = new DecimalFormat(format);
    id = NUnits++;
    allunits.put(name.toLowerCase(),this); }

  public int getDimension(){
    return dimension; }

  static double conversions[][]= null;

  private static void setConversion(int i, int j, double factor){
    if(conversions==null) initializeConversions();
    conversions[i][j]=factor;
    conversions[j][i]=1/factor;
    for(int k=0; k<NUnits; k++){
      if(conversions[i][k] == 0.0){
	if(conversions[j][k] != 0.0)
	  setConversion(i,k,conversions[i][j]*conversions[j][k]);
      }
      else {
	if(conversions[j][k] == 0.0)
	  setConversion(j,k,conversions[j][i]*conversions[i][k]);
      }}}

  public static void setConversion(Units from, Units to, double factor){
    setConversion(from.id,to.id,factor); }

  public double convert(double amount, Units tounits){
    return convert(amount,this,tounits); }

  public static double convert(double amount, Units fromunits, Units tounits){
    if (fromunits == tounits) return amount;
    if(conversions==null) initializeConversions();
    double f = conversions[fromunits.id][tounits.id];
    if (f == 0.0)
      throw new RuntimeException("No conversion factor from "+fromunits+" to "+tounits
			     +" has been specified");
    return f*amount; }

  public String getPrettyName(){
    return prettyname; }

  public String toString(){
    return name; }

  public static String toString(Units units){
    return units.name; }

  public static Units valueOf(String text) throws ParseException {
    Units u = (Units) allunits.get(text.toLowerCase());
    if (u != null) return u;
    throw new ParseException("Units not recognized: "+text,0); }

  public String toString(double value){
    formatter=new DecimalFormat(format);  // workaround for bug in 1.2; will be fixed in 1.3
    return formatter.format(value); }

  public String toString(Double value){
     formatter=new DecimalFormat(format);  // workaround for bug in 1.2; will be fixed in 1.3
     return formatter.format(value.doubleValue()); }


  private static void initializeConversions(){
    conversions=new double[NUnits][NUnits];
    // 1 Units1 = factor*Units2
    //Generic Energy Conversions.
    setConversion(KWH,THERM,0.03412128);
    setConversion(KWH,MBTU,0.003412128);
    setConversion(KWH,MJ, 3.6);
    setConversion(GJ, MJ,1000.0);
    setConversion(GJ, MBTU, 0.9478169);

    // Volume Conversions.
    setConversion(LITER, GALLON,0.2641721);
    setConversion(THOUSANDL, LITER, 1000.0);
    setConversion(THOUSANDGAL, GALLON, 1000.0);
 		setConversion(MGAL, GALLON, 1000000.0);
    setConversion(M3,FT3, 35.31467);
    setConversion(M3,LITER,1000.0);

    // Weight Conversions.
    setConversion(LB,KG, 0.45359232);

    // The following Energy Conversions represent how much energy one extracts
    // from, say, a gallon of Residual Fuel Oil.
    // It seems that these would depend on conversion efficiencies, and so would
    // vary with time and what kind of generation equipment is used.
    // Thus, this probably will need to be removed and placed in a data file.
    /*    setConversion(MBTU,LIT_DISTOIL, 27.05);
    setConversion(MBTU,LIT_RESIDOIL, 25.98);
    setConversion(MBTU,M3_NATGAS, 27.47);
    setConversion(MBTU,LIT_LPG, 41.349);
    setConversion(MBTU,KG_LPG, 21.014);
    setConversion(MBTU,KG_COAL, 43.19);
    */
  }
}
