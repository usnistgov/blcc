package blcc.util;

import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import blcc.parser.XMLIO;
import java.text.ParseException;
import blcc.model.VaryingEscalation;

public class DOEPrice implements XMLIO {
  Date startdate;
  String region;
  String schedule;
  FuelType fueltype;
  Units units;
  double prices[];

  public DOEPrice(){}

  public Date getStartDate(){ return startdate; }

  public void setStartDate(Date startdate){ this.startdate=startdate; }

  public String getRegion(){ return region; }
  public void setRegion(String region){ this.region=region; }

  public String getSchedule(){ return schedule; }
  public void setSchedule(String schedule){ this.schedule=schedule; }

  public FuelType getFuelType(){ return fueltype; }
  public void setFuelType(FuelType fueltype){ this.fueltype=fueltype; }

  public double[] getPrices(){ return prices; }
  public void setPrices(double[] prices){ this.prices=prices; }

  public void parseXMLFields(XMLParser p) throws ParseException {
    setStartDate(p.parseDate(this,"StartDate",null));
    setRegion(p.parseString(this,"Region",""));
    setSchedule(p.parseString(this,"RateSchedule",""));
    setFuelType((FuelType)p.parseChoice(this,"FuelType",FuelType.allFuels(),null));
    setPrices(p.parseDoubles(this,"Prices",null));
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatDate(level,"StartDate",startdate,null);
    fmt.formatString(level,"Region",region,"");
    fmt.formatString(level,"RateSchedule",schedule,"");
    fmt.formatChoice(level,"FuelType",fueltype,null);
    fmt.formatDoubles(level,"Prices",prices,prices.length);
  }

  public VaryingEscalation makeEscalation(){
    int n = prices.length;
    double[] rates = new double[n];
    for (int d = 0; d < n-1; d++)
      rates[d] = (prices[d+1]/prices[d]) - 1.0;
    double lastYearPrice = prices[n-1];
    double fiveBeforeLastPrice = prices[n-1-5];// 5 years before last
    rates[n-1] = Math.pow((lastYearPrice/fiveBeforeLastPrice), .2) - 1.0;

    VaryingEscalation esc = new VaryingEscalation();
    esc.setName("DOE Price Escalation Rates (" + fueltype.getPrettyName()+")");
    esc.setStartDate(getStartDate());
    esc.setInterval(DateDiff.YEAR);
    esc.setValues(rates);
    return esc; }

}
