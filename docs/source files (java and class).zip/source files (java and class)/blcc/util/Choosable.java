package blcc.util;

public interface Choosable {
  public String getPrettyName();
}
