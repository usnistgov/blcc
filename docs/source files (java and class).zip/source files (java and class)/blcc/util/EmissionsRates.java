package blcc.util;
import blcc.model.UsageIndex;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import blcc.parser.XMLIO;
import java.text.ParseException;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import org.w3c.dom.Node;

public class EmissionsRates implements XMLIO {
  static EmissionsRates defaultEmissionsRates = null;

  Hashtable emissions = new Hashtable();
  Hashtable fuelSubtypes=new Hashtable();

  static void initialize(){
    if (defaultEmissionsRates == null){
      try {
	XMLParser p =new XMLParser(EmissionsRates.class.getResourceAsStream(
	 				"/blcc/resources/Emissions.data"));
	defaultEmissionsRates = (EmissionsRates) p.parse();
      } catch(Exception e){
	System.err.println("Error reading Emissions data!");
	e.printStackTrace(); }
    }}

  public void parseXMLFields(XMLParser p) throws ParseException {
    for(Enumeration e = p.getContents(this,"Fuels"); e.hasMoreElements(); ){
      String ID = "DummyFuel";
      String IDE = "DummyEntry";
      p.prepNode(ID,(Node)e.nextElement());
      FuelType fuel  = (FuelType)p.parseChoice(ID,"FuelType",FuelType.allFuels(),null);
      // This is percent of sulfur by weight
      double sulfur = p.parseDouble(ID,"SulfurPercent",0.0);
      // This is GJ/std.unit
      double content = p.parseDouble(ID,"EnergyContent",0.0);
      // Emissions factors are read in as kg/GJ (or kg/GJ/%sulfur)
      double defco2 = p.parseDouble(ID,"CO2Factor",0.0);
      double defsox = p.parseDouble(ID,"SOxFactor",0.0);
      double defnox = p.parseDouble(ID,"NOxFactor",0.0);
      UsageIndex defsoxi = (UsageIndex)p.parse(ID,"SOxIndex");
      for(Enumeration ee = p.getContents(ID,"Entries"); ee.hasMoreElements();){
        p.prepNode(IDE,(Node)ee.nextElement());
	String subtype  = p.parseString(IDE,"Subtype","");
  String prettyName  = p.parseString(IDE,"PrettyName",null);
	double co2 = p.parseDouble(IDE,"CO2Factor",defco2);
	double sox = p.parseDouble(IDE,"SOxFactor",defsox);
	double nox = p.parseDouble(IDE,"NOxFactor",defnox);
	UsageIndex soxi = (UsageIndex)p.parse(IDE,"SOxIndex",defsoxi);
        p.finishNode(IDE);
	Emissions emis = new Emissions();
	emis.setName(subtype);
  emis.setPrettyName(prettyName);
	emis.setFuelType(fuel);
	emis.setEnergyContent(content);
	emis.setSulfurContent(sulfur/100.0);
	emis.setCO2Factor(co2*content);
	emis.setSOxFactor(sox*content);
	emis.setNOxFactor(nox*content);
	emis.setSOxIndex(soxi);
	emissions.put(fuel+"|"+subtype,emis);
	// ** Record what subtypes are available for each fuel.
	Vector v=(Vector)fuelSubtypes.get(fuel);
	if(v==null) fuelSubtypes.put(fuel,v=new Vector());
	//if(!v.contains(subtype)) v.addElement(subtype);
	v.addElement(emis);
      }
      p.finishNode(ID);
    }
    // fuelSubtypes had a Vector of emissions for each fuel type.
    // Convert each to a simple array.
    for(Enumeration e=fuelSubtypes.keys(); e.hasMoreElements(); ){
      FuelType fuel=(FuelType) e.nextElement();
      Vector v = (Vector)fuelSubtypes.get(fuel);
      Emissions es[] = new Emissions[v.size()];
      for(int i=0; i<es.length; i++)
	es[i]=(Emissions) v.elementAt(i);
      fuelSubtypes.put(fuel,es); }
    initializeCoalEmissions(); // Patch up.
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
  }

  private void initializeCoalEmissions(){
    Emissions bits[] = (Emissions[])fuelSubtypes.get(FuelType.BITUMINOUS);
    Emissions coals[] = new Emissions[bits.length];
    fuelSubtypes.put(FuelType.COAL,coals);
    double bitF = Defaults.getDoubleItem("coal_bituminous_fraction");
    double subF = Defaults.getDoubleItem("coal_subbituminous_fraction");
    double ligF = 1.0 - bitF - subF;

    for(int i=0; i<bits.length; i++){
      Emissions bit = bits[i];
      String subtype = bit.getName();
      Emissions sub = (Emissions)emissions.get(FuelType.SUBBITUMINOUS+"|"+subtype);
      Emissions lig = (Emissions)emissions.get(FuelType.LIGNITE+"|"+subtype);

      Emissions coal = new Emissions();
      coals[i]=coal;
      coal.setName(subtype);
      coal.setFuelType(FuelType.COAL);
      coal.setEnergyContent(bitF*bit.getEnergyContent()+
			    subF*sub.getEnergyContent()+
			    ligF*lig.getEnergyContent());
      coal.setSulfurContent(bitF*bit.getSulfurContent()+
			    subF*sub.getSulfurContent()+
			    ligF*lig.getSulfurContent());
      coal.setCO2Factor(bitF*bit.getCO2Factor()+
			subF*sub.getCO2Factor()+
			ligF*lig.getCO2Factor());
      coal.setSOxFactor(bitF*bit.getSOxFactor()+
			subF*sub.getSOxFactor()+
			ligF*lig.getSOxFactor());
      coal.setNOxFactor(bitF*bit.getNOxFactor()+
			subF*sub.getNOxFactor()+
			ligF*lig.getNOxFactor());
      coal.setSOxIndex(null);
      emissions.put(FuelType.COAL+"|"+subtype,coal);
    }}


  public static Emissions[] getEmissionsChoices(FuelType fuel){
    if(defaultEmissionsRates == null) initialize();
    return (Emissions[]) defaultEmissionsRates.fuelSubtypes.get(fuel); }

  public static Emissions getEmissions(FuelType fuel, String subtype){
    if(defaultEmissionsRates == null) initialize();
    return (Emissions) defaultEmissionsRates.emissions.get(fuel+"|"+subtype); }

  public static Emissions defaultEmissions(FuelType fuel){
    return (fuel == null ? null : getEmissionsChoices(fuel)[0]); }

}

