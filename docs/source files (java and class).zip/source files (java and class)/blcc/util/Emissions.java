package blcc.util;
import blcc.model.UsageIndex;

public class Emissions implements Choosable {
  String name;
  String prettyName;
  FuelType fueltype;
  double sulfurContent, energyContent;
  double CO2Factor,SOxFactor,NOxFactor;
  UsageIndex SOxIndex;

  public Emissions(){}

  public String getName(){
    return name; }
  public void setName(String name){
    this.name = name; }

  public String toString(){
    return name; }

  public String getPrettyName(){
    return (prettyName == null ? name : prettyName); }

  public void setPrettyName(String prettyName){
    this.prettyName=prettyName;  }

  public FuelType getFuelType(){
    return fueltype; }

  public void setFuelType(FuelType fueltype){
    this.fueltype = fueltype; }

  /** One `u' of fuel equals how many Standard Units of this fuel? */
  public double conversionFactor(Units u){
    if(u.getDimension()==Units.ENERGY)
      // content is GJ/std.unit.
      return u.convert(1.0,Units.GJ)/getEnergyContent();
    else
      return u.convert(1.0,fueltype.getStandardUnits()); }

  /** Return the standard unit for this fuel. */
  public Units standardUnits(){
    return fueltype.getStandardUnits(); }

  /** Return the energy content as GJ/std.unit.*/
  public double getEnergyContent(){
    return energyContent; }
  /** Specify the energy content as GJ/std.unit.*/
  public void setEnergyContent(double content){
    energyContent = content; }

  /** Return the sulfur content as factor.*/
  public double getSulfurContent(){
    return sulfurContent; }
  /** Specify the sulfur content.*/
  public void setSulfurContent(double content){
    sulfurContent = content; }

  /** Return the kg of CO2 emission per standard unit of fuel. */
  public double getCO2Factor(){
    return CO2Factor; }
  /** Specify the kg of CO2 emission per standard unit of fuel. */
  public void setCO2Factor(double factor){
    CO2Factor=factor; }

  /** Return the kg of SOx emissions per standard unit of fuel. */
  public double getSOxFactor(){
    return SOxFactor; }
  /** Specify the kg of SOx emissions per standard unit of fuel. */
  public void setSOxFactor(double factor){
    SOxFactor=factor; }

  /** Return the kg of NOx emissions per standard unit of fuel. */
  public double getNOxFactor(){
    return NOxFactor; }
  /** Specify the kg of NOx emissions per standard unit of fuel. */
  public void setNOxFactor(double factor){
    NOxFactor=factor; }

  /** Return the index indicating expected change in SOx emissions over time.*/
  // SOX indices were removed from Emissions data file in version 5.3-10
  public UsageIndex getSOxIndex(){
    return SOxIndex; }
  /** Specify the index indicating expected change in SOx emissions over time.*/
  public void setSOxIndex(UsageIndex index){
    SOxIndex=index; }
}
