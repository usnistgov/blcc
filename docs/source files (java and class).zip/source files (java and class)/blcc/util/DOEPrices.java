package blcc.util;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import blcc.parser.XMLIO;
import blcc.model.VaryingEscalation;
import java.text.ParseException;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import org.w3c.dom.Node;

public class DOEPrices implements XMLIO {
  static DOEPrices defaultPrices = null;


  Date date;
  Hashtable pricetable = new Hashtable();
  Hashtable stateRegion = new Hashtable();
  Hashtable fuelSchedules=new Hashtable();
  String allstates[];

  static void initialize(){
    if (defaultPrices == null){
      try {
	XMLParser p =new XMLParser(DOEPrices.class.getResourceAsStream(
	 				"/blcc/resources/DOEPrices.data"));
	defaultPrices = (DOEPrices) p.parse();
      } catch(Exception e){
	System.err.println("Error reading DOE Pricing data!");
  e.printStackTrace(); }
    }}

  public void parseXMLFields(XMLParser p) throws ParseException {
    date = p.parseDate(this,"Date",null);
    for(Enumeration e = p.getContents(this,"Regions"); e.hasMoreElements(); ){
      String ID = "DummyRegion";
      p.prepNode(ID,(Node)e.nextElement());
      // Require the node to be a Region ???
      String region = p.parseString(ID,"Name","");
      String rstates[] = p.parseStrings(ID,"States",null);
      p.finishNode(ID);
      for(int i=0; i<rstates.length; i++)
	stateRegion.put(rstates[i],region);
    }
    for(Enumeration e = p.getContents(this,"Entries"); e.hasMoreElements(); ){
      DOEPrice price = (DOEPrice) p.parseNext(this,e);
      if (price.getStartDate()==null)
	price.setStartDate(date);
      String region  = price.getRegion();
      String schedule= price.getSchedule();
      FuelType type  = price.getFuelType();

      // ** Record what schedules are available for each FuelType.
      Vector v=(Vector)fuelSchedules.get(type);
      if(v==null) fuelSchedules.put(type,v=new Vector());
      if(!v.contains(schedule)) v.addElement(schedule);

      // Now, store the corresponding DOE Escalation.
      pricetable.put(type+"|"+region+"|"+schedule, price);
    }
    for(Enumeration e=fuelSchedules.keys(); e.hasMoreElements(); ){
      FuelType type =(FuelType) e.nextElement();
      Vector v = (Vector)fuelSchedules.get(type);
      String s[] = new String[v.size()];
      for(int i=0; i<s.length; i++)
	s[i]=(String) v.elementAt(i);
      fuelSchedules.put(type,s); }
    allstates = new String[stateRegion.size()];
    int i=0;
    for(Enumeration e=stateRegion.keys(); e.hasMoreElements(); )
      allstates[i++]=(String) e.nextElement();
    Sort.sort(allstates);
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
  }

  public static VaryingEscalation getEscalation(FuelType fuel,
						String state, String schedule){
    if(defaultPrices == null) initialize();

    if ((fuel == null) || (state == null) || (schedule == null)) return null;
    String region = (String) defaultPrices.stateRegion.get(state);
    String id = fuel+"|"+region+"|"+schedule;
    DOEPrice price = (DOEPrice) defaultPrices.pricetable.get(id);
    return (price == null ? null :  price.makeEscalation()); }

  public static String[] getRateSchedules(FuelType fuel){
    if(defaultPrices == null) initialize();
    return (String[]) defaultPrices.fuelSchedules.get(fuel); }

  public static String defaultRateSchedule(FuelType fuel){
     return (fuel == null ? null : getRateSchedules(fuel)[0]); }

  public static String[] getStates(){
    if(defaultPrices == null) initialize();
    return defaultPrices.allstates; }

}
