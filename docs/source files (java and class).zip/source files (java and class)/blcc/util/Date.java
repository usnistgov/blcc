package blcc.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Calendar;

/** Representation of Dates for BLCC. */
public class Date {
  static DateFormat formatter = null;
  static DateFormat parser = null;
  static DateFormat monthly = null;
  static Calendar calendar = Calendar.getInstance();
  static public int JANUARY  = Calendar.JANUARY;
  static public int FEBRUARY = Calendar.FEBRUARY;
  static public int MARCH    = Calendar.MARCH;
  static public int APRIL    = Calendar.APRIL;
  static public int MAY      = Calendar.MAY;
  static public int JUNE     = Calendar.JUNE;
  static public int JULY     = Calendar.JULY;
  static public int AUGUST   = Calendar.AUGUST;
  static public int SEPTEMBER= Calendar.SEPTEMBER;
  static public int OCTOBER  = Calendar.OCTOBER;
  static public int NOVEMBER = Calendar.NOVEMBER;
  static public int DECEMBER = Calendar.DECEMBER;
  static public final Date FOREVER = new Date(Long.MAX_VALUE);
  java.util.Date absolute=null;

  static void main(String argv[]){
    System.out.println("Testing forever: "+FOREVER.toString());
    System.out.println(" Year: "+FOREVER.getYear());
    System.out.println(" Month: "+FOREVER.getMonth());
    System.out.println(" Day: "+FOREVER.getDay());
  }

  /** Create a Date object representing `now'.*/
  public Date(){
    absolute = new java.util.Date(); }

  /** Create a Date object representing date millisecs from Jan 1, 1970.*/
  public Date(long date){
    absolute = new java.util.Date(date); }

  /** Create a Date object based on the java.util.Date date. */
  public Date(java.util.Date date){
    absolute = date; }

  /** Create a Date representing the date year, month, day. */
  public Date(int year, int month, int day){
    calendar.clear();  // remove time info
    calendar.set(year, month, day);
    absolute = calendar.getTime(); }

  /** Return the number of milliseconds since Jan 1, 1970.*/
  public long getTime(){
    return absolute.getTime(); }

  /** Return the year of this date. */
  public int getYear(){
    calendar.setTime(absolute);	// Maybe should be synchronized ?
    return calendar.get(java.util.Calendar.YEAR); }

  /** Return the month of this date. */
  public int getMonth(){
    calendar.setTime(absolute);
    return calendar.get(java.util.Calendar.MONTH); }

  /** Return the day (in the month) of this date. */
  public int getDay(){
    calendar.setTime(absolute);
    return calendar.get(java.util.Calendar.DAY_OF_MONTH); }

  /** Get the internal date */
  public java.util.Date getRawDate(){
    return absolute; }

  /** Is this date before b? */
  public boolean before(Date b) {
    return (this == FOREVER ? false :
	    (b == FOREVER ? true : absolute.before(b.absolute))); }

  /** Is this date between (inclusive) the dates a and b.*/
  public boolean between(Date a, Date b){
    return (!before(a) && !b.before(this)); }

  /** Is this date in the date interval [a,b) */
  public boolean inInterval(Date a, Date b){
    return (!before(a) && before(b)); }

  /** Return the later of this date and a. */
  public Date max(Date a){
    return (before(a) ? a : this); }

  /** Return the earlier of this date and a. */
  public Date min(Date a){
    return (before(a) ? this : a); }

  /** Return the date which is diff later than this one.*/
  public Date add(DateDiff diff){
    return diff.addToDate(this); }

  /** Return the date at the midpoint between this date and end.*/
  public Date midpoint(Date end){
    long d1 = absolute.getTime();
    long d2 = end.absolute.getTime();
    return new Date(d1 + (d2-d1)/2); }

  /** Return the date representing the previous day.*/
  public Date previousDay(){
    return DateDiff.DAY.subFromDate(this); }

  /** Get date at end of one year starting from this date. */
  public Date yearEnd(){
    return DateDiff.DAY.subFromDate(DateDiff.YEAR.addToDate(this)); }

  /** Get the date of the middle of one year starting from this date. */
  public Date midyear(){
    return DateDiff.HALFYEAR.addToDate(this); }

  static void setupDateFormats(){
    if (formatter == null){
      formatter = DateFormat.getDateInstance(DateFormat.LONG);
      parser = DateFormat.getDateInstance(DateFormat.LONG);
      monthly = new SimpleDateFormat("MMM yyyy");
      if (parser instanceof SimpleDateFormat){
	SimpleDateFormat sp = (SimpleDateFormat) parser;
	String pattern = ((SimpleDateFormat)formatter).toPattern();
	if (pattern.equals("MMMM d, yyyy")) // Specify a more forgiving format!
	  sp.applyPattern("MMM d,yyyy"); }
    }}

  /** Format this date in the form Month Year.*/
  public String formatAsMonth(){
    setupDateFormats();
    return monthly.format(this.absolute); }

  /** Format this date to a string.*/
  public String toString(){
   if (this == FOREVER) return "EndOfTime";
   else return Date.toString(this); }

  /** Format date to a string.*/
  public static String toString(Date date){
    setupDateFormats();
    return formatter.format(date.absolute); }

  /** Parse a string as a Date.
    * Eventually need MUCH MORE flexible & forgiving parsing here.
    * In particular, it should let the day and/or month default to 1 (Jan)
    */
  public static Date valueOf(String text) throws ParseException {
    setupDateFormats();
    if(text.equalsIgnoreCase("forever"))
      return FOREVER;
    java.util.Date absolute = parser.parse(text);
    if (absolute == null) {
      throw new ParseException("Unparseable date: "+text,0); }
    return new Date(absolute);  }

  public boolean equals(Object obj){
    return (obj instanceof Date) && absolute.equals(((Date)obj).absolute); }

  public int hashCode(){
    return absolute.hashCode(); }
}
