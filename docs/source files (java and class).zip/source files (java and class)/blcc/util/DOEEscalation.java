package blcc.util;
import blcc.model.VaryingEscalation;
import blcc.model.Project;
import blcc.model.ModelElement;

/** DOEEscalations are VaryingEscalations, but they remain separate from
 * any particular project, so they dont get `owned', and shouldn't need
 * to refer to any project. */

public class DOEEscalation extends VaryingEscalation {
  /** DOEEscalation are not owned by a model element. */
  public void setOwner(ModelElement owner){}
  public Project getProject(){ return null; }
  public Date defaultStartDate(){ return null; }

}
