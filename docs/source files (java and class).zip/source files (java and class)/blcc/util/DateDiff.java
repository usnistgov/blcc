package blcc.util;

import java.util.Calendar;
import java.text.ParseException;
import java.io.StreamTokenizer;
import java.io.StringReader;
/**
  * DateDiff represents a difference between dates; a time interval.
  * It also provides support methods for computing with dates.
  *
 */
public class DateDiff {
  private static double yearLengthmilli = 365.25*24*60*60*1000;

  public static final DateDiff YEAR  = new DateDiff(1,0,0);
  public static final DateDiff HALFYEAR = new DateDiff(0,6,0);
  public static final DateDiff MONTH = new DateDiff(0,1,0);
  public static final DateDiff DAY   = new DateDiff(0,0,1);
  public static final DateDiff ZERO  = new DateDiff(0,0,0);
  public static final DateDiff FOREVER=new DateDiff(99999,0,0);
  int years,months,days;

  /** Create a DateDiff representing a time interval in years, months and days.*/
  public DateDiff(int years, int months, int days) {
    this.years = years;
    this.months= months;
    this.days  = days; }

  /** Return the number of months in this date difference.*/
  public int getMonths() {
    return months;  }

  /** Return the number of years in this date difference.*/
  public int getYears() {
    return years;  }

  /** Return the difference between two dates in units of years.  */
  public static double diffInYears (Date startDate, Date endDate) {
    return ((double) (endDate.getTime() - startDate.getTime())) / yearLengthmilli;
  }

  public DateDiff add(DateDiff diff){
    if ((this == FOREVER) || (diff == DateDiff.FOREVER))
      return DateDiff.FOREVER;
    else return new DateDiff(years+diff.years,months+diff.months,days+diff.months); }

  /** Add this DateDiff to date, returning the resulting date. */
  public Date addToDate(Date date) {
    if ((this == FOREVER) || (date == Date.FOREVER))
      return Date.FOREVER;
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date.getRawDate());
    calendar.add(Calendar.YEAR,years);
    calendar.add(Calendar.MONTH,months);
    calendar.add(Calendar.DATE,days);
    //    return new Date(calendar.getTime().getTime()); }
    return new Date(calendar.getTime()); }

  public Date subFromDate(Date date) {
    if (this == FOREVER)
      throw new RuntimeException("Subtracting FOREVER from a date.");
    if (date == Date.FOREVER)
      throw new RuntimeException("Subtracting a DateDiff from FOREVER.");
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date.getRawDate());
    calendar.add(Calendar.YEAR,-years);
    calendar.add(Calendar.MONTH,-months);
    calendar.add(Calendar.DATE,-days);
    return new Date(calendar.getTime().getTime()); }

  static public Date[] timeline(Date base, Date service, Date end){
    // First figure out how many intervals there are.
    int pcend = -1;
    Date d = base;
    while(d.before(service)){	// Step through PC period.
      d = DateDiff.YEAR.addToDate(d);
      pcend ++; }
    int svcbegin = pcend+1;
    int nIntervals = svcbegin;
    d = service;
    while(d.before(end)){	// Step through Service period.
      d = DateDiff.YEAR.addToDate(d);
      nIntervals ++; }

    // Now create the table of time interval starting dates.
    Date timeline[] = new Date[nIntervals+1];
    d = base;
    for (int i = 0; i <= pcend; i++){
      timeline[i] = d;
      d = YEAR.addToDate(d); }
    d = service;
    for (int i = svcbegin; i<nIntervals; i++){
      timeline[i] = d;
      d = DateDiff.YEAR.addToDate(d); }
    timeline[nIntervals]=end;

    return timeline; }

  public String toString(){
    return DateDiff.toString(this); }

  public static String toString(DateDiff d){
    if (d == null) return "0 years 0 months";  //"???????";
    if (d == FOREVER) return "Remaining";
    String out="";
    if (d.years >= 0){
  out += d.years + (d.years == 1 ? " year" : " years"); }
    if (d.months >= 0){
	if (!out.equals("")) out += " ";
  out += d.months + (d.months == 1 ? " month" : " months"); }
    if (d.days > 0){
	if (!out.equals("")) out += " ";
	out += d.days + (d.days > 1 ? " days" : " day"); }
    if (out.equals("")) out = "0 years 0 months";
    return out; }

  public static DateDiff valueOf(String text) throws ParseException {
    text = text.toLowerCase();
    if(text.equals("forever")) return FOREVER;
    if(text.startsWith("r")) return FOREVER;
    StreamTokenizer tok = new StreamTokenizer(new StringReader(text));
    int tt;
    DateDiff d = new DateDiff(0,0,0);
    try {
      while((tt = tok.nextToken()) != StreamTokenizer.TT_EOF) {
	if (tt != StreamTokenizer.TT_NUMBER)
	  throw new ParseException("Missing number in DateDiff format",0);
	int n = (int)tok.nval;
	if ((tt = tok.nextToken()) != StreamTokenizer.TT_WORD)
	  throw new ParseException("Missing units in DateDiff format",0);
	String unit = tok.sval;
	if     (unit.startsWith("y")) d.years  += n;
	else if(unit.startsWith("m")) d.months += n;
	else if(unit.startsWith("d")) d.days   += n;
	else
	  throw new ParseException("Missing units in DateDiff format",0);
      }
    } catch(java.io.IOException e){
      throw new ParseException("DateDiff Cannot parse "+text,0); }
    return d; }

  public boolean equals(Object obj){
    if (! (obj instanceof DateDiff)) return false;
    DateDiff d = (DateDiff) obj;
    return years == d.years && months == d.months && d.days == d.days; }

  public int hashCode(){
    return years*400+months*40+days; }
}
