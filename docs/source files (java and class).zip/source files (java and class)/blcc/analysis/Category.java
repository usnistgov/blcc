package blcc.analysis;

import blcc.util.Units;
import java.util.HashSet;
import java.util.Hashtable;
import blcc.util.Choosable;
import java.text.ParseException;

/** A Category is used to categorize amounts and costs. */
public class Category implements Choosable {
  private final static Hashtable allcategories = new Hashtable();

  String name;
  String shortname;
  Category subcategories[];
  boolean summable;
  Units defaultunits;
  Units acceptableunits[];
  boolean monetary;
  HashSet includedSubcategories;
  /* ______________________________________________________________________
     Cost Categories */
  private static final Category none[]= {};

  /* Capital Costs. */
  public static final Category COST_CAPITAL_INITIAL
  = new Category("Cost.Capital.Initial","Initial",
		 none, true,true, null, Units.MONETARY);
  public static final Category COST_CAPITAL_REPLACEMENT
  = new Category("Cost.Capital.Replacement","Replacement",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_CAPITAL_RESIDUAL
  = new Category("Cost.Capital.Residual","Residual (Orig. Comp.)",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_CAPITAL_REPLACEMENT_RESIDUAL
  = new Category("Cost.Capital.Replacement.Residual","Residual (Repl.)",
		 none, true, true, null, Units.MONETARY);

  private static final Category subcapcosts[]={COST_CAPITAL_INITIAL,
                 COST_CAPITAL_RESIDUAL,
                 COST_CAPITAL_REPLACEMENT,
                 COST_CAPITAL_REPLACEMENT_RESIDUAL};

  public static final Category COST_CAPITAL
  = new Category("Cost.Capital","Capital",
		 subcapcosts, true, true, null, Units.MONETARY);

  /* Operating & Maintanance Costs. */

  public static final Category COST_OMR_ENERGY_CONSUMPTION_ELECTRICITY
  = new Category("Cost.OMR.Energy","Energy Consumption.Electricity",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_ENERGY_CONSUMPTION_DISTOIL
  = new Category("Cost.OMR.Energy","Energy Consumption.DistOil",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_ENERGY_CONSUMPTION_RESIDOIL
  = new Category("Cost.OMR.Energy","Energy Consumption.ResidOil",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_ENERGY_CONSUMPTION_NATGAS
  = new Category("Cost.OMR.Energy","Energy Consumption.NatGas",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_ENERGY_CONSUMPTION_LGP
  = new Category("Cost.OMR.Energy","Energy Consumption.LPG",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_ENERGY_CONSUMPTION_COAL
  = new Category("Cost.OMR.Energy","Energy Consumption.COAL",
		 none, true, true, null, Units.MONETARY);

 public static final Category SUBCONSUMPTION[]={COST_OMR_ENERGY_CONSUMPTION_ELECTRICITY,COST_OMR_ENERGY_CONSUMPTION_DISTOIL,
  COST_OMR_ENERGY_CONSUMPTION_RESIDOIL,COST_OMR_ENERGY_CONSUMPTION_NATGAS,COST_OMR_ENERGY_CONSUMPTION_LGP,COST_OMR_ENERGY_CONSUMPTION_COAL};

  public static final Category COST_OMR_ENERGY_CONSUMPTION
  = new Category("Cost.OMR.Energy","Energy Consumption",
     SUBCONSUMPTION, true, true, null, Units.MONETARY);

  public static final Category COST_OMR_ENERGY_DEMAND
  = new Category("Cost.OMR.Energy","Energy Demand",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_ENERGY_REBATE
  = new Category("Cost.OMR.Energy","Energy Rebate",
		 none, true, true, null, Units.MONETARY);

  private static final Category subenergycosts[]={COST_OMR_ENERGY_CONSUMPTION,
  COST_OMR_ENERGY_DEMAND, COST_OMR_ENERGY_REBATE};

  public static final Category COST_OMR_ENERGY
  = new Category("Cost.OMR.Energy","Energy",
     subenergycosts, true, true, null, Units.MONETARY);

  public static final Category COST_OMR_WATER
  = new Category("Cost.OMR.Water","Water",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_WATERDISPOSAL
  = new Category("Cost.OMR.WaterDisposal","Water Disp.",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_RECURRING
  = new Category("Cost.OMR.Recurring","Recurring",
		 none, true, true, null, Units.MONETARY);
  public static final Category COST_OMR_NONRECURRING
  = new Category("Cost.OMR.NonRecurring","Non-Recurring",
		 none, true, true, null, Units.MONETARY);

  private static final Category subomr[]={COST_OMR_RECURRING,
					  COST_OMR_NONRECURRING,
            COST_OMR_ENERGY_CONSUMPTION,
            COST_OMR_ENERGY_DEMAND,
            COST_OMR_ENERGY_REBATE,
					  COST_OMR_WATER,
					  COST_OMR_WATERDISPOSAL};
  public static final Category COST_OMR
  = new Category("Cost.OMR","OM&R", subomr, true, true, null, Units.MONETARY);

  /* Contract Costs. */
  public static final Category COST_CONTRACT_RECURRING
  = new Category("Cost.Contract.Recurring","Recurring",
     none, true, true, null, Units.MONETARY);
  public static final Category COST_CONTRACT_NONRECURRING
  = new Category("Cost.Contract.NonRecurring","Non-Recurring",
     none, true, true, null, Units.MONETARY);

  public static final Category subcont[]={COST_CONTRACT_RECURRING,COST_CONTRACT_NONRECURRING};
  public static final Category COST_CONTRACT
  = new Category("Cost.Contract","Contract",
     subcont, true, true, null, Units.MONETARY);

  /* All costs. */
  private static final Category subcosts[]= {COST_CAPITAL,COST_CONTRACT,
                  COST_OMR};
  public static final Category COST
   = new Category("Cost","Cost", subcosts, true, true, null, Units.MONETARY);

   /* ____________________________________________________________________
    Financed Amount Category
    Not included in LCC (is included in the Contract Payment
    Is used in determing residual value*/

   public static final Category AMOUNT_FINANCED
     = new Category("Initial.Investment.Financed","Financed",
     none,true,true,null,Units.MONETARY);

     /* ____________________________________________________________________
    ECIP Total Investment Category*/

   public static final Category ECIP_TOTAL_INVESTMENT
     = new Category("Initial.Investment.ECIP","Total Investment",
     none,true,true,null,Units.MONETARY);


  /* ______________________________________________________________________
     Resources Categories */
  public static final Category RESOURCE_USAGE_WATER=
  new Category("Resource.Usage.Water","Water",
	       none, true, false, Units.LITER, Units.VOLUMES);
  public static final Category RESOURCE_USAGE_ENERGY =
		   new Category("Resource.Usage.Energy","Energy",
				null, true, false, Units.MJ, Units.ENERGIES);
  public static final Category usages[]={RESOURCE_USAGE_WATER,
					 RESOURCE_USAGE_ENERGY};
  public static final Category RESOURCE_USAGE=
	 new Category("Resource.Usage","Usage", usages, false, false, null, null);
  /* ______________________________________________________________________
     Emissions Categories */
  public static final Category EMISSIONS_WASTEWATER
  = new Category("Emissions.WasteWater","WasteWater",
		 none, true, false, Units.LITER, Units.VOLUMES);
  public static final Category EMISSIONS_CO2
  = new Category("Emissions.CO2","CO2", none, true, false,
		 Units.KG, Units.WEIGHTS);
  public static final Category EMISSIONS_SOx
  = new Category("Emissions.SOx","SOx", none, true, false,
		 Units.KG, Units.WEIGHTS);
  public static final Category EMISSIONS_NOx
  = new Category("Emissions.NOx","NOx", none, true, false,
		 Units.KG, Units.WEIGHTS);
  public static final Category emissions[]={EMISSIONS_WASTEWATER,
					    EMISSIONS_CO2,EMISSIONS_SOx,EMISSIONS_NOx};
  public static final Category EMISSIONS
  = new Category("Emissions","Emissions",emissions,false,false,null, null);

  private Category(String name, String shortname,
		   Category subcategories[], boolean summable,  boolean monetary,
		   Units defaultunits, Units acceptableunits[]){
    this.name   = name;
    this.shortname= shortname;
    this.subcategories = subcategories;
    this.summable = summable;
    this.monetary=monetary;
    this.defaultunits = defaultunits;
    this.acceptableunits = acceptableunits;
    includedSubcategories = new HashSet();
    this.addIncludedSubcategories(includedSubcategories);
    allcategories.put(name.toLowerCase(),this); }

  /** Get the short names of a list of catgories */
  public static String[] categoryNames(Category categories[]){
    String names[] = new String[categories.length];
    for(int c=0; c<categories.length; c++)
      names[c] = categories[c].shortname;
    return names; }

  /** Return the name of this category. */
  public String getName(){
    return name; }

  public String getPrettyName(){
    return shortname; }

  /** Return the default units for amounts classified under this category. */
  public Units defaultUnits(){
    return defaultunits; }

  /** Return an array of the subcategories of this category. */
  public Category[] getSubCategories(){
    return subcategories; }

  /** Returns whether this category is for monetary amounts. */
  public boolean isMonetary(){
    return monetary; }

  /** Returns whether the subcategories of this category can be summed to give a
    * meaningful total for the category. */
  public boolean isSummable(){
    return summable; }

  /* Construct the set of subcategories that are included in this category. */
  private void addIncludedSubcategories (HashSet set){
    set.add(this);
    if(summable && subcategories != null){
      for(int i=0; i<subcategories.length; i++)
	subcategories[i].addIncludedSubcategories(set);
    }}

  /** Is category an included subcategory of this category (or one of its subcategories).
    * Included means that it makes sense to sum quantities from a subcategory to
    * contribute to the total for a category. */
  public boolean includes(Category category){
    return includedSubcategories.contains(category); }

  /** Are units an acceptible unit for amounts classified under this category? */
  public boolean isValidUnits(Units units) {
    if (acceptableunits == null) return false;
    for(int i=0; i<acceptableunits.length; i++){
      if (acceptableunits[i].equals(units)) return true; }
    return false; }

  public static Hashtable allCategories(){
    return allcategories; }

  public String toString(){
    return name; }

  public static String toString(Category category){
    return category.name; }

  public static Category valueOf(String text) throws ParseException {
    Category c = (Category) allcategories.get(text.toLowerCase());
    if (c != null) return c;
    throw new ParseException("Category not recognized: "+text,0); }

}
