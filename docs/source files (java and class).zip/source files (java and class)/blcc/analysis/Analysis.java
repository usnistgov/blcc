package blcc.analysis;

import blcc.model.ModelElement;
import blcc.model.Project;
import blcc.model.Alternative;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.reports.Table;
import java.util.Vector;
import java.util.Enumeration;
/** An Analysis collects all Costs and Amounts from all ModelElements in a
  * Project Case during the study period.  From this collection, it can
  * compute the total amounts in various categories, during various periods,
  * distributed along a timeline (sequence of time intervals), and so on.
  *
  * The analysis gets a snapshot of the current state of the project, so
  * that it should produce the same reports, even if the project is later modified.
  */
public class Analysis {

  Project project = null;
  Date base,service,end;
  double discount;
  Units money;
  int nevents;
  Event events[];
  double capitalRecoveryFactor;
  Table projDesc;
  Vector alternatives = new Vector();
  Vector altDescs = new Vector();

  public Analysis(Project project){
    this.project=project;
    events = new Event[100];
    nevents=0;
  }

  public void analyze(){
    // Snapshot various information about the project used to collect the data.
    base     =project.getBaseDate();
    service  =project.getServiceDate();
    end      =project.getEndDate();
    discount =project.getDiscountRate();
    money    =project.getMonetaryUnits();
    capitalRecoveryFactor = project.getCapitalRecoveryFactor();
    for(Enumeration e=project.enumerateAlternatives(); e.hasMoreElements(); ){
      Alternative alt = (Alternative) e.nextElement();
      alternatives.add(alt); }
    // Now collect analysis data.
    nevents=0;
    project.analyze(this);
  }

  public Project getProject(){
    return project; }

  public Date getBaseDate() { return base; }
  public Date getServiceDate() { return service; }
  public Date getEndDate() { return end; }
  public Units getMonetaryUnits(){ return money; }

  /** Multiply a PresentValue amount by this to get Annual Value. */
  public double getCapitalRecoveryFactor(){ return capitalRecoveryFactor; }

  /** Returns an enumeration allowing iteration through all Alternatives being studied.*/
  public Enumeration enumerateAlternatives() {
    return alternatives.elements(); }


  /* ______________________________________________________________________
     Adding data to an analysis */

  /** Add an amount to the analysis, attributed to owner and  classified
    * according to category, that takes place at date. */
  public void addAmount(ModelElement owner, Category category,
			double amount, Units units, Date date){
    if (nevents >= events.length){
      Event tmp[]= new Event[events.length*2];
      System.arraycopy(events,0,tmp,0,events.length);
      events = tmp; }
    Units tounits = category.isMonetary() ? money : category.defaultUnits();
    amount = tounits.convert(amount,units);
    events[nevents++]= new Event(owner,category,amount,date);
  }

  /* ______________________________________________________________________
   */

  /** Is there a contribution from ownedby to the specified category? */
  public boolean contributes(ModelElement ownedby, Category category){
    for(int i=0; i<nevents; i++){
      Event e = events[i];
      if( e.owner.containedIn(ownedby)
	  && category.includes(e.category))
	return true;
    }
    return false; }

  /** Return the subset of categories for which there is a contribution from ownedby.
    * Returns null if there are none. */
  public Category[] contributingCategories(ModelElement ownedby, Category categories[]){
    int n=0;
    for(int i=0; i<categories.length; i++){
      if (contributes(ownedby,categories[i])) n++; }
    if (n == 0) return null;
    Category nonempty[] = new Category[n];
    int j=0;
    for(int i=0; i<categories.length; i++){
      if (contributes(ownedby,categories[i]))
	nonempty[j++] = categories[i]; }
    return nonempty; }

  /* ______________________________________________________________________
     Extracting data from an analysis */

  /** Get the total amount attributed to ownedby (and its children)
    * that are categorized under category (and its subclasses),
    * that occur during the interval [start,end), and expressed
    * in the specified units and appropriately discounted */
  public double getAmount(ModelElement ownedby, Category category,
			  Units units, Date start, Date end, boolean presentvalue){
    double amount = 0.0;

    for(int i=0; i<nevents; i++){
      Event e = events[i];
      if( e.owner.containedIn(ownedby)
    && category.includes(e.category)
    && e.date.between(start,end) ) {
			//System.out.println("Amount: "+e.amount);
			//System.out.println("Discount Rate: "+discount);
			//System.out.println("Length : "+ DateDiff.diffInYears(base, e.date));
  if (presentvalue)
    amount += e.amount/Math.pow(1+discount, DateDiff.diffInYears(base,e.date));
  else
    amount += e.amount;
    }}
    return amount; }


  /** Get the total amount attributed to ownedby (and its children)
    * that are categorized under each of the categories (and thier subclasses),
    * that occur during the interval [start,end), and expressed
    * in the specified units and appropriately discounted */
  public double[] getAmount(ModelElement ownedby, Category categories[],
			    Units units, Date start, Date end, boolean presentvalue){
    double amounts[] = new double[categories.length];
    for(int i=0; i<nevents; i++){
      Event e = events[i];
      if( e.owner.containedIn(ownedby)
	  && e.date.between(start,end) ) {
	for(int c = 0; c < categories.length; c++){ // Add to appropriate categories.
	  if(categories[c].includes(e.category)) {
	     if (presentvalue)
	       amounts[c] += e.amount/Math.pow(1+discount,
					       DateDiff.diffInYears(base,e.date));
	     else
	       amounts[c] += e.amount;
	  }}
      }}
    return amounts; }

  /** Get the total amount attributed to ownedby (and its children)
    * that are categorized under category (and its subclasses),
    * that occur during each interval in the timeline, and expressed
    * in the specified units and appropriately discounted */


  public double[] getAmount(ModelElement ownedby, Category category,
			    Units units, Date timeline[], boolean presentvalue){
    int nperiods = timeline.length-1;

    Date start = timeline[0];
    Date finish = timeline[nperiods];

    double amounts[] = new double[nperiods];
    for(int i=0; i<nevents; i++){
      Event e = events[i];
      if( e.owner.containedIn(ownedby)
    && category.includes(e.category)&& e.date.between(start,finish) ){
     int d=0;

     for(; d<nperiods; d++){
      if(e.date.before(timeline[d+1])) break;}
     if (d == nperiods)            // if d = nperiods, e.date it's not before the end date so it must BE the end date;
       d=d-1;                      // (we know it's in timeline because of e.date.between(start,end))
                                   // the cost belongs to the last interval in amounts (amounts[d-1]) (amounts[d] is
                                    // is out of bounds) so set d to be d-1
      if (d < nperiods) {
      if (presentvalue)
	      amounts[d] += e.amount/Math.pow(1+discount,
					      DateDiff.diffInYears(base,e.date));
      else
        amounts[d] += e.amount;
      }
      }}
    return amounts; }

  /** Get the total amount attributed to ownedby (and its children)
    * that are categorized under each of the categories (and thier subclasses),
    * that occur during each interval in the timeline, and expressed
    * in the specified units and appropriately discounted.
    * The return value is a 2d array whose first index is the category, the
    * second is the time interval. */


  public double[][]  getAmount(ModelElement ownedby, Category categories[],
			       Units units, Date timeline[], boolean presentvalue){
    int nperiods = timeline.length-1;
    Date start = timeline[0];
    Date finish = timeline[nperiods];

    double amounts[][] = new double[categories.length][nperiods];
    for(int i=0; i<nevents; i++){
      Event e = events[i];
      if( e.owner.containedIn(ownedby)&& e.date.between(start,finish)){
     int d=0;
    for( ; d<nperiods; d++){  // Find the interval for this event.
     if(e.date.before(timeline[d+1])) break;}
   if (d == nperiods)             // if d = nperiods, e.date it's not before the end date so it must BE the end date;
    d=d-1;                        // (we know it's in timeline because of e.date.between(start,end))
                                  // the cost belongs to the last interval in amounts (amounts[d-1]) (amounts[d] is
                                  // is out of bounds) so set d to be d-1
   if (d < nperiods) {
    for(int c = 0; c < categories.length; c++){ // Add to appropriate categories.
       if(categories[c].includes(e.category)) {
        if (presentvalue)
          amounts[c][d] += e.amount/Math.pow(1+discount,
          DateDiff.diffInYears(base,e.date));
        else
         amounts[c][d] += e.amount;
     }}}
      }}

    return amounts; }



  /* ______________________________________________________________________
     Subtract an amount.
     Support for loans and such. */

  /** Subtract a portion of the amount attributed to owner (and its children)
    * and classified according to category (and its subcategories),
    * that takes place during the time interval [start,end),
    * returning the amount subtracted.
    * This supports Loans. */
  public double subtractAmount(ModelElement ownedby, Category category,
			       double portion, Units units,
			       Date start, Date end){
    double amount = 0.0;
    for(int i=0; i<nevents; i++){
      Event e = events[i];
      if( e.owner.containedIn(ownedby)
	  && category.includes(e.category)
	  && e.date.between(start,end) ) {
	double a = portion*e.amount;
	amount += a;
	e.amount -= a;
      }}
    return amount; }
}


class Event {
  ModelElement owner;
  Category category;
  double amount;
  Date date;

  public Event(ModelElement owner, Category category,
	       double amount, Date date){
    this.owner    = owner;
    this.category = category;
    this.amount   = amount;
		//System.out.println(amount);
    this.date     = date; }

  public String toString(){
    return amount + " by " + owner.getName() +
      " for " + category.getName() + " on " + date; }
}
