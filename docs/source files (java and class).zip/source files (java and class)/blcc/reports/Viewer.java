package blcc.reports;

import javax.swing.JFrame;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Dimension;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;
import javax.swing.text.html.CSS;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.AttributeSet;
import java.util.Enumeration;
import java.io.IOException;

public class Viewer extends JFrame {

  JEditorPane viewerPane;

  public Viewer(String title) {
    super(title);
    viewerPane = new JEditorPane();
    viewerPane.setEditable(false);
    viewerPane.setContentType("text/html");
    setStyleSheet();
		getContentPane().add(new JScrollPane(viewerPane));
		viewerPane.addHyperlinkListener(new HyperlinkListener()
     {
	public void hyperlinkUpdate(HyperlinkEvent e)
	  {
	    if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
	      JEditorPane pane = (JEditorPane) e.getSource();
	      if (e instanceof HTMLFrameHyperlinkEvent) {
		HTMLFrameHyperlinkEvent  evt = (HTMLFrameHyperlinkEvent)e;
		HTMLDocument doc = (HTMLDocument)pane.getDocument();
		doc.processHTMLFrameHyperlinkEvent(evt);
	      } else {
		try {
		  pane.setPage(e.getURL());
		} catch (Throwable t) {
		  t.printStackTrace(); }
	      }
	    }
	  }
      });

    addWindowListener(new WindowAdapter()
      {
	public void windowClosing(java.awt.event.WindowEvent e){
	  System.exit(0); }
      });
  }

  void setStyleSheet(){
    HTMLEditorKit ekit = (HTMLEditorKit) viewerPane.getEditorKit();
    StyleSheet sheet = ekit.getStyleSheet();
    System.out.println("***** Style before ****");
    //showRules(sheet);
    showRule(sheet.getStyle("th"));
    showRule(sheet.getStyle("td"));
    try {
      sheet.loadRules(new java.io.FileReader("/home/miller/buildLCC/java/blcc/reports/style.css"),null);
    } catch (Throwable t) {
      t.printStackTrace(); }
    //sheet.getStyle("th").addAttribute(CSS.getAttribute("font-style"),"italic");
    //sheet.getStyle("th").addAttribute(CSS.getAttribute("font-size"),"medium");
    //    showRule(sheet.getDeclaration("th { font-style: italic; font-size: medium }"));
    //showRule(sheet.getDeclaration("th { font-style=italic, font-size=medium }"));
    //    StyleConstants.setItalic(sheet.getStyle("th"),true);
    System.out.println("***** Style after ****");
    showRule(sheet.getStyle("th"));
    showRule(sheet.getStyle("td"));
    //showRules(sheet);
    //ekit.setStyleSheet(sheet);



  }

  void showRule(AttributeSet s){
    Enumeration e = s.getAttributeNames();
    while(e.hasMoreElements()){
      Object key = e.nextElement();
      Object val = s.getAttribute(key);
      System.out.println(key+" => " + val + " ("+val.getClass()+")"); }}

  void showRules(StyleSheet styles){
    Enumeration rules = styles.getStyleNames();
    while (rules.hasMoreElements()) {
      String name = (String) rules.nextElement();
      Style rule = styles.getStyle(name);
      System.out.println(rule.toString());
    }}
  public void setPage(String url) throws IOException {
    viewerPane.setPage(url);}

  public void setText(String text) {
    viewerPane.setText(text); }

  public static void main(String[] args){
    Viewer viewer = new Viewer("Report Viewer");
    viewer.setSize(new Dimension (300, 500));
    viewer.show();
    try {
      viewer.setPage(args[0]);
    } catch(Throwable t){
      t.printStackTrace(); }
  }
}
