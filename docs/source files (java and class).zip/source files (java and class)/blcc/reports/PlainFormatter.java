package blcc.reports;

import java.io.PrintWriter;
import java.text.NumberFormat;

public class PlainFormatter extends Formatter {
  PrintWriter out;
  int width= 70;

  int widths[] = null;
  int colno;

  public PlainFormatter() {
    this(new PrintWriter(System.out,true)); }

  public PlainFormatter(PrintWriter outstream){
    out = outstream;  }

  public void header(int level, String text) {
    out.println();
    if (level == 1){
      repeat('=',width); out.println();
      out.print("||"); cpad(text,width-4,' '); out.println("||");
      repeat('=',width); out.println(); }
    else if (level == 2){
      repeat('-',width); out.println();
      out.print('|'); cpad(text,width-2,' '); out.println('|');
      repeat('-',width); out.println(); }
    else {
      cpad(text,width,'*'); }
    out.println(); }

  public void line(String text) {
    out.println(text); }

  public void paragraph(String text) {
    // Need to add line Wrapping here.
    out.println(text); }

   public String spaces(){
    return "   ";}

  public void repeat(char c, int n){
    for(int i=0; i<n; i++)
      out.print(c); }

  void rpad(String text, int width, char c){
    int n = text.length();
    out.print(text);
    repeat(c,width-n); }

  void lpad(String text, int width, char c){
    int n = text.length();
    repeat(c,width-n);
    out.print(text); }

  void cpad(String text, int width, char c){
    int n = text.length();
    int p = (width-n)/2;
    repeat(c,p);
    out.print(text);
    repeat(c,width-n-p); }

  // Table formatting
  public void formatTableStart(){}

  int nextindent=0;
  public void formatTableRowStart(int indent){
    nextindent=indent;  }

  public void formatTableCol(int col, int width, String data, Object format){
    int attr = 0;
    if (format instanceof Integer) attr = ((Integer) format).intValue();
    if (nextindent>0){
      repeat(' ',nextindent*2);
      width -= nextindent*2;
      nextindent=0; }
    switch (attr & 3){
    case 0x0: rpad(data,width,' '); break; // Left justi
    case 0x1: lpad(data,width,' '); break; // Right
    case 0x2: cpad(data,width,' '); break; // Centered
    case 0x3: repeat(data.charAt(0),width); break; }
    out.print(' ');
  }

  public void formatTableRowEnd(){
    out.println();  }
  public void formatTableEnd(){}
}

