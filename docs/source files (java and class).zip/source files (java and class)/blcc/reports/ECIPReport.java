package blcc.reports;


import blcc.model.*;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.util.FuelType;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.DecimalFormat;
import java.util.Enumeration;


public class ECIPReport {


  Analysis analysis;
  Formatter formatter;
  Project project;
  String fileName;
  Units money;
	// variables used for calcs in section 4-8
	double totalInvestment=0.0, totalAnnualEnergyAndWater=0.0, totalDiscountedEnergyAndWater=0.0, totalAnnualRecurring=0.0,
	        totalAnnualNonRecurring=0.0, totalDiscountedNonEnergy=0.0, escalatedNARCAmount=0.0;





  public ECIPReport(Analysis analysis, Formatter formatter,
                       Project project, String fileName){
    this.analysis = analysis;
    this.formatter = formatter;
    this.project = project;
    this.fileName = fileName;}

  public void report(){

    Date start      = analysis.getBaseDate();
    Date service    = analysis.getServiceDate();
    Date end        = analysis.getEndDate();
    double CRF      = analysis.getCapitalRecoveryFactor();
    double length   = DateDiff.diffInYears(service,end);
    money           = analysis.getMonetaryUnits();
    Date timeline[] = DateDiff.timeline(start,service,end);

    formatter.header(1,"NIST BLCC " + blcc.util.Defaults.getStringItem("version") + ": ECIP Report");
		if( project.getAnalysisType() ==Project.OMBANALYSIS || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS){
			formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology in OMB Circular A-94");}
		else{
    formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology and Procedures, 10 CFR, Part 436, Subpart A");}
		formatter.header(6,"The LCC calculations are based on the FEMP discount rates and energy price escalation rates updated on April 1, " + blcc.util.Defaults.getIntegerItem("default year") + ".");
		formatter.header(0,"");

    formatter.header(0,"");
    describeProject(project,0).format(formatter);

   for(Enumeration e=project.enumerateAlternatives(); e.hasMoreElements(); ){
      Alternative alt = (Alternative) e.nextElement();
      describeAlternative(alt, start, service, end, length, 0); }

    }


  /* ______________________________________________________________________
     Project Description */


  public Table describeProject(Project project, int level){
    Table desc = new Table(4);
    desc.addRow(level+1,"Location:",Table.ROWHEADING,
                project.getLocation(),Table.RIGHT,
								"Discount Rate:",Table.ROWHEADING,
								project.getDiscountRate(),Table.RATE);

		desc.addRow(level+1, "Project Title:", Table.ROWHEADING,
                project.getName(), Table.RIGHT,
								"Analyst:",Table.ROWHEADING,
								 project.getAnalyst(),Table.RIGHT);

    desc.addRow(level+1,"Base Date:",Table.ROWHEADING,
                project.getBaseDate(),Table.RIGHT,
								"Preparation Date:",Table.ROWHEADING,
								new java.util.Date(),Table.RIGHT);

		desc.addRow(level+1,"BOD:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT,
								"Economic Life:",Table.ROWHEADING,
								project.getDuration(),Table.RIGHT);

	 desc.addRow(level+1,"File Name:",Table.ROWHEADING,
							 	fileName,Table.RIGHT,
								"", Table.CENTER,
								"", Table.CENTER);



    return desc; }


      /* ______________________________________________________________________
     Alternative Description */
  public void describeAlternative(Alternative alt, Date start, Date service, Date end, double length, int level){

    for(Enumeration e=alt.enumerateCapitalComponents(); e.hasMoreElements(); ){
        CapitalComponent comp = (CapitalComponent) e.nextElement();
        describeInvestment(comp, level+1);}

        describeEnergyAndWater(alt, start, service, end, length, level+1);
				describeNonEnergy(alt, start, service, end, length, level+1);
				describeRemainingSections(start, end, level+1);

  }

    public void describeInvestment(CapitalComponent comp, int level){
    formatter.header(5,"1.  Investment");
    Table desc = new Table(2);
    desc.addRow(level+1,formatter.spaces()+"Construction Cost",Table.ROWHEADING,
                comp.getConstructionCost(),money);
    desc.addRow(level+1,formatter.spaces()+"SIOH",Table.ROWHEADING,
                comp.getSIOH(),money);
    desc.addRow(level+1,formatter.spaces()+"Design Cost", Table.ROWHEADING,
                comp.getDesignCost(), money);

    double cost=0.0;
		cost=comp.getConstructionCost()+comp.getSIOH()+comp.getDesignCost();
    totalInvestment=cost - comp.getSalvageValue() - comp.getUtilityRebate();

    desc.addRow(level+1,formatter.spaces()+"Total Cost",Table.ROWHEADING,
                cost,money);
    desc.addRow(level+1,formatter.spaces()+"Salvage Value of Existing Equipment",Table.ROWHEADING,
                 comp.getSalvageValue(),money);
    desc.addRow(level+1,formatter.spaces()+"Public Utility Company ",Table.ROWHEADING,
                 comp.getUtilityRebate(),money);
    desc.addRow(level+1,formatter.spaces()+"Total Investment",Table.ROWHEADING,
                totalInvestment,money);
    desc.addRow(0,"",Table.COLHEADING);
    desc.format(formatter);}

    public void describeEnergyAndWater(Alternative alt, Date start, Date service, Date end, double length, int level){
      formatter.header(5,"2.  Energy and Water Savings (+) or Cost (-)");
      formatter.header(5,"Base Date Savings, unit costs, & discounted savings");
      Table desc = new Table(6);
      desc.addRow(level+1, "Item", Table.COLHEADING, "Unit Cost", Table.COLHEADING, "Usage Savings", Table.COLHEADING,
                            "Annual Savings", Table.COLHEADING, "Discount Factor",Table.COLHEADING, "Discounted Savings", Table.COLHEADING);

      // collect totals for each energy type
      int numberOfFuels = FuelType.FUELS.length;

      double[] fuelUsageSavings = new double[numberOfFuels];
      double[] fuelAnnualSavings = new double[numberOfFuels];
		  double totalFuelUsage=0.0, totalFuelAnnual=0.0,totalFuelDemand=0.0, totalUtilityRebate=0.0;  // total savings
			double tempUsage=0.0, tempAnnual=0.0;

		  for(int i=0;i<fuelUsageSavings.length;i++){     // since this is keeping total, intialize
       fuelUsageSavings[i]=0.0;
       fuelAnnualSavings[i]=0.0;}

      int index=0;
			double stdusage, factor, toGJ;


		  // add up savings for usage savings, annual savings and demand charge annual savings  asr 10-29-11 add rebate
		  // can't use getAmount without discounting b/c that includes escalations
			// note for usage savings - this is not an average savings, it's a savings at base date (ie, can't use indexed amount)

		  for(Enumeration e = alt.enumerateEnergyUsages(); e.hasMoreElements();) {
        EnergyUsage usage = (EnergyUsage) e.nextElement();
        FuelType fuelType = usage.getFuelType();
        factor=usage.getEmissions().conversionFactor(usage.getUnits());
        toGJ=usage.getEmissions().conversionFactor(Units.GJ);
        for (int i=0; i < numberOfFuels; i++)
          if (fuelType == FuelType.FUELS[i]){index=i; break;}

				stdusage = usage.getYearlyUsage() * factor;

				tempUsage = Units.convert(stdusage/toGJ,Units.GJ,Units.MBTU);
				tempAnnual = usage.getYearlyUsage() * usage.getUnitCost();

				fuelUsageSavings[index]+= tempUsage;
				fuelAnnualSavings[index]+= tempAnnual;
				totalFuelDemand+=usage.getDemandCharge();
				totalUtilityRebate+=usage.getUtilityRebate();
				totalFuelUsage+=tempUsage;
				totalFuelAnnual+=tempAnnual;}

		  // add up savings for water usage and water disposal
		  double waterUsageSavings=0.0, waterDisposalSavings=0.0, waterUsageAnnualSavings=0.0, waterDisposalAnnualSavings=0.0;
		  for(Enumeration e = alt.enumerateWaterUsages(); e.hasMoreElements(); ){
         WaterUsage usage = (WaterUsage) e.nextElement();
			   waterUsageSavings+=Units.convert(usage.getSummerYearlyUsage()+usage.getWinterYearlyUsage(), usage.getUnits(), Units.MGAL);
				 waterDisposalSavings+=Units.convert(usage.getSummerYearlyDisposal()+usage.getWinterYearlyDisposal(), usage.getUnits(), Units.MGAL);
				 waterUsageAnnualSavings+= (usage.getSummerYearlyUsage()*usage.getSummerUsageUnitCost()) + (usage.getWinterYearlyUsage()*usage.getWinterUsageUnitCost());
				 waterDisposalAnnualSavings+= (usage.getSummerYearlyDisposal()*usage.getSummerDisposalUnitCost()) + (usage.getWinterYearlyDisposal()*usage.getWinterDisposalUnitCost());}

      for(int i=0; i<numberOfFuels; i++){
				if (fuelUsageSavings[i]==0){}  // do nothing
				else{
				   desc.addRow(level+1, FuelType.FUELS[i].getPrettyName(), Table.ROWHEADING,
                         fuelAnnualSavings[i]/fuelUsageSavings[i], Units.USUNIT,
                         fuelUsageSavings[i], Units.MBTU,
                         fuelAnnualSavings[i], money,
												 fuelAnnualSavings[i]==0.0 ? 0.0 : (analysis.getAmount(alt,Category.SUBCONSUMPTION[i],money,start,end,true)/fuelAnnualSavings[i]), Table.FACTOR,
                         analysis.getAmount(alt,Category.SUBCONSUMPTION[i],money,start,end,true), money); }}

			// demand
			if(totalFuelDemand != 0.0)
			desc.addRow(level+1, "Demand Savings", Table.ROWHEADING,
                           " ", Table.COLHEADING,
                           " ", Table.COLHEADING,
                           totalFuelDemand, money,
                           analysis.getAmount(alt,Category.COST_OMR_ENERGY_DEMAND,money,start,end,true)/totalFuelDemand, Table.FACTOR,
                           analysis.getAmount(alt,Category.COST_OMR_ENERGY_DEMAND,money,start,end,true), money);
			// rebate
			if(totalUtilityRebate != 0.0)
			desc.addRow(level+1, "Rebate Savings", Table.ROWHEADING,
                           " ", Table.COLHEADING,
                           " ", Table.COLHEADING,
                           totalUtilityRebate, money,
                           analysis.getAmount(alt,Category.COST_OMR_ENERGY_REBATE,money,start,end,true)/totalUtilityRebate, Table.FACTOR,
                           analysis.getAmount(alt,Category.COST_OMR_ENERGY_REBATE,money,start,end,true), money);

			// subtotal - energy
			desc.addRow(level+1, "Energy Subtotal", Table.ROWHEADING,
                           " ", Table.COLHEADING,
                           totalFuelUsage, Units.MBTU,
                           totalFuelAnnual + totalFuelDemand + totalUtilityRebate, money,
                           " ", Table.COLHEADING,
                           analysis.getAmount(alt,Category.COST_OMR_ENERGY,money,start,end,true), money);

			desc.addRow(0,"",Table.COLHEADING);

			// water usage
			if(waterUsageSavings==0.0){}  // do nothing
			else{
				   desc.addRow(level+1, "Water Usage", Table.ROWHEADING,
                         waterUsageAnnualSavings/waterUsageSavings, Units.USUNIT,
                         waterUsageSavings, Units.MGAL,
                         waterUsageAnnualSavings, money,
												 waterUsageAnnualSavings==0.0 ? 0.0 : (analysis.getAmount(alt,Category.COST_OMR_WATER,money,start,end,true)/waterUsageAnnualSavings), Table.FACTOR,
												 analysis.getAmount(alt,Category.COST_OMR_WATER,money,start,end,true), money); }
			// water disposal
			if(waterDisposalSavings==0.0){}  // do nothing
			else{
				   desc.addRow(level+1, "Water Disposal", Table.ROWHEADING,
                         waterDisposalAnnualSavings/waterDisposalSavings, Units.USUNIT,
                         waterDisposalSavings, Units.MGAL,
                         waterDisposalAnnualSavings, money,
                         waterDisposalAnnualSavings==0.0 ? 0.0 : (analysis.getAmount(alt,Category.COST_OMR_WATERDISPOSAL,money,start,end,true)/waterDisposalAnnualSavings), Table.FACTOR,
												 analysis.getAmount(alt,Category.COST_OMR_WATERDISPOSAL,money,start,end,true), money); }

			// subtotal - water
			desc.addRow(level+1, "Water Subtotal", Table.ROWHEADING,
                           " ", Table.COLHEADING,
                           waterUsageSavings + waterDisposalSavings, Units.MGAL,
                           waterUsageAnnualSavings + waterDisposalAnnualSavings, money,
                           " ", Table.COLHEADING,
                           analysis.getAmount(alt,Category.COST_OMR_WATER,money,start,end,true)+analysis.getAmount(alt,Category.COST_OMR_WATERDISPOSAL,money,start,end,true), money);

			 desc.addRow(0,"",Table.COLHEADING);

			// total
			totalAnnualEnergyAndWater = totalFuelAnnual+totalFuelDemand+totalUtilityRebate+waterUsageAnnualSavings + waterDisposalAnnualSavings;
			totalDiscountedEnergyAndWater=analysis.getAmount(alt,Category.COST_OMR_ENERGY,money,start,end,true)+
											analysis.getAmount(alt,Category.COST_OMR_WATER,money,start,end,true)+
											analysis.getAmount(alt,Category.COST_OMR_WATERDISPOSAL,money,start,end,true);

			desc.addRow(level+1, "Total", Table.ROWHEADING,
                            " ", Table.ROWHEADING,
                            " ", Table.ROWHEADING,
                            totalAnnualEnergyAndWater,money,
								            " ", Table.ROWHEADING,
                            totalDiscountedEnergyAndWater, money);

			desc.addRow(0,"",Table.COLHEADING);
		  desc.format(formatter);}

   public void describeNonEnergy(Alternative alt, Date start, Date service, Date end, double length, int level){
			totalAnnualNonRecurring=0.0;
			formatter.header(5,"3.  Non-Energy Savings (+) or Cost (-)");
			Table desc = new Table(5);
			desc.addRow(level+1,  "Item", Table.COLHEADING, "Savings/Cost", Table.COLHEADING,
		  											 "Occurrence", Table.COLHEADING, "Discount Factor", Table.COLHEADING, "Discounted Savings/Cost", Table.COLHEADING);
			for(Enumeration e=alt.enumerateCapitalComponents(); e.hasMoreElements(); ){
        CapitalComponent comp = (CapitalComponent) e.nextElement();

			double discountRate = comp.getProject().getDiscountRate();

			for(Enumeration c = comp.enumerateRecurringCosts(); c.hasMoreElements(); ){
        RecurringCost cost = (RecurringCost) c.nextElement();
				totalAnnualRecurring+=cost.getAmount();}

				if(totalAnnualRecurring==0.0){}  // do nothing
				else{
				  desc.addRow(level+1, "Annually Recurring", Table.ROWHEADING,
													     totalAnnualRecurring, money,
														   "Annual", Table.CENTER,
														   analysis.getAmount(comp,Category.COST_OMR_RECURRING,money,start,end,true)/totalAnnualRecurring, Table.FACTOR,
														   analysis.getAmount(comp,Category.COST_OMR_RECURRING,money,start,end,true), money);}

      desc.addRow(0,"",Table.COLHEADING);

			double spv=0.0;

		  desc.addRow(level+1, "Non-Annually Recurring", Table.ROWHEADING,
													   "", Table.CENTER,
														 "",Table.CENTER,
													   "", Table.CENTER,
														 "",Table.CENTER);

			for(Enumeration c = comp.enumerateNonRecurringCosts(); c.hasMoreElements(); ){
        NonRecurringCost cost = (NonRecurringCost) c.nextElement();
				if (cost.getAmount()==0.0){} // do nothing
				else{
					 escalatedNARCAmount = cost.getEscalation().escalate(cost.getAmount(), cost.getStartDate());  // asr 3-11-09:  need escalated amount
                                         totalAnnualNonRecurring+=escalatedNARCAmount;
					 spv = 1/ Math.pow(1+discountRate, DateDiff.diffInYears(start, cost.getStartDate()));   // asr 3-11-09:  need the time between the base date and start of cost
				   desc.addRow(level+1, cost.getName(), Table.ROWHEADING,
														    escalatedNARCAmount, money,
														    cost.getStart(), Table.CENTER,
														    spv, Table.FACTOR,
														    escalatedNARCAmount*spv, money); }}

				desc.addRow(level+1, "Non-Annually Recurring Subtotal", Table.ROWHEADING,
													     totalAnnualNonRecurring, money,
														   " ", Table.CENTER,
														   " ", Table.CENTER,
														   analysis.getAmount(comp,Category.COST_OMR_NONRECURRING,money,start,end,true), money);
       desc.addRow(0,"",Table.COLHEADING);

			 totalDiscountedNonEnergy= analysis.getAmount(comp,Category.COST_OMR_RECURRING,money,start,end,true)+analysis.getAmount(comp,Category.COST_OMR_NONRECURRING,money,start,end,true);

			 desc.addRow(level+1, "Total", Table.ROWHEADING,
													     totalAnnualRecurring+totalAnnualNonRecurring, money,
														   " ", Table.CENTER,
														   " ", Table.CENTER,
														   totalDiscountedNonEnergy, money);
	   }

	 desc.addRow(0,"",Table.COLHEADING);
		desc.format(formatter);}



   public void describeRemainingSections(Date start, Date end, int level){

			double len = DateDiff.diffInYears(start,end);
			double firstYearSavings = totalAnnualEnergyAndWater + totalAnnualRecurring + (totalAnnualNonRecurring/len);
			double totalDiscountedSavings = totalDiscountedEnergyAndWater + totalDiscountedNonEnergy;
			double sir = totalDiscountedSavings/totalInvestment;
			double airr = (1+project.getDiscountRate()) * Math.pow(sir,1/len) - 1;

			DecimalFormat yearsFormat = new java.text.DecimalFormat("#0.00");


			Table desc = new Table(3);
			desc.addRow(level+1, "4.  First year savings", Table.BOLD,
									firstYearSavings, money, "", Table.ROWHEADING);
			desc.addRow(level+1, "5.  Simple Payback Period (in years)", Table.BOLD,
									totalInvestment/firstYearSavings, yearsFormat, "(total investment/first-year savings)", Table.NORMAL );
			desc.addRow(level+1, "6.  Total Discounted Operational Savings", Table.BOLD,
			            totalDiscountedSavings, money, "", Table.NORMAL);
			desc.addRow(level+1, "7.  Savings to Investment Ratio (SIR)", Table.BOLD,
			            sir, Table.SIR, "(total discounted operational savings/total investment)", Table.NORMAL);
			desc.addRow(level+1, "8.  Adjusted Internal Rate of Return (AIRR)", Table.BOLD,
			            airr, Table.AIRR, "(1+d)*SIR^(1/n)-1; d=discount rate, n=years in study period", Table.NORMAL);


	 desc.addRow(0,"",Table.COLHEADING);
		desc.format(formatter);}






}
