package blcc.reports;

import java.io.PrintWriter;
import java.text.NumberFormat;

public class HTMLFormatter extends Formatter {
  PrintWriter out;

  public HTMLFormatter() {
    this(new PrintWriter(System.out,true)); }

  public HTMLFormatter(PrintWriter outstream){
    out = outstream;
    out.println("<HTML><HEAD><TITLE>BLCC Report</TITLE>");
    out.println("</HEAD><BODY>");
  }

//  public String img(String file, String attribs){
  // return "<IMG SRC=\""+getClass().getResource(file)+"\" "+attribs+">"; }

  public java.net.URL getStyleSheet(){
    return getClass().getResource("style.css"); }

  public void close(){
    out.println("</BODY></HTML>");
    out.close();
  }
  public void header(int level, String text) {
    out.println("<H"+level+">"+text+"</H"+level+">"); }

  public void line(String text) {
    out.println(text); }

  public void paragraph(String text) {
    // Need to add line Wrapping here.
    out.println("<P>"+text+"</P>"); }

   public String spaces(){
    return "&nbsp;&nbsp;&nbsp;";}

  // Table formatting
  public void formatTableStart(){
    out.println("<TABLE cellpadding='3'>"); }

  public void formatTableEnd() {
    out.println("</TABLE>");}

  int nextindent=0;
  public void formatTableRowStart(int indent){
    nextindent=indent;
    out.print("<TR>"); }

  public void formatTableRowEnd(){
    out.println("</TR>"); }

  final int CHARWIDTH=6;
  public void formatTableCol(int col, int width, String data, Object format){
    String tag = "TD";
    if((format == Table.COLHEADING) || (format == Table.ROWHEADING)) tag = "TH";
    if (format == Table.COLSPANHEADING)tag = "TH COLSPAN='3'";
    int attr = 0;
    if(format instanceof Integer) attr = ((Integer) format).intValue();
    String align = "";
    String s1="",s2="";
    if(nextindent>0) nextindent=0;

    switch (attr & 0xF){
    case 0x0: align = " ALIGN='LEFT'"; break;
    case 0x1: align = " ALIGN='RIGHT'"; break;
    case 0x2: align = " ALIGN='CENTER'"; break;
    case 0x3:
      align = " ALIGN='RIGHT' VALIGN='MIDDLE'";
      data = "------------";
      break; }
    switch (attr & 0xF0){
    case 0x00 : break;
    case 0x10 : s1="<EM>"; s2="</EM>"; break;
    case 0x20 : s1="<B>"; s2="</B>"; break;
      //    case TT     : s1="<CODE>"; s2="</CODE>"; break;
    }

    out.println("<"+tag+align+">"+s1+data+s2+"</"+tag+">");
  }
}
