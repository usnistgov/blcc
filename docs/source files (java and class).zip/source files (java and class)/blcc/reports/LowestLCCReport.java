package blcc.reports;


import blcc.model.Alternative;
import blcc.model.Project;
import blcc.model.CapitalComponent;
import blcc.model.EnergyUsage;
import blcc.model.WaterUsage;
import blcc.model.ModelElement;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.DecimalFormat;
import java.util.Enumeration;
import java.util.Vector;


public class LowestLCCReport {
  Analysis analysis;
  Formatter formatter;
  Project project;
  String fileName;

public LowestLCCReport(Analysis analysis, Formatter formatter, Project project, String fileName){
 this.analysis = analysis;
 this.formatter = formatter;
 this.project = project;
 this.fileName = fileName;}


public void report(){
  Date start    = analysis.getBaseDate();
  Date service  = analysis.getServiceDate();
  Date end      = analysis.getEndDate();
  Units money   = analysis.getMonetaryUnits();
  Vector alts;
  double lowestLCC;


  alts = new Vector();
  for (Enumeration enum1 = project.enumerateAlternatives(); enum1.hasMoreElements();) {
    alts.addElement((Alternative)enum1.nextElement());}

  // sort by initial and find lowest LCC
  Alternative temp;
  boolean sorted=false;
  int m =alts.size()-1;
  double amount1=0.0;
  double amount2=0.0;

  for (int i=m; i>0; i--){
  sorted = true;
  for (int j=0; j<m; j++){
    amount1  = analysis.getAmount((Alternative)alts.elementAt(j),Category.COST_CAPITAL_INITIAL,money,start,end,true);
    amount2  = analysis.getAmount((Alternative)alts.elementAt(j+1),Category.COST_CAPITAL_INITIAL,money,start,end,true);
   if (amount1 > amount2){
   temp = ((Alternative)alts.elementAt(j));
   alts.setElementAt(alts.elementAt(j+1), j);
   alts.setElementAt(temp, j+1);
    sorted = false;}
  }
 if (sorted)
  break;
}
 double newLCC;
//once sorted by initial, find lowest lcc
lowestLCC=analysis.getAmount((Alternative)alts.elementAt(0),Category.COST,money,start,end,true);  // initialize lcc
for(int i=0; i<alts.size();i++){
  newLCC=analysis.getAmount((Alternative)alts.elementAt(i),Category.COST,money,start,end,true);
 if(newLCC < lowestLCC)
  lowestLCC=newLCC;
}

  formatter.header(1,"NIST BLCC " + blcc.util.Defaults.getStringItem("version") + ":  Lowest LCC");
		if( project.getAnalysisType() ==Project.OMBANALYSIS || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS){
			formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology in OMB Circular A-94");}
		else{
    formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology and Procedures, 10 CFR, Part 436, Subpart A");}
  formatter.header(0,"");
  describeProject(project,0).format(formatter);

  formatter.header(2,"Lowest LCC");
  formatter.header(4,"Comparative Present-Value Costs of Alternatives");
  formatter.header(4,"(Shown in Ascending Order of Initial Cost, * = Lowest LCC)");
  Table tab1=new Table(4);
  tab1.addRow(0,"Alternative",Table.ROWHEADING,
                "Initial Cost (PV)",Table.COLHEADING,
                "Life Cycle Cost (PV)",Table.COLHEADING,
                "",Table.COLHEADING);
  String junk="";

  for(Enumeration e=alts.elements(); e.hasMoreElements(); ){
    Alternative alt = (Alternative) e.nextElement();
    double lifecycle=analysis.getAmount(alt,Category.COST,money,start,end,true);
    if(lifecycle==lowestLCC) junk="*"; else junk="";

    tab1.addRow(1, alt.getName(),Table.ROWHEADING,analysis.getAmount(alt,Category.COST_CAPITAL_INITIAL,money, start,end,true),
                money,lifecycle,money,
                junk, Table.COLHEADING);}
    tab1.format(formatter);
  }
  /* ______________________________________________________________________
     Project Description */

  public Table describeProject(Project project, int level){
    Table desc = new Table(2);
    formatter.header(2,"General Information");
    desc.addRow(level+1,"File Name:",Table.ROWHEADING,
                fileName,Table.RIGHT);
    desc.addRow(level+1,"Date of Study:",Table.ROWHEADING,
                new java.util.Date(),Table.RIGHT);
    desc.addRow(level+1,"Analysis Type:",Table.ROWHEADING,
                Project.analysisNames[project.getAnalysisType()],Table.RIGHT);
		if (project.getAnalysisType() == Project.OMBANALYSIS) {
			desc.addRow(level+1,"Analysis Purpose:", Table.ROWHEADING,
								Project.analysisPurposes[project.getAnalysisPurpose()],Table.RIGHT);
		}
    desc.addRow(level+1, "Project Name:", Table.ROWHEADING,
                project.getName(), Table.RIGHT);
    desc.addRow(level+1,"Project Location:",Table.ROWHEADING,
                project.getLocation(),Table.RIGHT);
    desc.addRow(level+1,"Analyst:",Table.ROWHEADING,
                project.getAnalyst(),Table.RIGHT);
    showComment(desc,level+1,project);
    desc.addRow(level+1,"Base Date:",Table.ROWHEADING,
                project.getBaseDate(),Table.RIGHT);
    if(project.getAnalysisType() == Project.AGENCYFUNDEDANALYSIS)
     desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    else if(project.getAnalysisType() == Project.OMBANALYSIS)
     desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
     else if (project.getAnalysisType()==Project.MILCONENERGYANALYSIS || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS)
      desc.addRow(level+1,"Beneficial Occupancy Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    String junk = project.getDuration() + " (" + project.getBaseDate() + " through " + project.getEndDate() + ")";
    desc.addRow(level+1,"Study Period:",Table.ROWHEADING,
                junk,Table.RIGHT);
    desc.addRow(level+1,"Discount Rate:",Table.ROWHEADING,
                project.getDiscountRate(),Table.RATE);
    desc.addRow(level+1,"Discounting Convention:",Table.ROWHEADING,
              Project.discountingMethodNames[project.getDiscountingMethod()],
              Table.RIGHT);
    desc.addRow(0,"",Table.COLHEADING);
    return desc; }



 public void showComment(Table desc, int level, ModelElement element){
    String comment = element.getComment();
    if(comment!=null && !comment.equals(""))
      desc.addRow(level,"Comment:",Table.ROWHEADING,comment,Table.RIGHT); }
}











