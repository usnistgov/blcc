package blcc.reports;


import blcc.model.Alternative;
import blcc.model.Project;
import blcc.model.CapitalComponent;
import blcc.model.EnergyUsage;
import blcc.model.WaterUsage;
import blcc.model.ModelElement;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.DecimalFormat;
import java.util.Enumeration;


public class SummaryReport {
  Analysis analysis;
  Formatter formatter;
  Project project;
  String fileName;

  public SummaryReport(Analysis analysis, Formatter formatter, Project project, String fileName){
    this.analysis = analysis;
    this.formatter = formatter;
    this.project = project;
    this.fileName = fileName;}


  public void report(){
    Date start    = analysis.getBaseDate();
    Date service  = analysis.getServiceDate();
    Date end      = analysis.getEndDate();
    double CRF    = analysis.getCapitalRecoveryFactor();
    double length = DateDiff.diffInYears(service,end);
    Units money   = analysis.getMonetaryUnits();
    int analysisType = project.getAnalysisType();


		//System.out.println("CRF: "+CRF);
    formatter.header(1,"NIST BLCC " + blcc.util.Defaults.getStringItem("version") + ": Summary LCC");
    formatter.header(0,"");
		if( analysisType ==Project.OMBANALYSIS || analysisType==Project.MILCONNONENERGYANALYSIS){
			formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology in OMB Circular A-94");}
		else{
    formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology and Procedures, 10 CFR, Part 436, Subpart A");}

    describeProject(project,0).format(formatter);


    for(Enumeration e=analysis.enumerateAlternatives(); e.hasMoreElements(); ){
      Alternative alt = (Alternative) e.nextElement();
      formatter.header(1,"Alternative: "+alt.getName());

      formatter.header(3,"LCC Summary");
      Table tab1=new Table(3);
      tab1.addRow(0,"",Table.ROWHEADING,
                  "Present Value",Table.COLHEADING,
                  "Annual Value",Table.COLHEADING);


      double cap,econsump,erebate,edemand,re,disp=0,repdisp,capdisp,wu,wd,lcc,ar,nr,res,nrcont=0,rcont=0;

      if(analysisType == Project.AGENCYFUNDEDANALYSIS)
        tab1.addRow(0,"Initial Cost",Table.ROWHEADING,
        cap = analysis.getAmount(alt,Category.COST_CAPITAL_INITIAL,money, start,end,true), money, cap*CRF, money);
      else
        tab1.addRow(0,"Initial Cost Paid By Agency",Table.ROWHEADING,
        cap = analysis.getAmount(alt,Category.COST_CAPITAL_INITIAL,money, start,end,true), money, cap*CRF, money);

      if(analysisType==Project.FINANCEDANALYSIS){
      tab1.addRow(1,"Annually Recurring Contract Costs", Table.ROWHEADING,
          rcont=analysis.getAmount(alt,Category.COST_CONTRACT_RECURRING,money,start,end,true),money, rcont*CRF, money);
      tab1.addRow(1,"Non-Annually Recurring Contract Costs", Table.ROWHEADING,
          nrcont=analysis.getAmount(alt,Category.COST_CONTRACT_NONRECURRING,money,start,end,true),money, nrcont*CRF, money);}

      tab1.addRow(1,"Energy Consumption Costs",Table.ROWHEADING,
          econsump = analysis.getAmount(alt,Category.COST_OMR_ENERGY_CONSUMPTION,money,
                                          start,end,true),money,econsump*CRF,money);
      tab1.addRow(1,"Energy Demand Costs",Table.ROWHEADING,
          edemand = analysis.getAmount(alt,Category.COST_OMR_ENERGY_DEMAND,money,
                                          start,end,true),money,edemand*CRF,money);
      tab1.addRow(1,"Energy Utility Rebates",Table.ROWHEADING,
          erebate = analysis.getAmount(alt,Category.COST_OMR_ENERGY_REBATE,money,
                                          start,end,true),money,erebate*CRF,money);
      tab1.addRow(1,"Water Usage Costs",Table.ROWHEADING,
          wu = analysis.getAmount(alt,Category.COST_OMR_WATER,money,
                                          start,end,true),money,wu*CRF,money);
      tab1.addRow(1,"Water Disposal Costs",Table.ROWHEADING,
          wd = analysis.getAmount(alt,Category.COST_OMR_WATERDISPOSAL,money,
                                          start,end,true),money,wd*CRF,money);

      String prefix1 = "", prefix2="";
      if(analysisType==Project.MILCONENERGYANALYSIS || analysisType==Project.MILCONNONENERGYANALYSIS){
        prefix1="Routine ";
        prefix2="Major Repair and ";}

      tab1.addRow(1,prefix1+"Annually Recurring OM&R Costs", Table.ROWHEADING,
         ar = analysis.getAmount(alt,Category.COST_OMR_RECURRING,money,start,end,true), money, ar*CRF, money);
      tab1.addRow(1,prefix1+"Non-Annually Recurring OM&R Costs", Table.ROWHEADING,
          nr = analysis.getAmount(alt,Category.COST_OMR_NONRECURRING,money,start,end,true), money, nr*CRF, money);
      tab1.addRow(1,prefix2+"Replacement Costs",Table.ROWHEADING,
          re = analysis.getAmount(alt,Category.COST_CAPITAL_REPLACEMENT,money,start,end,true),money,re*CRF,money);
          repdisp = analysis.getAmount(alt,Category.COST_CAPITAL_REPLACEMENT_RESIDUAL,money,start,end,true);

      capdisp = analysis.getAmount(alt,Category.COST_CAPITAL_RESIDUAL,money,start,end,true);
      tab1.addRow(1,"Less Remaining Value",Table.ROWHEADING,
          disp = capdisp+repdisp,money,disp*CRF,money);
      tab1.addRow(1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL);
      tab1.addRow(0,"Total Life-Cycle Cost",Table.BOLD,
                  lcc=cap+ar+nr+econsump+erebate+edemand+wu+wd+rcont+nrcont+re +disp,money,
                  lcc*CRF,money);
      tab1.addRow(0,"",Table.COLHEADING);
      tab1.format(formatter);
          }
  }
  /* ______________________________________________________________________
     Project Description */

  public Table describeProject(Project project, int level){
    Table desc = new Table(2);
    formatter.header(2,"General Information");
    desc.addRow(level+1,"File Name:",Table.ROWHEADING,
                fileName,Table.RIGHT);
    desc.addRow(level+1,"Date of Study:",Table.ROWHEADING,
                new java.util.Date(),Table.RIGHT);
    desc.addRow(level+1,"Analysis Type:",Table.ROWHEADING,
                Project.analysisNames[project.getAnalysisType()],Table.RIGHT);
		if (project.getAnalysisType() == Project.OMBANALYSIS) {
			desc.addRow(level+1,"Analysis Purpose:", Table.ROWHEADING,
								Project.analysisPurposes[project.getAnalysisPurpose()],Table.RIGHT);
		}
    desc.addRow(level+1, "Project Name:", Table.ROWHEADING,
                project.getName(), Table.RIGHT);
    desc.addRow(level+1,"Project Location:",Table.ROWHEADING,
                project.getLocation(),Table.RIGHT);
    desc.addRow(level+1,"Analyst:",Table.ROWHEADING,
                project.getAnalyst(),Table.RIGHT);
    showComment(desc,level+1,project);
    desc.addRow(level+1,"Base Date:",Table.ROWHEADING,
                project.getBaseDate(),Table.RIGHT);
    if(project.getAnalysisType() == Project.AGENCYFUNDEDANALYSIS)
      desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    else if(project.getAnalysisType() == Project.OMBANALYSIS)
      desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    else if (project.getAnalysisType()==Project.MILCONENERGYANALYSIS || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS)
       desc.addRow(level+1,"Beneficial Occupancy Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    String junk = project.getDuration() + " (" + project.getBaseDate() + " through " + project.getEndDate() + ")";
    desc.addRow(level+1,"Study Period:",Table.ROWHEADING,
                junk,Table.RIGHT);
    desc.addRow(level+1,"Discount Rate:",Table.ROWHEADING,
                project.getDiscountRate(),Table.RATE);
    desc.addRow(level+1,"Discounting Convention:",Table.ROWHEADING,
              Project.discountingMethodNames[project.getDiscountingMethod()],
              Table.RIGHT);
    String junkline;
     if(project.getDollarMethod() == Project.CONSTANTDOLLARMETHOD)
      junkline="REAL (exclusive";
    else
      junkline="NOMINAL (inclusive";
    desc.addRow(level+1,"Discount and Escalation Rates are "+ junkline + " of general inflation)",Table.COLSPANHEADING);
    desc.addRow(0,"",Table.COLHEADING);
    return desc; }

 public void showComment(Table desc, int level, ModelElement element){
    String comment = element.getComment();
    if(comment!=null && !comment.equals(""))
      desc.addRow(level,"Comment:",Table.ROWHEADING,comment,Table.RIGHT); }




}

