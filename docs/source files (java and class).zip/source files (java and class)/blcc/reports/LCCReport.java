package blcc.reports;


import blcc.model.Alternative;
import blcc.model.Project;
import blcc.model.CapitalComponent;
import blcc.model.EnergyUsage;
import blcc.model.WaterUsage;
import blcc.model.ModelElement;
import blcc.model.Escalation;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.model.PhaseIn;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.DecimalFormat;
import java.util.Enumeration;


public class LCCReport {
  Analysis analysis;
  Formatter formatter;
  Project project;
  String fileName;
  double cap,omr=0,en=0,enconsump,enrebate,endemand,rep=0,re,capdisp=0,wu,wd,lcc,ar,nr,cont=0,nrcont,rcont,capres,repres,repdisp=0;

  Date start, service, end;
  double CRF, length;
  Units money;
  int analysisType;



  public LCCReport(Analysis analysis, Formatter formatter, Project project, String fileName){
    this.analysis = analysis;
    this.formatter = formatter;
    this.project = project;
    this.fileName = (fileName==null?" ":fileName);}


  public void report(){
    start    = analysis.getBaseDate();
    service  = analysis.getServiceDate();
    end      = analysis.getEndDate();
    CRF    = analysis.getCapitalRecoveryFactor();
    length = DateDiff.diffInYears(service,end);
    money   = analysis.getMonetaryUnits();
    analysisType = project.getAnalysisType();


    formatter.header(1,"NIST BLCC " + blcc.util.Defaults.getStringItem("version") + ":  Detailed LCC Analysis");
    if( analysisType ==Project.OMBANALYSIS || analysisType ==Project.MILCONNONENERGYANALYSIS){
			formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology in OMB Circular A-94");}
		else{
    formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology and Procedures, 10 CFR, Part 436, Subpart A");}
    formatter.header(0,"");
    describeProject(project,0).format(formatter);


    for(Enumeration e=analysis.enumerateAlternatives(); e.hasMoreElements(); ){
      Alternative alt = (Alternative) e.nextElement();
      formatter.header(1,"Alternative: "+alt.getName());
      formatter.header(0,"");
      describeInitial(alt,0);

      formatter.header(2,"Life-Cycle Cost Analysis");
      Table tab1=new Table(3);
      tab1.addRow(0,"",Table.ROWHEADING,
                  "Present Value",Table.COLHEADING,
                  "Annual Value",Table.COLHEADING);

      initialLCC(alt, tab1);
      if(analysisType==Project.FINANCEDANALYSIS){ contractLCC(alt, tab1); }
      energyLCC(alt, tab1);
      waterLCC(alt, tab1);
      omrLCC(alt, tab1);
      replacementLCC(alt, tab1);
      residualLCC(alt, tab1);
      replacementResidualLCC(alt, tab1);


      tab1.addRow(0,"Total Life-Cycle Cost",Table.BOLD,
                  lcc=cap+omr+en+wu+wd+rep+cont +capdisp+repdisp,money,
                  lcc*CRF,money);
      tab1.addRow(0,"",Table.COLHEADING);
      tab1.format(formatter);

      emissionsSummary(alt);


    }
  }
  /* ______________________________________________________________________
     Project Description */

  public Table describeProject(Project project, int level){
    Table desc = new Table(2);
    formatter.header(2,"General Information");
    desc.addRow(level+1,"File Name:",Table.ROWHEADING,
                fileName,Table.RIGHT);
    desc.addRow(level+1,"Date of Study:",Table.ROWHEADING,
                new java.util.Date(),Table.RIGHT);
    desc.addRow(level+1,"Analysis Type:",Table.ROWHEADING,
                Project.analysisNames[analysisType],Table.RIGHT);
		if (analysisType == Project.OMBANALYSIS) {
			desc.addRow(level+1,"Analysis Purpose:", Table.ROWHEADING,
								Project.analysisPurposes[project.getAnalysisPurpose()],Table.RIGHT);
		}
    desc.addRow(level+1, "Project Name:", Table.ROWHEADING,
                project.getName(), Table.RIGHT);
    desc.addRow(level+1,"Project Location:",Table.ROWHEADING,
                project.getLocation(),Table.RIGHT);
    desc.addRow(level+1,"Analyst:",Table.ROWHEADING,
                project.getAnalyst(),Table.RIGHT);
    showComment(desc,level+1,project);
    desc.addRow(level+1,"Base Date:",Table.ROWHEADING,
                project.getBaseDate(),Table.RIGHT);
    if(analysisType == Project.AGENCYFUNDEDANALYSIS)
     desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    else if(analysisType == Project.OMBANALYSIS)
     desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    else if (analysisType==Project.MILCONENERGYANALYSIS || analysisType==Project.MILCONNONENERGYANALYSIS)
      desc.addRow(level+1,"Beneficial Occupancy Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    String junk = project.getDuration() + " (" + project.getBaseDate() + " through " + project.getEndDate() + ")";
    desc.addRow(level+1,"Study Period:",Table.ROWHEADING,
                junk,Table.RIGHT);
    desc.addRow(level+1,"Discount Rate:",Table.ROWHEADING,
                project.getDiscountRate(),Table.RATE);
    desc.addRow(level+1,"Discounting Convention:",Table.ROWHEADING,
              Project.discountingMethodNames[project.getDiscountingMethod()],
              Table.RIGHT);
    String junkline;
     if(project.getDollarMethod() == Project.CONSTANTDOLLARMETHOD)
      junkline="REAL (exclusive";
    else
      junkline="NOMINAL (inclusive";
    desc.addRow(level+1,"Discount and Escalation Rates are "+ junkline + " of general inflation)",Table.COLSPANHEADING);
    desc.addRow(0,"",Table.COLHEADING);
    return desc; }

  public void describeInitial(Alternative alt, int level){

    double initial, en;

    formatter.header(2,"Initial Cost Data (not Discounted)");
    formatter.header(0,"");
    String junk = "";
    if(analysisType == Project.FINANCEDANALYSIS)
       junk = " Paid By Agency";
    formatter.header(3,"Initial Capital Costs"+junk);
    formatter.header(5, "(adjusted for price escalation)");


    Table tab = new Table(2);
    tab.addRow(0,"Initial Capital Costs for All Components:",Table.ROWHEADING,
               analysis.getAmount(alt,Category.COST_CAPITAL_INITIAL,money,
                              start,end,false), money);
    tab.addRow(0,"",Table.COLHEADING);
    tab.format(formatter);

    for(Enumeration fe=alt.enumerateCapitalComponents(); fe.hasMoreElements(); ){
      CapitalComponent comp = (CapitalComponent) fe.nextElement();
      formatter.header(4,"Component:  " + comp.getName());
      Table phaseIn = new Table(3);
      describePhaseIn(comp,phaseIn,level+1,money);
      phaseIn.format(formatter);}

    if(analysisType == Project.FINANCEDANALYSIS){
     formatter.header(3,"Initial Capital Costs Financed");
     formatter.header(5, "(base-year dollars)");
     Table tab2 = new Table(2);
     tab2.addRow(0,"Initial Capital Costs for All Components:",Table.ROWHEADING,
               analysis.getAmount(alt,Category.AMOUNT_FINANCED,money,
                              start,end,false), money);
      tab2.addRow(0,"",Table.COLHEADING);
      tab2.format(formatter);
     for(Enumeration fe=alt.enumerateCapitalComponents(); fe.hasMoreElements(); ){
      CapitalComponent comp = (CapitalComponent) fe.nextElement();
      formatter.header(4,"Component:  " + comp.getName());
      Table financed = new Table(2);
      financed.addRow(0,"Initial Cost Financed",Table.ROWHEADING,
               analysis.getAmount(comp,Category.AMOUNT_FINANCED,money,
                              start,end,false), money);
      financed.addRow(0,"",Table.COLHEADING);
      financed.format(formatter);}}

   double usage=0.0;
   for(Enumeration e=alt.enumerateEnergyUsages(); e.hasMoreElements(); ) {
     Table tab2 = new Table(5);
     tab2.addRow(0,"Average", Table.COLHEADING,
                "", Table.COLHEADING,
                "Average", Table.COLHEADING,
                "Average", Table.COLHEADING,
                "Average", Table.COLHEADING);
     tab2.addRow(0,"Annual Usage", Table.COLHEADING,
                "Price/Unit", Table.COLHEADING,
                "Annual Cost", Table.COLHEADING,
                "Annual Demand", Table.COLHEADING,
                "Annual Rebate", Table.COLHEADING);

      EnergyUsage energy = (EnergyUsage) e.nextElement();
      formatter.header(3, "Energy Costs:  " + energy.getName());
      formatter.header(5, "(base-year dollars)");
      blcc.model.UsageIndex index = energy.getUsageIndex();
       usage=index.indexedAmount(energy.getYearlyUsage(),service,end);
       tab2.addRow(level+1, usage, energy.getUnits(),
                  energy.getUnitCost(),energy.getUnitCostMonetaryUnits(),
                  energy.getUnitCost() * usage, money,
                  index.indexedAmount(energy.getDemandCharge(),service,end), money,
                  index.indexedAmount(energy.getUtilityRebate(),service,end), money);
      tab2.addRow(0,"",Table.COLHEADING);
      tab2.format(formatter);}

    Units units;
    Units unitCost;
    for(Enumeration e=alt.enumerateWaterUsages(); e.hasMoreElements(); ) {
      Table tab3 = new Table(6);
      tab3.addRow(0,"",Table.ROWHEADING,
                    "Average Annual Usage",Table.COLSPANHEADING,
                    "Average Annual Disposal", Table.COLSPANHEADING,
                    "Average Annual", Table.ROWHEADING );
     tab3.addRow(0,"Water",Table.ROWHEADING,
                    "Units/Year",Table.COLHEADING,
                    "Price/Unit", Table.COLHEADING,
                    "Units/Year",Table.COLHEADING,
                    "Price/Unit", Table.COLHEADING,
                    "Cost", Table.COLHEADING );

      WaterUsage water = (WaterUsage) e.nextElement();
      units = water.getUnits();
      blcc.model.UsageIndex index = water.getUsageIndex();
      unitCost=water.getUnitCostMonetaryUnits();

      double use1, use2, cost1, cost2;

      formatter.header(3, "Water Costs:  " + water.getName());
      formatter.header(5, "(base-year dollars)");
      tab3.addRow(level+1, "@ Summer Rates", Table.ROWHEADING,
                  use1=index.indexedAmount(water.getSummerYearlyUsage(),service,end),units,
                  cost1=water.getSummerUsageUnitCost(), unitCost,
                  use2=index.indexedAmount(water.getSummerYearlyDisposal(),service,end), units,
                  cost2=water.getSummerDisposalUnitCost(), unitCost,
                  use1*cost1+use2*cost2, money);
       tab3.addRow(level+1, "@ Winter Rates", Table.ROWHEADING,
                  use1=index.indexedAmount(water.getWinterYearlyUsage(),service,end), units,
                  cost1=water.getWinterUsageUnitCost(),unitCost,
                  use2=index.indexedAmount(water.getWinterYearlyDisposal(),service,end),units,
                  cost2=water.getWinterDisposalUnitCost(),unitCost,
                  use1*cost1+use2*cost2,money);
      tab3.addRow(0,"",Table.COLHEADING);
      tab3.format(formatter);}

     }



 public void showComment(Table desc, int level, ModelElement element){
    String comment = element.getComment();
    if(comment!=null && !comment.equals(""))
      desc.addRow(level,"Comment:",Table.ROWHEADING,comment,Table.RIGHT); }

  /* ______________________________________________________________________
     PhaseIn Description */

   public void describePhaseIn(CapitalComponent comp, Table desc, int level,Units money){
    double amount;
    PhaseIn phaseIn = comp.getPhaseIn();
    double total=0.0;
    formatter.header(5,"Cost-Phasing");
    desc.addRow(level+1,"Date",Table.ROWHEADING,"Portion",Table.COLHEADING,"Yearly Cost",Table.COLHEADING);
    Date start = comp.getBaseDate();
    Date date;


    for(int i=0;i<phaseIn.getPortions().length;i++){
      date=phaseIn.getDate(i);
      desc.addRow(level+1, date, Table.ROWHEADING,
                  phaseIn.getPortion(i), Table.RATE,
                  amount=analysis.getAmount(comp,Category.COST_CAPITAL_INITIAL, money,start,date,false),
                  money);
      total+=amount;
      start=date.add(DateDiff.DAY); }

      desc.addRow(level+1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL);
      desc.addRow(level+1, "Total (for Component)", Table.ROWHEADING,
                  "", Table.COLHEADING,
                  total, money);
      desc.addRow(0,"",Table.COLHEADING);}

  /* ______________________________________________________________________
     Emissions Summary */

      public void emissionsSummary(Alternative alt){
       formatter.header(3,"Emissions Summary");
       Table tab2=new Table(3);
       tab2.addRow(0, "Energy Name", Table.ROWHEADING,
                     "Annual",Table.COLHEADING,
                     "Life-Cycle",Table.COLHEADING);
      double x;
     for(Enumeration emiss=alt.enumerateEnergyUsages(); emiss.hasMoreElements(); ) {
       EnergyUsage energy = (EnergyUsage) emiss.nextElement();
       tab2.addRow(0, energy.getName()+":", Table.ROWHEADING, "",Table.COLHEADING,"",Table.COLHEADING);
       x = analysis.getAmount(energy,Category.EMISSIONS_CO2,
                                    Units.KG,start,end,false);
      tab2.addRow(0,"CO2",Table.COLHEADING, x/length,Units.KG, x,Units.KG);
      x = analysis.getAmount(energy,Category.EMISSIONS_SOx,Units.KG,start,end,false);
      tab2.addRow(0,"SO2",Table.COLHEADING, x/length,Units.KG, x,Units.KG);
      x = analysis.getAmount(energy,Category.EMISSIONS_NOx,Units.KG,start,end,false);
      tab2.addRow(0,"NOx",Table.COLHEADING, x/length, Units.KG, x,Units.KG);}

      tab2.addRow(0, "Total:", Table.ROWHEADING, "",Table.COLHEADING,"",Table.COLHEADING);
      x = analysis.getAmount(alt,Category.EMISSIONS_CO2,Units.KG,start,end,false);
      tab2.addRow(0,"CO2",Table.COLHEADING, x/length,Units.KG, x,Units.KG);
      x = analysis.getAmount(alt,Category.EMISSIONS_SOx,Units.KG,start,end,false);
      tab2.addRow(0,"SO2",Table.COLHEADING, x/length,Units.KG, x,Units.KG);
      x = analysis.getAmount(alt,Category.EMISSIONS_NOx,Units.KG,start,end,false);
      tab2.addRow(0,"NOx",Table.COLHEADING, x/length, Units.KG, x,Units.KG);

      tab2.addRow(0,"",Table.COLHEADING);
      tab2.format(formatter);}

  /* ______________________________________________________________________
     Initial Cost */
     public void initialLCC(Alternative alt, Table tab){
      String junk = "";
       if(analysisType == Project.FINANCEDANALYSIS)
         junk = " Paid By Agency";

      tab.addRow(0,"Initial Capital Costs"+junk,Table.ROWHEADING,
            cap = analysis.getAmount(alt,Category.COST_CAPITAL_INITIAL,money,
                              start,end,true), money, cap*CRF, money);

       tab.addRow(0,"",Table.COLHEADING); }

  /* ______________________________________________________________________
     Contract Costs */
      public void contractLCC(Alternative alt, Table tab){

				tab.addRow(1,"Contract-Related Costs",Table.BOLD);
        rcont = analysis.getAmount(alt,Category.COST_CONTRACT_RECURRING,money,
              start,end,true);

         tab.addRow(1,formatter.spaces()+"Annually Recurring Contract Costs", Table.ROWHEADING,rcont,money, rcont*CRF, money);

          nrcont = analysis.getAmount(alt,Category.COST_CONTRACT_NONRECURRING,money,
              start,end,true);
         tab.addRow(1,formatter.spaces()+"Non-Annually Recurring Contract Costs", Table.ROWHEADING,nrcont,money, nrcont*CRF, money);
         cont=rcont+nrcont;
          tab.addRow(1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL);
          tab.addRow(1,formatter.spaces()+"Subtotal (for Contract):",Table.ROWHEADING,
                  cont,money,cont*CRF,money);

          tab.addRow(0,"",Table.COLHEADING); }

  /* ______________________________________________________________________
     Energy Costs */
      public void energyLCC(Alternative alt, Table tab){
       tab.addRow(1,"Energy Costs",Table.BOLD);
       tab.addRow(1,formatter.spaces()+"Energy Consumption Costs",Table.ROWHEADING,
                  enconsump = analysis.getAmount(alt,Category.COST_OMR_ENERGY_CONSUMPTION,money,
                                          start,end,true),money,enconsump*CRF,money);
       tab.addRow(1,formatter.spaces()+"Energy Demand Charges",Table.ROWHEADING,
                  endemand = analysis.getAmount(alt,Category.COST_OMR_ENERGY_DEMAND,money,
                                          start,end,true),money,endemand*CRF,money);
       tab.addRow(1,formatter.spaces()+"Energy Utility Rebates",Table.ROWHEADING,
                  enrebate = analysis.getAmount(alt,Category.COST_OMR_ENERGY_REBATE,money,
                                          start,end,true),money,enrebate*CRF,money);
      en = enconsump+endemand+enrebate;
      tab.addRow(1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL);
      tab.addRow(1,formatter.spaces()+"Subtotal (for Energy):",Table.ROWHEADING,
                  en,money,en*CRF,money);

      tab.addRow(0,"",Table.COLHEADING);}

  /* ______________________________________________________________________
     Water Costs */
       public void waterLCC(Alternative alt, Table tab){
         tab.addRow(1,"Water Usage Costs",Table.ROWHEADING,
                  wu = analysis.getAmount(alt,Category.COST_OMR_WATER,money,
                                          start,end,true),money,wu*CRF,money);
          tab.addRow(1,"Water Disposal Costs",Table.ROWHEADING,
                  wd = analysis.getAmount(alt,Category.COST_OMR_WATERDISPOSAL,money,
                                          start,end,true),money,wd*CRF,money);
          tab.addRow(0,"",Table.COLHEADING);}
  /* ______________________________________________________________________
     OM&R Costs */
      public void omrLCC(Alternative alt, Table tab){

			omr=0.0;
      String junk="";
      if(analysisType==Project.MILCONENERGYANALYSIS || analysisType==Project.MILCONNONENERGYANALYSIS){junk="Routine ";}

      tab.addRow(1,junk+"Operating, Maintenance & Repair Costs",Table.BOLD);
      for(Enumeration fe=alt.enumerateCapitalComponents(); fe.hasMoreElements(); ){
      CapitalComponent comp = (CapitalComponent) fe.nextElement();
      tab.addRow(1, formatter.spaces()+"Component: " + comp.getName(), Table.ROWHEADING);

			ar = analysis.getAmount(comp,Category.COST_OMR_RECURRING,money,
              start,end,true);
      nr = analysis.getAmount(comp,Category.COST_OMR_NONRECURRING,money,
              start,end,true);
      omr +=ar+nr;
      tab.addRow(1,formatter.spaces()+formatter.spaces()+junk+"Annually Recurring Costs", Table.ROWHEADING,ar,money, ar*CRF, money);
      tab.addRow(1,formatter.spaces()+formatter.spaces()+junk+"Non-Annually Recurring Costs", Table.ROWHEADING,nr,money, nr*CRF, money);}
      tab.addRow(1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL);
      tab.addRow(1,formatter.spaces()+"Subtotal (for OM&R):",Table.ROWHEADING,
                  omr,money,omr*CRF,money);
      tab.addRow(0,"",Table.COLHEADING); }

  /* ______________________________________________________________________
     Replacement Costs*/
      public void replacementLCC(Alternative alt, Table tab){
			rep=0.0;

       if(analysisType!=Project.MILCONENERGYANALYSIS && analysisType!=Project.MILCONNONENERGYANALYSIS){tab.addRow(0, "Replacements to Capital Components", Table.BOLD);}
       else{tab.addRow(0, "Major Repair and Replacements", Table.BOLD);}

       for(Enumeration fe=alt.enumerateCapitalComponents(); fe.hasMoreElements(); ){
         CapitalComponent comp = (CapitalComponent) fe.nextElement();
         re = analysis.getAmount(comp,Category.COST_CAPITAL_REPLACEMENT,money,
              start,end,true);
          rep+=re;
         tab.addRow(0,formatter.spaces()+"Component:  " + comp.getName(),Table.ROWHEADING,re,money, re*CRF, money);}
         tab.addRow(1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL);
         if(analysisType!=Project.MILCONENERGYANALYSIS && analysisType!=Project.MILCONNONENERGYANALYSIS){
         tab.addRow(1,formatter.spaces()+"Subtotal (for Replacements):",Table.ROWHEADING,
                  rep,money,rep*CRF,money);}
         else{
          tab.addRow(1,formatter.spaces()+"Subtotal (for Repair and Replacements):",Table.ROWHEADING,
                  rep,money,rep*CRF,money);}
         tab.addRow(0,"",Table.COLHEADING);}

  /* ______________________________________________________________________
     Residual Value of Capital Components */
      public void residualLCC(Alternative alt, Table tab){
				capdisp=0.0;
				tab.addRow(0,"Residual Value of Original Capital Components",Table.BOLD);
        for(Enumeration fe=alt.enumerateCapitalComponents(); fe.hasMoreElements(); ){
         CapitalComponent comp = (CapitalComponent) fe.nextElement();
         capres = analysis.getAmount(comp,Category.COST_CAPITAL_RESIDUAL,money,
              start,end,true);
         capdisp+=capres;
        tab.addRow(0,formatter.spaces()+"Component:  " + comp.getName(),Table.ROWHEADING,capres,money, capres*CRF, money);}
        tab.addRow(1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL);
        tab.addRow(1,formatter.spaces()+"Subtotal (for Residual Value):",Table.ROWHEADING,
                  capdisp,money,capdisp*CRF,money);
        tab.addRow(0,"",Table.COLHEADING);}
  /* ______________________________________________________________________
     Residual Value of Replacements */
      public void replacementResidualLCC(Alternative alt, Table tab){
				repdisp=0.0;
        if(analysisType!=Project.MILCONENERGYANALYSIS && analysisType!=Project.MILCONNONENERGYANALYSIS){tab.addRow(0,"Residual Value of Capital Replacements",Table.BOLD);}
        else {tab.addRow(0,"Residual Value of Major Repair and Replacements",Table.BOLD);}

        for(Enumeration fe=alt.enumerateCapitalComponents(); fe.hasMoreElements(); ){
         CapitalComponent comp = (CapitalComponent) fe.nextElement();
         repres = analysis.getAmount(comp,Category.COST_CAPITAL_REPLACEMENT_RESIDUAL,money,
              start,end,true);
          repdisp+=repres;
         tab.addRow(0,formatter.spaces()+"Component:  " + comp.getName(),Table.ROWHEADING,repres,money, repres*CRF, money);}
         tab.addRow(1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL);
         tab.addRow(1,formatter.spaces()+"Subtotal (for Residual Value):",Table.ROWHEADING,
                  repdisp,money,repdisp*CRF,money);
         tab.addRow(0,"",Table.COLHEADING);}


}

