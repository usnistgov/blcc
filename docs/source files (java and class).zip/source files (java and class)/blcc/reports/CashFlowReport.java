package blcc.reports;

import blcc.model.Alternative;
import blcc.model.Project;
import blcc.model.CapitalComponent;
import blcc.model.ModelElement;
import blcc.model.PhaseIn;
import blcc.model.Escalation;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.DecimalFormat;
import java.util.Enumeration;

public class CashFlowReport{
  Analysis analysis;
  Formatter formatter;
  Project project;
  String fileName;

  public CashFlowReport(Analysis analysis, Formatter fmt, Project project, String fileName){
    this.analysis = analysis;
    this.formatter = fmt;
    this.project = project;
    this.fileName = fileName;}

  public void report(){
    Date base     = analysis.getBaseDate();
    Date service  = analysis.getServiceDate();
    Date end      = analysis.getEndDate();
    Date timeline[] = DateDiff.timeline(base,service,end);
    Units money   = analysis.getMonetaryUnits();
    Category cats[];

		formatter.header(1, "NIST BLCC " + blcc.util.Defaults.getStringItem("version") + ": Cash Flow Analysis");
		if( project.getAnalysisType() ==Project.OMBANALYSIS || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS){
			formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology in OMB Circular A-94");}
		else{
    formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology and Procedures, 10 CFR, Part 436, Subpart A");}
    formatter.header(0,"");
    describeProject(project,0).format(formatter);


    for(Enumeration e=analysis.enumerateAlternatives(); e.hasMoreElements(); ){
      Alternative alt = (Alternative) e.nextElement();
      formatter.header(1,"Alternative: "+alt.getName());

    String junk = "";
    if(project.getAnalysisType() == Project.FINANCEDANALYSIS)
       junk = " Paid By Agency";

    formatter.header(3,"Initial Capital Costs" + junk);
    for(Enumeration fe=alt.enumerateCapitalComponents(); fe.hasMoreElements(); ){
      CapitalComponent comp = (CapitalComponent) fe.nextElement();
      formatter.header(4,"Component:  " + comp.getName());
      Table phaseIn = new Table(2);
      describePhaseIn(comp,phaseIn,2,money);
      phaseIn.format(formatter);}

      cats = analysis.contributingCategories(alt,Category.COST_CAPITAL.getSubCategories());
     if (cats != null){
	formatter.header(3,"Capital Investment Costs");
  formatter.flowTable(timeline, analysis.getAmount(alt,cats,money,timeline,false),
           Category.categoryNames(cats),money, true,true)
    .format(formatter); }

      cats = analysis.contributingCategories(alt,Category.COST_CONTRACT.getSubCategories());
      if (cats != null){
  formatter.header(3,"Contract Costs");
	formatter.flowTable(timeline,
			    analysis.getAmount(alt,cats,money,timeline,false),
			    Category.categoryNames(cats),money, true,true)
	  .format(formatter); }


      cats = analysis.contributingCategories(alt,Category.COST_OMR.getSubCategories());
      if (cats != null){
  formatter.header(3,"Operating-Related Costs");
	formatter.flowTable(timeline,
          analysis.getAmount(alt,cats,money,timeline,false),
          Category.categoryNames(cats),money, true,true)
	  .format(formatter); }


      cats = analysis.contributingCategories(alt,Category.COST.getSubCategories());
      formatter.header(3,"Sum of All Cash Flows");
      if (cats == null){
	formatter.header(4,"There were no transactions!"); }
      else {
          formatter.flowTable(timeline,
          analysis.getAmount(alt,cats,money,timeline,false),
          Category.categoryNames(cats),money, true,true)
	  .format(formatter); }
   formatter.header(0,"");}
  }

  /* ______________________________________________________________________
     Project Description */

  public Table describeProject(Project project, int level){
    Table desc = new Table(2);
    formatter.header(2,"General Information");
    desc.addRow(level+1,"File Name:",Table.ROWHEADING,
                fileName,Table.RIGHT);
    desc.addRow(level+1,"Date of Study:",Table.ROWHEADING,
                new java.util.Date(),Table.RIGHT);
    desc.addRow(level+1,"Analysis Type:",Table.ROWHEADING,
                Project.analysisNames[project.getAnalysisType()],Table.RIGHT);
		if (project.getAnalysisType() == Project.OMBANALYSIS) {
			desc.addRow(level+1,"Analysis Purpose:", Table.ROWHEADING,
								Project.analysisPurposes[project.getAnalysisPurpose()],Table.RIGHT);
		}
    desc.addRow(level+1, "Project Name:", Table.ROWHEADING,
                project.getName(), Table.RIGHT);
    desc.addRow(level+1,"Project Location:",Table.ROWHEADING,
                project.getLocation(),Table.RIGHT);
    desc.addRow(level+1,"Analyst:",Table.ROWHEADING,
                project.getAnalyst(),Table.RIGHT);
    showComment(desc,level+1,project);
    desc.addRow(level+1,"Base Date:",Table.ROWHEADING,
                project.getBaseDate(),Table.RIGHT);
    if(project.getAnalysisType() == Project.AGENCYFUNDEDANALYSIS)
      desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
		else if(project.getAnalysisType() == Project.OMBANALYSIS)
      desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
		else if (project.getAnalysisType()==Project.MILCONENERGYANALYSIS )
      desc.addRow(level+1,"Beneficial Occupancy Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
		else if (project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS )
      desc.addRow(level+1,"Beneficial Occupancy Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);

    String junk = project.getDuration() + " (" + project.getBaseDate() + " through " + project.getEndDate() + ")";
    desc.addRow(level+1,"Study Period:",Table.ROWHEADING,
                junk,Table.RIGHT);
    String junkline;
    if(project.getDiscountingMethod() == Project.ENDYEARDISCOUNTING)
     junkline="End-of-year";
    else
     junkline="Mid-year";
    desc.addRow(level+1, junkline+" cash-flow convention used", Table.COLSPANHEADING);
    if(project.getDollarMethod() == Project.CONSTANTDOLLARMETHOD)
      desc.addRow(level+1,"All costs in constant dollars (excluding general inflation)",Table.COLSPANHEADING);
    else
      desc.addRow(level+1,"All costs in current dollars (including general inflation)",Table.COLSPANHEADING);


    desc.addRow(0,"",Table.COLHEADING);
    return desc; }


 public void showComment(Table desc, int level, ModelElement element){
    String comment = element.getComment();
    if(comment!=null && !comment.equals(""))
      desc.addRow(level,"Comment:",Table.ROWHEADING,comment,Table.RIGHT); }

   public void describePhaseIn(CapitalComponent comp, Table desc, int level,Units money){
    double amount;
    PhaseIn phaseIn = comp.getPhaseIn();
    Escalation esc = comp.getEscalation();
    double initialCost = comp.getInitialCost();
    double total=0.0;

    desc.addRow(level+1,"Year Beginning",Table.ROWHEADING,"Total",Table.COLHEADING);
    for(int i=0;i<phaseIn.getPortions().length;i++){
      amount=esc.escalate(initialCost*phaseIn.getPortion(i),phaseIn.getDate(i));
      total+=amount;
      desc.addRow(level+1, phaseIn.getDate(i).formatAsMonth(), Table.ROWHEADING,
                  amount,money);}
      desc.addRow(level+1,"Total", Table.ROWHEADING, total, money);
      desc.addRow(0,"",Table.COLHEADING);}

}
