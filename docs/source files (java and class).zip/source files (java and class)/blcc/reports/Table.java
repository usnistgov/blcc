package blcc.reports;

import blcc.util.Units;
import java.text.Format;
import java.util.Vector;

public class Table {
  public final static Integer LEFT   = new Integer(0x0);
  public final static Integer RIGHT  = new Integer(0x1);
  public final static Integer CENTER = new Integer(0x2);
  public final static Integer FILL   = new Integer(0x3);
  public final static Integer POSMASK =new Integer(0xF);

  public final static Integer NORMAL = new Integer(0x00);
  public final static Integer ITALIC = new Integer(0x10);
  public final static Integer BOLD   = new Integer(0x20);
  public final static Integer TT     = new Integer(0x30);
  public final static Integer STYLEMASK=new Integer(0xF0);

  public final static Integer NUMBER = new Integer(0x31); // Right & TT
  public final static Integer COLHEADING = new Integer(0x2); // Centered
  public final static Integer ROWHEADING = new Integer(0x0); // Left.
  public final static Integer COLSPANHEADING = new Integer(0x2);  // spans 2 columns for now; centered
  public final static Format RATE   = new java.text.DecimalFormat("##.#%");
  public final static Format ESCALATION = new java.text.DecimalFormat("##.##%");
  public final static Format SIR   = new java.text.DecimalFormat("#0.00");
  public final static Format AIRR   = new java.text.DecimalFormat("#0.00%");
  public final static Format FACTOR = new java.text.DecimalFormat("#0.000");

  int ncols;
  Vector rows = new Vector();
  Object currow[] = null;
  int curcol=0;

  public Table(int ncols){
    this.ncols=ncols; }

  // Building the table.

  public void startRow(){
    curcol=0;
    currow = new Object[1+2*ncols];
    currow[0] = new Integer(0); }

  public void setIndent(int indent){
    currow[0] = new Integer(indent); }

  public void addCol(double data, Units units){
    addCol(new Double(data),units); }

  public void addCol(Object data, Object format){
    String string;
    if (data == null){
      string="";}
    else if((data instanceof Double) && (format instanceof Units)){
      string = ((Units) format).toString((Double) data);
      format = NUMBER;
       }
    else if (format instanceof Format){
      string = ((Format) format).format(data);
      format = NUMBER; }
    else {
      string = data.toString(); }
    currow[1+2*curcol]=string;
    currow[2+2*curcol]=format;
    curcol++; }

  public void endRow(){
    rows.addElement(currow);
    currow=null; }

  public void endTable(){}

  // Convenience methods
  public void addRow(int indent, Object data1, Object format1){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
		     Object data2, Object format2){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(new Double(data2),format2);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2, Object data3, Object format3){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(new Double(data2),format2);
    addCol(data3,format3);
    endRow(); }



  public void addRow(int indent, Object data1, Object format1,
         Object data2, Object format2,
         double data3, Object format3){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(new Double(data3),format3);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
         Object data2, Object format2,
         double data3, Object format3,
         double data4, Object format4){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(new Double(data3),format3);
    addCol(new Double(data4),format4);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
         Object data2, Object format2,
         Object data3, Object format3,
         double data4, Object format4){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(data3,format3);
    addCol(new Double(data4),format4);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
         Object data2, Object format2,
         Object data3, Object format3,
         double data4, Object format4,
         Object data5, Object format5,
         double data6, Object format6){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(data3,format3);
    addCol(new Double(data4),format4);
    addCol(data5,format5);
    addCol(new Double(data6),format6);

    endRow(); }


  public void addRow(int indent, Object data1, Object format1,
         double data2, Object format2,
         double data3, Object format3,
         Object data4, Object format4){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(new Double(data2),format2);
    addCol(new Double(data3),format3);
    addCol(data4,format4);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
		     Object data2, Object format2,
		     Object data3, Object format3){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(data3,format3);
    endRow(); }
  public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2,
		     double data3, Object format3){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(new Double(data2),format2);
    addCol(new Double(data3),format3);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
		     Object data2, Object format2,
		     Object data3, Object format3,
		     Object data4, Object format4){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(data3,format3);
    addCol(data4,format4);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2,
		     double data3, Object format3,
		     double data4, Object format4){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(new Double(data2),format2);
    addCol(new Double(data3),format3);
    addCol(new Double(data4),format4);
    endRow(); }

	 public void addRow(int indent,double data1, Object format1,
		     double data2, Object format2,
		     double data3, Object format3){
    startRow();
    setIndent(indent);
    addCol(new Double(data1),format1);
    addCol(new Double(data2),format2);
    addCol(new Double(data3),format3);
    endRow(); }

		public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2,
				 Object data3, Object format3,
				 double data4, Object format4,
				 double data5, Object format5){
    startRow();
    setIndent(indent);
		addCol(data1, format1);
    addCol(new Double(data2),format2);
		addCol(data3, format3);
    addCol(new Double(data4),format4);
		addCol(new Double(data5),format5);
    endRow(); }

	 public void addRow(int indent, Object data1, Object format1,
				 Object data2, Object format2,
				 Object data3, Object format3,
				 double data4, Object format4,
		     double data5, Object format5,
		     double data6, Object format6){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
		addCol(data2,format2);
		addCol(data3,format3);
    addCol(new Double(data4),format4);
    addCol(new Double(data5),format5);
    addCol(new Double(data6),format6);
    endRow(); }

	 public void addRow(int indent, Object data1, Object format1,
				 Object data2, Object format2,
				 double data3, Object format3,
		     double data4, Object format4,
				 Object data5, Object format5,
				 double data6, Object format6){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
		addCol(data2,format2);
    addCol(new Double(data3),format3);
    addCol(new Double(data4),format4);
		addCol(data5,format5);
    addCol(new Double(data6),format6);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
		     Object data2, Object format2,
		     Object data3, Object format3,
         Object data4, Object format4,
         Object data5, Object format5){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(data3,format3);
    addCol(data4,format4);
    addCol(data5,format5);

    endRow(); }


  public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2,
		     Object data3, Object format3,
         Object data4, Object format4,
         double data5, Object format5){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
		addCol(new Double(data2),format2);
		addCol(data3,format3);
    addCol(data4,format4);
    addCol(new Double(data5),format5);
    endRow(); }
  public void addRow(int indent, Object data1, Object format1,
		     Object data2, Object format2,
		     Object data3, Object format3,
         Object data4, Object format4,
         Object data5, Object format5,
         Object data6, Object format6){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(data3,format3);
    addCol(data4,format4);
    addCol(data5,format5);
    addCol(data6,format6);
    endRow(); }


  public void addRow(int indent, Object data1, Object format1,
		     Object data2, Object format2,
		     Object data3, Object format3,
         Object data4, Object format4,
         Object data5, Object format5,
         Object data6, Object format6,
         Object data7, Object format7){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(data2,format2);
    addCol(data3,format3);
    addCol(data4,format4);
    addCol(data5,format5);
    addCol(data6,format6);
    addCol(data7,format7);
    endRow(); }



  public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2,
		     double data3, Object format3,
         double data4, Object format4,
         double data5, Object format5){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(new Double(data2),format2);
    addCol(new Double(data3),format3);
    addCol(new Double(data4),format4);
    addCol(new Double(data5), format5);
    endRow(); }

  public void addRow(int indent,
         double data1, Object format1,
         double data2, Object format2,
         double data3, Object format3,
         double data4, Object format4,
         double data5, Object format5){
    startRow();
    setIndent(indent);
    addCol(new Double(data1),format1);
    addCol(new Double(data2),format2);
    addCol(new Double(data3),format3);
    addCol(new Double(data4), format4);
    addCol(new Double(data5), format5);
    endRow(); }

  public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2,
		     double data3, Object format3,
         double data4, Object format4,
         double data5, Object format5,
         double data6, Object format6){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(new Double(data2),format2);
    addCol(new Double(data3),format3);
    addCol(new Double(data4),format4);
    addCol(new Double(data5), format5);
    addCol(new Double(data6), format6);
    endRow(); }


  public void addRow(int indent, Object data1, Object format1,
		     double data2, Object format2,
		     double data3, Object format3,
         double data4, Object format4,
         double data5, Object format5,
         double data6, Object format6,
         double data7, Object format7){
    startRow();
    setIndent(indent);
    addCol(data1,format1);
    addCol(new Double(data2),format2);
    addCol(new Double(data3),format3);
    addCol(new Double(data4),format4);
    addCol(new Double(data5), format5);
    addCol(new Double(data6), format6);
    addCol(new Double(data7), format7);
    endRow(); }



   // Formatting assitance;
  public int[] computeWidths(){
    int widths[] = new int[ncols];
    int nrows=rows.size();
    for(int i=0; i<nrows; i++){
      Object row[] = (Object[])rows.elementAt(i);
      int ind=((Integer)row[0]).intValue()*2;
      for(int j=0; j<ncols; j++){
	String string =(String) row[1+2*j];
	if (string != null){
	  int w = string.length()+ind;
	  if (w > widths[j]) widths[j]=w; }
	ind=0;}}
    return widths; }

  public void format(Formatter formatter){
    int widths[] = computeWidths();
    formatter.formatTableStart();
    int nrows=rows.size();
    for(int i=0; i<nrows; i++){
      Object row[] = (Object[])rows.elementAt(i);
      formatter.formatTableRowStart(((Integer) row[0]).intValue());
      for(int j=0; j<ncols; j++){
	String data = (String) row[1+2*j];
	if (data == null) data = "";
	formatter.formatTableCol(j,widths[j],data, row[2+2*j]); }
      formatter.formatTableRowEnd(); }
    formatter.formatTableEnd();}

}
