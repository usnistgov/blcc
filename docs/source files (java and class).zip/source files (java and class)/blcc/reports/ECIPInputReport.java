package blcc.reports;

import blcc.model.*;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.DecimalFormat;
import java.util.Enumeration;

public class ECIPInputReport {
  Project project;
  Formatter formatter;
  String fileName;
  int analysisType;

  public ECIPInputReport(Project project, Formatter formatter, String fileName){
    this.project = project;
    this.formatter = formatter;
    this.fileName = fileName;}

  public void report(){
    analysisType=project.getAnalysisType();
    formatter.header(1,"NIST BLCC " + blcc.util.Defaults.getStringItem("version") + ": Input Data Listing");
		if( project.getAnalysisType() ==Project.OMBANALYSIS || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS){
			formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology in OMB Circular A-94");}
		else{
    formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology and Procedures, 10 CFR, Part 436, Subpart A");}
    formatter.header(0,"");
    describeProject(project,0).format(formatter);

    for(Enumeration e=project.enumerateAlternatives(); e.hasMoreElements(); ){
      Alternative alt = (Alternative) e.nextElement();
      formatter.header(1,"Savings from Alternative: "+alt.getName());
      describeAlternative(alt,0);
      }
  }

  /* ______________________________________________________________________
     Project Description */

  public Table describeProject(Project project, int level){
    Table desc = new Table(2);
    formatter.header(2,"General Information");
    desc.addRow(level+1,"File Name:",Table.ROWHEADING,
                fileName,Table.RIGHT);
    desc.addRow(level+1,"Date of Study:",Table.ROWHEADING,
                new java.util.Date(),Table.RIGHT);
    desc.addRow(level+1,"Analysis Type:",Table.ROWHEADING,
                Project.analysisNames[project.getAnalysisType()],Table.RIGHT);
		if (project.getAnalysisType() == Project.OMBANALYSIS) {
			desc.addRow(level+1,"Analysis Purpose:", Table.ROWHEADING,
								Project.analysisPurposes[project.getAnalysisPurpose()],Table.RIGHT);
		}
    desc.addRow(level+1, "Project Name:", Table.ROWHEADING,
                project.getName(), Table.RIGHT);
    desc.addRow(level+1,"Project Location:",Table.ROWHEADING,
                project.getLocation(),Table.RIGHT);
    desc.addRow(level+1,"Analyst:",Table.ROWHEADING,
                project.getAnalyst(),Table.RIGHT);
    showComment(desc,level+1,project);
    desc.addRow(level+1,"Base Date:",Table.ROWHEADING,
                project.getBaseDate(),Table.RIGHT);
    desc.addRow(level+1,"Beneficial Occupancy Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    String junk = project.getDuration() + " (" + project.getBaseDate() + " through " + project.getEndDate() + ")";
    desc.addRow(level+1,"Study Period:",Table.ROWHEADING,
                junk,Table.RIGHT);
    desc.addRow(level+1,"Discount Rate:",Table.ROWHEADING,
                project.getDiscountRate(),Table.RATE);
    desc.addRow(level+1,"Discounting Convention:",Table.ROWHEADING,
              Project.discountingMethodNames[project.getDiscountingMethod()],
              Table.RIGHT);
    String junkline;
     if(project.getDollarMethod() == Project.CONSTANTDOLLARMETHOD)
      junkline="REAL (exclusive";
    else
      junkline="NOMINAL (inclusive";
    desc.addRow(level+1,"Discount and Escalation Rates are "+ junkline + " of general inflation)",Table.COLSPANHEADING);
    desc.addRow(0,"",Table.COLHEADING);
    return desc; }

  /* ______________________________________________________________________
     Alternative Description */
  public void describeAlternative(Alternative alt, int level){

    Table comment = new Table(2);
    showComment(comment,level+1,alt);
    comment.addRow(0,"",Table.COLHEADING);
    comment.format(formatter);

    for(Enumeration e=alt.enumerateEnergyUsages(); e.hasMoreElements(); ) {
      describeEnergy((EnergyUsage) e.nextElement(),level+1);}

    for(Enumeration e=alt.enumerateWaterUsages(); e.hasMoreElements(); ){
      describeWater((WaterUsage) e.nextElement(),level+1); }

    for(Enumeration e=alt.enumerateCapitalComponents(); e.hasMoreElements(); ){
        CapitalComponent comp = (CapitalComponent) e.nextElement();
        formatter.header(2, "Capital Component Savings/Costs:  " +comp.getName());
        describeComponent(comp, level+1);}
  }

  /* ______________________________________________________________________
     Component Description */
  public void describeComponent(CapitalComponent comp, int level){
    Units money=comp.getMonetaryUnits();

    Table comment = new Table(2);
    showComment(comment,level+1,comp);
    comment.addRow(0,"",Table.COLHEADING);
    comment.format(formatter);

    formatter.header(3,"Additional Investment Cost");
    Table desc = new Table(2);
    desc.addRow(level+1,"Construction Cost:",Table.ROWHEADING,
                comp.getConstructionCost(),money);
    desc.addRow(level+1,"SIOH:",Table.ROWHEADING,
                comp.getSIOH(),money);
    desc.addRow(level+1,"Design Cost:",Table.ROWHEADING,
                comp.getDesignCost(),money);
    double cost=0.0, investment=0.0;
    cost=comp.getConstructionCost()+comp.getSIOH()+comp.getDesignCost();
    investment=cost - comp.getSalvageValue() - comp.getUtilityRebate();
    desc.addRow(level+1,"Total Cost:",Table.ROWHEADING,
                cost,money);
    desc.addRow(level+1,"Salvage Value of Existing Equipment:",Table.ROWHEADING,
                comp.getSalvageValue(),money);
    desc.addRow(level+1,"Public Utility Company Rebate:",Table.ROWHEADING,
                comp.getUtilityRebate(),money);
    desc.addRow(level+1,"Total Investment:",Table.ROWHEADING,
                investment,money);

    desc.addRow(0,"",Table.COLHEADING);
    desc.format(formatter);

    for(Enumeration e=comp.enumerateRecurringCosts(); e.hasMoreElements(); ) {
      describeARC((RecurringCost) e.nextElement(), level+1); }

    for(Enumeration e=comp.enumerateNonRecurringCosts(); e.hasMoreElements(); ){
      describeNRC((NonRecurringCost) e.nextElement(), level+1); }
  }


  /* ______________________________________________________________________
     EnergyUsage Description */
  public void describeEnergy(EnergyUsage energy, int level){
    Table des = new Table(2);
    formatter.header(3, "Energy Savings/Cost:  "+energy.getName());
    des.addRow(level+1,"Annual Savings:",Table.ROWHEADING,
                energy.getYearlyUsage(),energy.getUnits());
    des.addRow(level+1,"Price per Unit:",Table.ROWHEADING,
                energy.getUnitCost(),energy.getUnitCostMonetaryUnits());
    des.addRow(level+1,"Demand Charge:",Table.ROWHEADING,
                energy.getDemandCharge(),energy.getMonetaryUnits());
    des.addRow(level+1,"Utility Rebate:",Table.ROWHEADING,
                energy.getUtilityRebate(),energy.getMonetaryUnits());
    String emissions;
    if(energy.getFuelType() == blcc.util.FuelType.ELECTRICITY) emissions="Location:";
    else emissions="End-Use:";
    des.addRow(level+1,emissions,Table.ROWHEADING,
                energy.getEmissions(),Table.RIGHT);
    des.addRow(level+1,"Rate Schedule:",Table.ROWHEADING,
                energy.getRateSchedule(),Table.RIGHT);
    des.addRow(level+1,"State:",Table.ROWHEADING,
                energy.getState(),Table.RIGHT);
    des.addRow(0,"",Table.COLHEADING);
    des.format(formatter);

    formatter.header(4,"Usage Indices");
    Table usage = new Table(3);
    describeVarying((UsageIndex)energy.getUsageIndex(),usage,level+1,"Usage Index");
    usage.format(formatter);

    formatter.header(4,"Escalation Rates");
    Table escalation = new Table(3);
    describeVarying((VaryingEscalation)energy.getEscalation(),escalation,level+1,"Escalation");
    escalation.format(formatter);}
    /* ______________________________________________________________________
     WaterUsage Description */

  public void describeWater(WaterUsage water, int level){
    Units money=water.getUnitCostMonetaryUnits();
    Units units=water.getUnits();
    Table des = new Table(5);
    formatter.header(3, "Water Savings/Cost:  " + water.getName());

    des.addRow(0,"",Table.ROWHEADING,
                  "Annual Usage",Table.COLSPANHEADING,
                  "Annual Disposal",Table.COLSPANHEADING);

    des.addRow(0,"",Table.ROWHEADING,
                  "Units/Year",Table.COLHEADING,
                  "Price/Unit",Table.COLHEADING,
                  "Units/Year",Table.COLHEADING,
                  "Price/Unit",Table.COLHEADING);

     des.addRow(level+1, "@Summer Rates", Table.ROWHEADING,
                  water.getSummerYearlyUsage(),units,
                  water.getSummerUsageUnitCost(), money,
                  water.getSummerYearlyDisposal(),units,
                  water.getSummerDisposalUnitCost(), money);
     des.addRow(level+1, "@Winter Rates", Table.ROWHEADING,
                  water.getWinterYearlyUsage(),units,
                  water.getWinterUsageUnitCost(), money,
                  water.getWinterYearlyDisposal(),units,
                  water.getWinterDisposalUnitCost(), money);

    des.addRow(0,"",Table.COLHEADING);
    des.format(formatter);

    formatter.header(4,"Escalation Rates - Usage");
    Table usageEsc = new Table(3);
    describeVarying((VaryingEscalation)water.getUsageEscalation(),usageEsc,level+1,"Usage Cost Escalation");
    usageEsc.format(formatter);

    formatter.header(4,"Escalation Rates - Disposal");
    Table dispEsc = new Table(3);
    describeVarying((VaryingEscalation)water.getDisposalEscalation(),dispEsc,level+1,"Disposal Cost Escalation");
    dispEsc.format(formatter);

    formatter.header(4,"Usage Indices - Usage");
    Table usage = new Table(3);
    describeVarying((UsageIndex)water.getUsageIndex(),usage,level+1,"Index");
    usage.format(formatter);

    formatter.header(4,"Usage Indices - Disposal");
    Table disposal = new Table(3);
    describeVarying((UsageIndex)water.getDisposalIndex(),disposal,level+1,"Index");
    disposal.format(formatter); }
  /* ______________________________________________________________________
     Recurring/NonRecurring Cost Description */

  public void describeNRC(NonRecurringCost cost, int level){
    Units money=cost.getMonetaryUnits();
    Table des = new Table(2);
    formatter.header(3, "Non-Annually Recurring Savings/Costs:  " + cost.getName());
    des.addRow(level+1,"Years/Months:",Table.ROWHEADING,
                cost.getStart(),Table.RIGHT);
    des.addRow(level+1,"Amount Saved:",Table.ROWHEADING,cost.getAmount(),money);
    des.addRow(level+1,"Annual Rate of Increase:",Table.ROWHEADING,
            ((SimpleEscalation)cost.getEscalation()).getRate(),Table.RATE);
    des.addRow(0,"",Table.COLHEADING);
    des.format(formatter);}


    public void describeARC(RecurringCost cost, int level){
    Units money=cost.getMonetaryUnits();
    Table des = new Table(2);
    formatter.header(3,  "Annually Recurring Savings/Cost:  " +cost.getName());
    des.addRow(level+1,"Amount Saved:",Table.ROWHEADING,cost.getAmount(),money);
    des.addRow(level+1,"Annual Rate of Increase:",Table.ROWHEADING,
            ((SimpleEscalation)cost.getEscalation()).getRate(),Table.RATE);
    des.addRow(0,"",Table.COLHEADING);
    des.format(formatter);

     formatter.header(4,"Usage Indices");
      Table usage = new Table(3);
      describeVarying((UsageIndex)cost.getIndex(),usage,level+1,"Factor");
      usage.format(formatter);   }

  /* ______________________________________________________________________
     Varying Description */

   public void describeVarying(Varying varying, Table desc, int level, String heading){
    desc.addRow(level+1,"From Date",Table.COLHEADING,"Duration",Table.COLHEADING,heading,Table.COLHEADING);
    for(int i=0;i<varying.getValues().length;i++)
      desc.addRow(level+1,varying.getDate(i),Table.COLHEADING,
                  varying.getInterval(i), Table.COLHEADING,
                  varying.getValue(i), Table.ESCALATION);
      desc.addRow(0,"",Table.COLHEADING);}
  /* ______________________________________________________________________
     Low-level helpers */

  public void showComment(Table desc, int level, ModelElement element){
    String comment = element.getComment();
    if(comment!=null && !comment.equals(""))
      desc.addRow(level,"Comment:",Table.ROWHEADING,comment,Table.RIGHT); }


}
