package blcc.reports;

import blcc.util.Date;
import blcc.util.Units;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

public abstract class Formatter {

  public abstract void header(int level, String text);
  public abstract void line(String text);
  public abstract void paragraph(String text);
  public abstract String spaces();

  public void close(){}

  /** This formats a table. */
  abstract public void formatTableStart();
  abstract public void formatTableRowStart(int indent);
  abstract public void formatTableCol(int col, int width, String data, Object format);
  abstract public void formatTableRowEnd();
  abstract public void formatTableEnd();

  /** Format a table appropriate for a CashFlow.
    * Row totals are added as a column on the right, and
    * column totals are added as a row on the bottom. */
  public Table flowTable(Date timeline[], double columns[][],
			String headings[], Units units,
			boolean sumrows, boolean sumcols){
    int ncols = columns.length;
    int nrows = timeline.length-1;
    double sums[]=new double[ncols+1];

    Table table = new Table(1+ncols+(sumrows? 1:0));

    table.startRow();
    table.addCol("Year Beginning",Table.ROWHEADING);
    for(int j=0; j<ncols; j++)
      table.addCol(headings[j],Table.COLHEADING);

    if (sumrows)
      table.addCol("Total",Table.COLHEADING);
    table.endRow();

    for(int i=0; i<nrows; i++){
      table.startRow();
      table.addCol(timeline[i].formatAsMonth(),Table.ROWHEADING);
      double rtotal=0.0;
      for(int j=0; j<ncols; j++) {
        double v = columns[j][i];
        table.addCol(v,units);
        sums[j] += v;
        rtotal += v; }
      sums[ncols] += rtotal;
      if (sumrows)
	table.addCol(rtotal,units);
      table.endRow(); }

    if (sumcols){
      table.startRow();
      for(int i=0; i<sums.length+1; i++)
        table.addCol("-",Table.FILL);
      table.endRow();
      table.startRow();
      table.addCol("Total",Table.BOLD);
      for(int j=0; j<ncols+1; j++)
	table.addCol(sums[j],units);
      table.endRow(); }
    table.endTable();
    table.addRow(0,"",Table.COLHEADING);
   return table; }
}
