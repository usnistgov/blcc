package blcc.reports;


import blcc.model.*;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.util.FuelType;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.DecimalFormat;
import java.util.Enumeration;


public class CompareReport {


  Analysis analysis;
  Formatter formatter;
  Project project;
  String fileName;
  Alternative alt1;
  Alternative alt2;

  public CompareReport(Analysis analysis, Formatter formatter,
                       Project project, String fileName, Alternative alt1, Alternative alt2){
    this.analysis = analysis;
    this.formatter = formatter;
    this.project = project;
    this.fileName = fileName;
    this.alt1 = alt1;
    this.alt2 = alt2;}

  public void report(){

    Date start      = analysis.getBaseDate();
    Date service    = analysis.getServiceDate();
    Date end        = analysis.getEndDate();
    double CRF      = analysis.getCapitalRecoveryFactor();
    double length   = DateDiff.diffInYears(service,end);
    Units money     = analysis.getMonetaryUnits();
    Date timeline[] = DateDiff.timeline(start,service,end);
    int analysisType = project.getAnalysisType();


    formatter.header(1, "NIST BLCC " + blcc.util.Defaults.getStringItem("version") + ": Comparative Analysis");
		if( project.getAnalysisType() ==Project.OMBANALYSIS || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS){
			formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology in OMB Circular A-94");}
		else{
    formatter.header(6,"Consistent with Federal Life Cycle Cost Methodology and Procedures, 10 CFR, Part 436, Subpart A");}
    formatter.header(0,"");

    formatter.header(2,"Base Case: "+alt1.getName());
    formatter.header(2,"Alternative: "+alt2.getName());


    formatter.header(0,"");
    describeProject(project,0).format(formatter);


    formatter.header(1,"Comparison of Present-Value Costs");
    formatter.header(0,"");

    double cap1,cap2,borrow1,borrow2,capinit1,capinit2,capinit_diff;
    cap1 = analysis.getAmount(alt1,Category.COST_CAPITAL_INITIAL,money,
                              start,end,true);
    cap2 = analysis.getAmount(alt2,Category.COST_CAPITAL_INITIAL,money,
                              start,end,true);
    capinit_diff = cap1 - cap2;
    formatter.header(2,"PV Life-Cycle Cost");
    Table table1 = new Table(4);
    table1.addRow(0,"",Table.ROWHEADING,
                    "Base Case",Table.COLHEADING,
                    "Alternative",Table.COLHEADING,
                    "Savings from Alternative",Table.COLHEADING);
    String junk=":";
    if(analysisType == Project.FINANCEDANALYSIS)
     junk = " Paid By Agency:";
    table1.addRow(0,"Initial Investment Costs" + junk, Table.BOLD,
                  "", Table.COLHEADING, "", Table.COLHEADING, "", Table.COLHEADING);
    table1.addRow(1,formatter.spaces()+"Capital Requirements as of Base Date",Table.ROWHEADING,
                  cap1,money,cap2,money,capinit_diff,money);

    double rep1,rep2,resid1,resid2,ecost1,ecost2,edemand1, edemand2, erebate1, erebate2, rec1,rec2,nrec1,nrec2,
           omr1,omr2,contract1=0.0,contract2=0.0,sub1,sub2,sub_diff,wcost1,wcost2,lcc1,lcc2;

    rep1 = analysis.getAmount(alt1,Category.COST_CAPITAL_REPLACEMENT,money,
                              start,end,true);
    rep2 = analysis.getAmount(alt2,Category.COST_CAPITAL_REPLACEMENT,money,
                              start,end,true);
    resid1 = analysis.getAmount(alt1,Category.COST_CAPITAL_RESIDUAL,money,
                                start,end,true) + analysis.getAmount(alt1,
                                Category.COST_CAPITAL_REPLACEMENT_RESIDUAL, money,
                                start,end,true);
    resid2 = analysis.getAmount(alt2,Category.COST_CAPITAL_RESIDUAL,money,
                                start,end,true) + analysis.getAmount(alt2,
                                Category.COST_CAPITAL_REPLACEMENT_RESIDUAL, money,
                                start,end,true);
    ecost1 = analysis.getAmount(alt1,Category.COST_OMR_ENERGY_CONSUMPTION,money,
                                start,end,true);
    ecost2 = analysis.getAmount(alt2,Category.COST_OMR_ENERGY_CONSUMPTION,money,
                                start,end,true);
    edemand1 = analysis.getAmount(alt1,Category.COST_OMR_ENERGY_DEMAND,money,
                                start,end,true);
    edemand2 = analysis.getAmount(alt2,Category.COST_OMR_ENERGY_DEMAND,money,
                                start,end,true);
    erebate1 = analysis.getAmount(alt1,Category.COST_OMR_ENERGY_REBATE,money,
                                start,end,true);
    erebate2 = analysis.getAmount(alt2,Category.COST_OMR_ENERGY_REBATE,money,
                                start,end,true);
    wcost1 = analysis.getAmount(alt1,Category.COST_OMR_WATER,money,
                                start,end,true);
    wcost1 = wcost1 + analysis.getAmount(alt1,Category.COST_OMR_WATERDISPOSAL,
                                         money,start,end,true);
    wcost2 = analysis.getAmount(alt2,Category.COST_OMR_WATER,money,
                                start,end,true);
    wcost2 = wcost2 + analysis.getAmount(alt2,Category.COST_OMR_WATERDISPOSAL,
                                         money,start,end,true);
    rec1 = analysis.getAmount(alt1,Category.COST_OMR_RECURRING,money,
                              start,end,true);
    nrec1 = analysis.getAmount(alt1,Category.COST_OMR_NONRECURRING,money,
                               start,end,true);
    omr1 = rec1 + nrec1;
    rec2 = analysis.getAmount(alt2,Category.COST_OMR_RECURRING,money,
                              start,end,true);
    nrec2 = analysis.getAmount(alt2,Category.COST_OMR_NONRECURRING,money,
                               start,end,true);
    omr2 = rec2 + nrec2;
    contract1 = analysis.getAmount(alt1,Category.COST_CONTRACT,money,
                               start,end,true);
    contract2 = analysis.getAmount(alt2,Category.COST_CONTRACT,money,
                               start,end,true);

    sub1 = rep1 + resid1 + ecost1 + edemand1 + erebate1+ wcost1 + omr1 + contract1;
    sub2 = rep2 + resid2 + ecost2 + edemand2 + erebate2 + wcost2 + omr2 + contract2;
    sub_diff = sub1 - sub2;
    lcc1 = cap1 + sub1;
    lcc2 = cap2 + sub2;

    table1.addRow(0,"Future Costs:", Table.BOLD,
                  "", Table.COLHEADING, "", Table.COLHEADING, "", Table.COLHEADING);
    if(analysisType == Project.FINANCEDANALYSIS)
      table1.addRow(1,formatter.spaces()+"Recurring and Non-Recurring Contract Costs",Table.ROWHEADING,
                    contract1,money,contract2,money,contract1-contract2,money);
    table1.addRow(1,formatter.spaces()+"Energy Consumption Costs",Table.ROWHEADING,
                  ecost1,money,ecost2,money,ecost1-ecost2,money);
    table1.addRow(1,formatter.spaces()+"Energy Demand Charges",Table.ROWHEADING,
                  edemand1,money,edemand2,money,edemand1-edemand2,money);
    table1.addRow(1,formatter.spaces()+"Energy Utility Rebates",Table.ROWHEADING,
                  erebate1,money,erebate2,money,erebate1-erebate2,money);


    table1.addRow(1,formatter.spaces()+"Water Costs",Table.ROWHEADING,
                  wcost1,money,wcost2,money,wcost1-wcost2,money);

    String prefix1="", prefix2="";
    if(analysisType==Project.MILCONENERGYANALYSIS || analysisType==Project.MILCONNONENERGYANALYSIS){
      prefix1="Routine ";
      prefix2 = "Major Repair and ";}
    else{prefix2="Capital ";}

    table1.addRow(1,formatter.spaces()+prefix1+"Recurring and Non-Recurring OM&R Costs",Table.ROWHEADING,
                  omr1,money,omr2,money,omr1-omr2,money);
    table1.addRow(1,formatter.spaces()+prefix2+"Replacements",Table.ROWHEADING,
                  rep1,money,rep2,money,rep1-rep2,money);
    table1.addRow(1,formatter.spaces()+"Residual Value at End of Study Period",Table.ROWHEADING,
                  resid1,money,resid2,money,resid1-resid2,money);
    table1.addRow(1,"",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL,"-",Table.FILL);
    table1.addRow(2,formatter.spaces()+"Subtotal (for Future Cost Items)",Table.ROWHEADING,
                  sub1,money,sub2,money,sub1-sub2,money);
    table1.addRow(1," ",Table.ROWHEADING,"-",Table.FILL,"-",Table.FILL,"-",Table.FILL);
    table1.addRow(0,"Total PV Life-Cycle Cost",Table.BOLD,
                  lcc1,money,lcc2,money,lcc1-lcc2,money);
    table1.format(formatter);
    formatter.header(0,"");


    double nonInvestmentSavings, increasedTotalInvestment;

    // note:  for FEMP projects, investment costs include replacement and residual
    formatter.header(2,"Net Savings from Alternative Compared with Base Case");
    Table table3 = new Table(2);
    nonInvestmentSavings=(omr1+ecost1+edemand1+erebate1+wcost1)-(omr2+ecost2+edemand2+erebate2+wcost2);
    increasedTotalInvestment=(cap2+rep2+contract2+resid2)-(cap1+rep1+contract1+resid1);


    String label1, label2;
    if(project.getAnalysisType() == Project.FINANCEDANALYSIS){
     label1 = "PV of Operational Savings"; label2="- PV of Differential Costs";}
    else{
     label1 = "PV of Non-Investment Savings"; label2="- Increased Total Investment";}

    table3.addRow(1,label1,Table.ROWHEADING,
                  nonInvestmentSavings,money);
    table3.addRow(1,label2,Table.ROWHEADING,
                  increasedTotalInvestment,money);
    table3.addRow(1," ",Table.ROWHEADING,"-",Table.FILL);
    table3.addRow(2,"Net Savings",Table.BOLD,
                  nonInvestmentSavings-increasedTotalInvestment,money);
    table3.format(formatter);
    formatter.header(0,"");


   if(project.getAnalysisType() != Project.FINANCEDANALYSIS){ //no SIR, AIRR, Payback in financed projects

		 if(nonInvestmentSavings>=0. && increasedTotalInvestment>=0.){
        formatter.header(2,"Savings-to-Investment Ratio (SIR)");
        double sir;
        sir = nonInvestmentSavings/increasedTotalInvestment;
        Table table4 = new Table(2);
		    table4.addRow(1,"SIR = ",Table.BOLD,sir,Table.SIR);
		    table4.format(formatter);
		    if(sir < 1.0)
		     formatter.header(5, "SIR is lower than 1.0; project alternative is not cost effective.");
		    formatter.header(0,"");


		    formatter.header(2,"Adjusted Internal Rate of Return");

				if(sir!=0.0){
				  double airr;
		      double disc = project.getDiscountRate();
		      double len = DateDiff.diffInYears(start,end);

		      airr = (1+disc) * Math.pow(sir,1/len) - 1;

		      Table table5 = new Table(2);
		      table5.addRow(1,"AIRR = ",Table.BOLD,airr,Table.AIRR);
		      table5.format(formatter);
		      if(airr < project.getDiscountRate())
		       formatter.header(5, "AIRR is lower than your discount rate; project alternative is not cost effective.");
				}
				else                            // SIR is 0
    			formatter.header(5, "Can't compute AIRR when SIR=0.");

		    formatter.header(0,"");

		  // *** Payback Period ***
		  String title="Service";
		  if(project.getAnalysisType()==Project.MILCONENERGYANALYSIS || project.getAnalysisType()==Project.MILCONECIPANALYSIS  || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS)
		    title ="Beneficial Occupancy";

		  formatter.header(2,"Payback Period");
		  formatter.header(3,"Estimated Years to Payback "+
		  "(from beginning of " + title + " Period)");

		  if(cap1 == cap2){
		   formatter.header(5, "No difference in required initial capital investment between Base Case");
		   formatter.header(5, " and Alternative Case.  Computation of Payback Period not applicable.");}

		 else{
		  int nperiods = timeline.length-1;
		  double[] capital_1 = new double[nperiods];
		  double[] capital_2 = new double[nperiods];
		  double[] omr_1 = new double[nperiods];
		  double[] omr_2 = new double[nperiods];
		  double[][] columns = new double[5][nperiods];

			//String[] headings = {"Alt1_Capital","Alt1_OMR","Alt2_Capital","Alt2_OMR",
		  //"Cumulative_Net_Savings"};

			// *** Simple Payback ***
		  boolean payback = false;
			boolean simpleEverReached=false;
		  double cumulative_savings = 0;
		  Table table6 = new Table(2);
		  capital_1 = analysis.getAmount(alt1,Category.COST_CAPITAL,
		  money,timeline,false);
		  omr_1 = analysis.getAmount(alt1,Category.COST_OMR,
		  money,timeline,false);
		  capital_2 = analysis.getAmount(alt2,Category.COST_CAPITAL,
		  money,timeline,false);
		  omr_2 = analysis.getAmount(alt2,Category.COST_OMR,
		  money,timeline,false);

		  double yearsFromService;
		  DecimalFormat yearsFormat = new java.text.DecimalFormat("#0");

		  for (int i = 0; i < nperiods; i++)
		   {
		    columns[0][i] = capital_1[i];
		    columns[1][i] = omr_1[i];
		    columns[2][i] = capital_2[i];
		    columns[3][i] = omr_2[i];
		    cumulative_savings += capital_1[i] + omr_1[i] - capital_2[i] - omr_2[i];
		    columns[4][i] = cumulative_savings;

		     if ( !payback && cumulative_savings >= 0. )
		       {
		        yearsFromService=DateDiff.diffInYears(service, timeline[i]) + 1;   //+1 --> service is year 1
						if(yearsFromService<0){          // happens during P/C period, don't report  (aka, -3 would be 3 years BEFORE service period)
						  payback=false;}
		        payback = true;
						simpleEverReached=true;
		        table6.addRow(1,"Simple Payback occurs in year ",Table.ROWHEADING,
		        yearsFromService,yearsFormat);
		       }
		    else if ( payback && cumulative_savings < 0.)
		    {
		     payback = false;
		     yearsFromService=DateDiff.diffInYears(service, timeline[i]) + 1;   //+1 --> service is year 1
		     table6.addRow(1,"Simple Payback is negated in year ",Table.ROWHEADING,
		     yearsFromService,yearsFormat);
		   }
		  }

		// Uncomment next three lines (and headings above) to include diagnostic timeline table in report.
		 //formatter.header(4,"Diagnostic Table for Simple Payback");
		 //formatter.flowTable(timeline,columns,headings,money,false,false).format(formatter);
		 //formatter.header(0,"");

		// *** Discounted Payback ***
		   payback = false;
			 boolean discountedEverReached=false;
		   cumulative_savings = 0;
		   capital_1 = analysis.getAmount(alt1,Category.COST_CAPITAL,
		     money,timeline,true);
		    omr_1 = analysis.getAmount(alt1,Category.COST_OMR,
		     money,timeline,true);
		    capital_2 = analysis.getAmount(alt2,Category.COST_CAPITAL,
		      money,timeline,true);
		    omr_2 = analysis.getAmount(alt2,Category.COST_OMR,
		      money,timeline,true);
		   for (int i = 0; i < nperiods; i++)
		    {
		    columns[0][i] = capital_1[i];
		    columns[1][i] = omr_1[i];
		    columns[2][i] = capital_2[i];
		    columns[3][i] = omr_2[i];
		    cumulative_savings += capital_1[i] + omr_1[i] - capital_2[i] - omr_2[i];
		    columns[4][i] = cumulative_savings;
		   if ( !payback && cumulative_savings >= 0. )
		   {
		    payback = true;
				discountedEverReached=true;
		    yearsFromService = DateDiff.diffInYears(service, timeline[i]) + 1;   //+1 --> service is year 1
		 		if(yearsFromService<0){          // happens during P/C period, don't report  (aka, -3 would be 3 years BEFORE service period)
				  payback=false;
					break;}																																				 //
		    table6.addRow(1,"Discounted Payback occurs in year ",Table.ROWHEADING,
		    yearsFromService, yearsFormat);
		   }
		  else if ( payback && cumulative_savings < 0.)
		    {
		    payback = false;
		    yearsFromService=(int) DateDiff.diffInYears(service, timeline[i]) + 1;   //+1 --> service is year 1
		    table6.addRow(1,"Discounted Payback is negated in year ",Table.ROWHEADING,
		    yearsFromService, yearsFormat);
		   }
			}

			if(!simpleEverReached)
			  formatter.header(5,"Simple Payback never reached during study period.");
			if(!discountedEverReached)
			  formatter.header(5,"Discounted Payback never reached during study period.");


		   table6.format(formatter);

		// Uncomment next two lines to include diagnostic timeline table in report.
		 //formatter.header(4,"Diagnostic Table for Discounted Payback");
		 //formatter.flowTable(timeline,columns,headings,money,false,false).format(formatter);
		 //formatter.header(0,"");

		} //initial capital not equal
		}// nonInvestmentSavings & increadedTotalInvestment are positive
		else
			formatter.header(4, "NOTE:  Meaningful SIR, AIRR and Payback can not be computed unless incremental savings and total savings are both positive.");
		} //not financed
		else
     formatter.header(4, "NOTE:  Meaningful SIR, AIRR and Payback can not be computed for Financed Projects.");



    formatter.header(0,"");


    if(project.getAnalysisType() == Project.FINANCEDANALYSIS){
     formatter.header(1, "Comparison of Contract Payments and Savings from Alternative");
     formatter.header(3, "(undiscounted)");
     describeContractPayments(timeline, money).format(formatter);}

   if(alt1.enumerateEnergyUsages().hasMoreElements() || alt2.enumerateEnergyUsages().hasMoreElements()){
    formatter.header(1,"Energy Savings Summary");
    formatter.header(2,"Energy Savings Summary (in stated units)");
    describeEnergySavings(service, end, length).format(formatter);
    formatter.header(2,"Energy Savings Summary (in MBtu)");
    describeMBTUSavings(service, end, length).format(formatter);
    formatter.header(1,"Emissions Reduction Summary");
    describeEmissionsSavings(service, end, length).format(formatter);}

  }


  /* ______________________________________________________________________
     Project Description */


  public Table describeProject(Project project, int level){
    Table desc = new Table(2);
    formatter.header(2,"General Information");
    desc.addRow(level+1,"File Name:",Table.ROWHEADING,
                fileName,Table.RIGHT);
    desc.addRow(level+1,"Date of Study:",Table.ROWHEADING,
                new java.util.Date(),Table.RIGHT);
    desc.addRow(level+1, "Project Name:", Table.ROWHEADING,
                project.getName(), Table.RIGHT);
    desc.addRow(level+1,"Project Location:",Table.ROWHEADING,
                project.getLocation(),Table.RIGHT);
    desc.addRow(level+1,"Analysis Type:",Table.ROWHEADING,
                Project.analysisNames[project.getAnalysisType()],Table.RIGHT);
		if (project.getAnalysisType() == Project.OMBANALYSIS) {
			desc.addRow(level+1,"Analysis Purpose:", Table.ROWHEADING,
								Project.analysisPurposes[project.getAnalysisPurpose()],Table.RIGHT);
		}
    desc.addRow(level+1,"Analyst:",Table.ROWHEADING,
                project.getAnalyst(),Table.RIGHT);
    showComment(desc,level+1,project);
    desc.addRow(level+1,"Base Date:",Table.ROWHEADING,
                project.getBaseDate(),Table.RIGHT);
    if(project.getAnalysisType() == Project.AGENCYFUNDEDANALYSIS)
      desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    else if(project.getAnalysisType() == Project.OMBANALYSIS)
      desc.addRow(level+1,"Service Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    else if (project.getAnalysisType()==Project.MILCONENERGYANALYSIS || project.getAnalysisType()==Project.MILCONNONENERGYANALYSIS)
      desc.addRow(level+1,"Beneficial Occupancy Date:",Table.ROWHEADING,
                project.getServiceDate(),Table.RIGHT);
    String junk = project.getDuration() + "(" + project.getBaseDate() + " through " + project.getEndDate() + ")";
    desc.addRow(level+1,"Study Period:",Table.ROWHEADING,
                junk,Table.RIGHT);
    desc.addRow(level+1,"Discount Rate:",Table.ROWHEADING,
                project.getDiscountRate(),Table.RATE);
    desc.addRow(level+1,"Discounting Convention:",Table.ROWHEADING,
                Project.discountingMethodNames[project.getDiscountingMethod()],
              Table.RIGHT);
    desc.addRow(0,"",Table.COLHEADING);


    return desc; }


  public void showName(Table desc, int level, ModelElement element){
    desc.addRow(level,element.getType(),Table.ROWHEADING,
                element.getName(),Table.RIGHT); }



  public void showComment(Table desc, int level, ModelElement element){
    String comment = element.getComment();
    if(comment!=null && !comment.equals(""))
      desc.addRow(level,"Comment",Table.ROWHEADING,comment,Table.RIGHT); }


 public Table describeEnergySavings(Date service, Date end, double length){

   // all fuel types must have the same units;  if they do NOT, a message will be printed
   // in the report that they must change the units to get this section of the report

   // set up 2 arrays of totals; one for each alternative and an array of units
   // arrays are in same order as FuelType.FUELS

  int numberOfFuels = FuelType.FUELS.length;

   double[] total1 = new double[numberOfFuels];
   for(int i=0;i<total1.length;i++)     // since this is keeping total, intialize
     total1[i]=0.0;
   double[] total2 = new double[numberOfFuels];
   for(int i=0;i<total2.length;i++)
     total2[i]=0.0;
   Units[] units = new Units[numberOfFuels];
   int index=0;
   for(Enumeration e = alt1.enumerateEnergyUsages(); e.hasMoreElements(); )
     {
      EnergyUsage usage = (EnergyUsage) e.nextElement();
        UsageIndex usageIndex = usage.getUsageIndex();
        FuelType fuelType = usage.getFuelType();
        for (int i=0; i < numberOfFuels; i++)
          if (fuelType == FuelType.FUELS[i]){index=i; break;}
        total1[index]+=usageIndex.indexedAmount(usage.getYearlyUsage(), service, end);

        if(units[index] == null) units[index] = usage.getUnits();  // new fuel type?  enter units

        if(units[index] != usage.getUnits()){  // different units, return
         Table tab1 = new Table(1);
				 tab1.addRow(1, "Units for every energy type not the same, can't report energy savings", Table.ROWHEADING);
         tab1.addRow(0,"",Table.COLHEADING);
         return tab1;}
     }

   for(Enumeration e = alt2.enumerateEnergyUsages(); e.hasMoreElements(); )
     {
      EnergyUsage usage = (EnergyUsage) e.nextElement();
        UsageIndex usageIndex = usage.getUsageIndex();
        FuelType fuelType = usage.getFuelType();
        for (int i=0; i < numberOfFuels; i++)
          if (fuelType == FuelType.FUELS[i]){index=i; break;}
        total2[index]+=usageIndex.indexedAmount(usage.getYearlyUsage(), service, end);

        if(units[index] == null) units[index] = usage.getUnits();

        if(units[index] != usage.getUnits()){
         Table tab1 = new Table(1);
         tab1.addRow(1, "Units are not the same for each energy type; can't report energy savings.", Table.ROWHEADING);
         tab1.addRow(0,"",Table.COLHEADING);
          return tab1;}

     }


   Table tab = new Table(5);
   tab.addRow(1,"Energy",Table.ROWHEADING,
       "-----Average",Table.COLHEADING,
      "Annual",Table.COLHEADING,
      "Consumption-----",Table.COLHEADING,
      "Life-Cycle",Table.COLHEADING);
    tab.addRow(1,"Type",Table.ROWHEADING,
       "Base Case",Table.COLHEADING,
       "Alternative",Table.COLHEADING,
       "Savings",Table.COLHEADING,
       "Savings",Table.COLHEADING);

    double consumption1, consumption2, diff=0.0;;

    for(int i=0; i<numberOfFuels;i++){
      consumption1=total1[i];
      consumption2=total2[i];
      if(consumption1==0.0 && consumption2==0.0){}  // both 0.0, do nothing
      else
        tab.addRow(1, FuelType.FUELS[i].getPrettyName(), Table.ROWHEADING,
                  consumption1, units[i],
                  consumption2, units[i],
                  diff=consumption1-consumption2, units[i],
                  diff*length, units[i]);
    }
    tab.addRow(0,"",Table.COLHEADING);
    return tab;}

 public Table describeMBTUSavings(Date service, Date end, double length){

   // set up 2 arrays of totals; one for each alternative and an array of units
   // arrays are in same order as FuelType.FUELS

   int numberOfFuels = FuelType.FUELS.length;

   double[] total1 = new double[numberOfFuels];
   for(int i=0;i<total1.length;i++)     // since this is keeping total, intialize
     total1[i]=0.0;
   double[] total2 = new double[numberOfFuels];
   for(int i=0;i<total2.length;i++)
     total2[i]=0.0;
   int index=0;
   double stdusage, factor, toGJ;

   for(Enumeration e = alt1.enumerateEnergyUsages(); e.hasMoreElements(); )
     {
        EnergyUsage usage = (EnergyUsage) e.nextElement();
        UsageIndex usageIndex = usage.getUsageIndex();
        FuelType fuelType = usage.getFuelType();
        factor=usage.getEmissions().conversionFactor(usage.getUnits());
        toGJ=usage.getEmissions().conversionFactor(Units.GJ);
        for (int i=0; i < numberOfFuels; i++)
          if (fuelType == FuelType.FUELS[i]){index=i; break;}
        stdusage = usageIndex.indexedAmount(usage.getYearlyUsage(), service, end)*factor;
        total1[index]+= Units.convert(stdusage/toGJ,Units.GJ,Units.MBTU);

      }

   for(Enumeration e = alt2.enumerateEnergyUsages(); e.hasMoreElements(); )
     {
      EnergyUsage usage = (EnergyUsage) e.nextElement();
        UsageIndex usageIndex = usage.getUsageIndex();
        FuelType fuelType = usage.getFuelType();
        factor=usage.getEmissions().conversionFactor(usage.getUnits());
        toGJ=usage.getEmissions().conversionFactor(Units.GJ);
        for (int i=0; i < numberOfFuels; i++)
          if (fuelType == FuelType.FUELS[i]){index=i; break;}
        stdusage = usageIndex.indexedAmount(usage.getYearlyUsage(), service, end)*factor;
        total2[index]+=Units.convert(stdusage/toGJ,Units.GJ,Units.MBTU);
     }


   Table tab = new Table(5);
   tab.addRow(1,"Energy",Table.ROWHEADING,
       "-----Average",Table.COLHEADING,
      "Annual",Table.COLHEADING,
      "Consumption-----",Table.COLHEADING,
      "Life-Cycle",Table.COLHEADING);
    tab.addRow(1,"Type",Table.ROWHEADING,
       "Base Case",Table.COLHEADING,
       "Alternative",Table.COLHEADING,
       "Savings",Table.COLHEADING,
       "Savings",Table.COLHEADING);

    double consumption1, consumption2, diff=0.0;;

    for(int i=0; i<numberOfFuels;i++){
      consumption1=total1[i];
      consumption2=total2[i];
      if(consumption1==0.0 && consumption2==0.0){}  // both 0.0, do nothing
      else
        tab.addRow(1, FuelType.FUELS[i].getPrettyName(), Table.ROWHEADING,
                  consumption1, Units.MBTU,
                  consumption2, Units.MBTU,
                  diff=consumption1-consumption2, Units.MBTU,
                  diff*length, Units.MBTU);
    }
    tab.addRow(0,"",Table.COLHEADING);
    return tab;}

 public Table describeEmissionsSavings(Date start, Date end, double length){
   int numberOfFuels = FuelType.FUELS.length;

   double[] c1 = new double[numberOfFuels];
   for(int i=0;i<c1.length;i++)     // since this is keeping total, intialize
     c1[i]=0.0;

   double[] c2 = new double[numberOfFuels];
   for(int i=0;i<c2.length;i++)     // since this is keeping total, intialize
     c2[i]=0.0;

   double[] s1 = new double[numberOfFuels];
   for(int i=0;i<s1.length;i++)     // since this is keeping total, intialize
     s1[i]=0.0;

   double[] s2 = new double[numberOfFuels];
   for(int i=0;i<s2.length;i++)     // since this is keeping total, intialize
     s2[i]=0.0;

   double[] n1 = new double[numberOfFuels];
   for(int i=0;i<n1.length;i++)     // since this is keeping total, intialize
     n1[i]=0.0;

   double[] n2 = new double[numberOfFuels];
   for(int i=0;i<n2.length;i++)     // since this is keeping total, intialize
     n2[i]=0.0;
   int[] usedFuels=new int[numberOfFuels];

   int index=0;


   for(Enumeration e = alt1.enumerateEnergyUsages(); e.hasMoreElements(); )
     {
      EnergyUsage usage = (EnergyUsage) e.nextElement();
        FuelType fuelType = usage.getFuelType();
        for (int i=0; i < numberOfFuels; i++)
          if (fuelType == FuelType.FUELS[i]){index=i; usedFuels[i]=10;break;}

        c1[index]+=analysis.getAmount(usage,Category.EMISSIONS_CO2,Units.KG,start,end,false);
        s1[index]+=analysis.getAmount(usage,Category.EMISSIONS_SOx,Units.KG,start,end,false);
        n1[index]+=analysis.getAmount(usage,Category.EMISSIONS_NOx,Units.KG,start,end,false);
     }

   for(Enumeration e = alt2.enumerateEnergyUsages() ; e.hasMoreElements(); )
     {
      EnergyUsage usage = (EnergyUsage) e.nextElement();
        FuelType fuelType = usage.getFuelType();
        for (int i=0; i < numberOfFuels; i++)
          if (fuelType == FuelType.FUELS[i]){index=i;usedFuels[i]=10;break;}  // 5-29-01 added usedFuels[i]=10; otherwise, fuel only in alt will not show up in report

        c2[index]+=analysis.getAmount(usage,Category.EMISSIONS_CO2,Units.KG,start,end,false);
        s2[index]+=analysis.getAmount(usage,Category.EMISSIONS_SOx,Units.KG,start,end,false);
        n2[index]+=analysis.getAmount(usage,Category.EMISSIONS_NOx,Units.KG,start,end,false);

     }


   Table tab = new Table(5);
   tab.addRow(1,"Energy",Table.ROWHEADING,
       "-----Average",Table.COLHEADING,
      "Annual",Table.COLHEADING,
      "Emissions-----",Table.COLHEADING,
      "Life-Cycle",Table.COLHEADING);
    tab.addRow(1,"Type",Table.ROWHEADING,
       "Base Case",Table.COLHEADING,
       "Alternative",Table.COLHEADING,
       "Reduction",Table.COLHEADING,
       "Reduction",Table.COLHEADING);

    double x1, x2, diff=0.0;
    for(int i=0; i<numberOfFuels;i++){
     if(usedFuels[i] == 10){
       tab.addRow(1, FuelType.FUELS[i].getPrettyName(), Table.ROWHEADING,
                  "", Table.COLHEADING,
                  "", Table.COLHEADING,
                  "", Table.COLHEADING,
                  "", Table.COLHEADING);
        tab.addRow(1,"CO2", Table.COLHEADING,
                  x1=c1[i]/length, Units.KG,
                  x2=c2[i]/length, Units.KG,
                  diff=x1-x2, Units.KG,
                  diff*length, Units.KG);
       tab.addRow(1,"SO2", Table.COLHEADING,
                  x1=s1[i]/length, Units.KG,
                  x2=s2[i]/length, Units.KG,
                  diff=x1-x2, Units.KG,
                  diff*length, Units.KG);
       tab.addRow(1,"NOx", Table.COLHEADING,
                  x1=n1[i]/length, Units.KG,
                  x2=n2[i]/length, Units.KG,
                  diff=x1-x2, Units.KG,
                  diff*length, Units.KG);}
  }
      tab.addRow(1, "Total:", Table.ROWHEADING,
                  "", Table.COLHEADING,
                  "", Table.COLHEADING,
                  "", Table.COLHEADING,
                  "", Table.COLHEADING);
       tab.addRow(1,"CO2", Table.COLHEADING,
                  x1=analysis.getAmount(alt1,Category.EMISSIONS_CO2,Units.KG,start,end,false)/length, Units.KG,
                  x2=analysis.getAmount(alt2,Category.EMISSIONS_CO2,Units.KG,start,end,false)/length, Units.KG,
                  diff=x1-x2, Units.KG,
                  diff*length, Units.KG);
       tab.addRow(1,"SO2", Table.COLHEADING,
                  x1=analysis.getAmount(alt1,Category.EMISSIONS_SOx,Units.KG,start,end,false)/length, Units.KG,
                  x2=analysis.getAmount(alt2,Category.EMISSIONS_SOx,Units.KG,start,end,false)/length, Units.KG,
                  diff=x1-x2, Units.KG,
                  diff*length, Units.KG);
       tab.addRow(1,"NOx", Table.COLHEADING,
                  x1=analysis.getAmount(alt1,Category.EMISSIONS_NOx,Units.KG,start,end,false)/length, Units.KG,
                  x2=analysis.getAmount(alt2,Category.EMISSIONS_NOx,Units.KG,start,end,false)/length, Units.KG,
                  diff=x1-x2, Units.KG,
                  diff*length, Units.KG);

    return tab;}

 public Table describeContractPayments(Date[] timeline, Units money){

  Category[] cats = {Category.COST_CONTRACT,Category.COST_OMR_ENERGY,Category.COST_OMR,Category.COST};

  double[][] amounts1  = analysis.getAmount(alt1, cats, money, timeline, false);
  double[][] amounts2  = analysis.getAmount(alt2, cats, money, timeline, false);

  int rows = timeline.length-1;

  Table tab = new Table(5);

  tab.addRow(1, "", Table.ROWHEADING,
              "Savings in", Table.COLHEADING,
              "Savings in", Table.COLHEADING,
              "Savings in", Table.COLHEADING,
              "Savings in", Table.COLHEADING);

  tab.addRow(1, "Year Beginning", Table.ROWHEADING,
              "Contract Costs", Table.COLHEADING,
              "Energy Costs", Table.COLHEADING,
              "Total Operational Costs", Table.COLHEADING,
              "Total Costs", Table.COLHEADING);

  for(int i=0; i<rows; i++)
     tab.addRow(1,timeline[i].formatAsMonth(), Table.ROWHEADING,
                amounts1[0][i] - amounts2[0][i], money,
                amounts1[1][i] - amounts2[1][i], money,
                amounts1[2][i] - amounts2[2][i], money,
                amounts1[3][i] - amounts2[3][i], money);
  tab.addRow(0,"",Table.COLHEADING);
 return tab;}










}
