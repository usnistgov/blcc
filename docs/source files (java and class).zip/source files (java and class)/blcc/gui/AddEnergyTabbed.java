package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import blcc.model.EnergyUsage;
import blcc.model.Alternative;
import blcc.model.Project;
import blcc.util.FuelType;
import blcc.model.ModelElement;
import java.util.Vector;

public class AddEnergyTabbed extends TabbedPane {
  JComboBox energyType;
  Chooser copyInput;
  JButton copyButton, addButton;
  FormPanel addPanel, copyPanel;
  JLabel addLabel, copyLabel;


  public AddEnergyTabbed(BLCC5 blcc) {
    super(blcc);
    TabPanel tab = new TabPanel();
    addPanel = new FormPanel("");

    addPanel.addField(addLabel=Factory.makeLabel(""),
		      energyType = new Chooser(FuelType.FUELS));

    tab.addSubPanel(addPanel);
    tab.addSubPanel(Factory.makeButtonSubPanel(
         addButton = new JButton ("")));
    addButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	  BLCCTreeNode node = owner.getCurrentNode();
	  FuelType fuel = (FuelType)energyType.getSelectedItem();
	  EnergyUsage energy = new EnergyUsage();
	  energy.setFuelType(fuel);
	  energy.setName(fuel.getPrettyName());
	  ((Alternative) node.getParentElement()).addEnergyUsage(energy);
	  owner.createEnergySubNode(node, energy, true);
	  owner.setNeedsSave(true);
	}});

   copyPanel = new FormPanel("");
   copyPanel.addField(copyLabel=Factory.makeLabel(""),
                copyInput = new Chooser());
   tab.addSubPanel(copyPanel);
   tab.addSubPanel(Factory.makeButtonSubPanel(copyButton = new JButton("")));

   copyButton.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {
    EnergyUsage currentEnergy= (EnergyUsage)copyInput.getChoice();
    EnergyUsage newEnergy = currentEnergy.copyEnergyUsage();
    BLCCTreeNode node = owner.getCurrentNode();
    ((Alternative) node.getParentElement()).addEnergyUsage(newEnergy);
    owner.createEnergySubNode(node, newEnergy, true);
    owner.setNeedsSave(true); }});

    copyButton.setEnabled(false);

    addTab("", tab); }


    public void getInformation(ModelElement element) {

    Vector energy = owner.getProject().getEnergyChoices();

    if(energy.size() != 0){
     copyInput.setChoices(energy);
     copyButton.setEnabled(true);}
    else
    {
     String choices[] ={"None"};
     copyInput.setChoices(choices);
     copyButton.setEnabled(false);}
    }

  public void setAnalysisSpecific(int analysisType) {
    if (analysisType == Project.MILCONECIPANALYSIS){
      addLabel.setText("Savings/Cost Name:");
      setTitleAt(0, "Add Energy Savings/Cost");
      ((javax.swing.border.TitledBorder) addPanel.getBorder()).setTitle("Create New Savings/Cost");
      addButton.setText("Create Savings/Cost");
      ((javax.swing.border.TitledBorder) copyPanel.getBorder()).setTitle("Copy Existing Savings/Cost");
      copyButton.setText("Copy Savings/Cost");
      copyLabel.setText("Savings/Cost to Copy:");}
    else {
      addLabel.setText("Cost Name:");
      setTitleAt(0, "Add Energy Cost");
      ((javax.swing.border.TitledBorder) addPanel.getBorder()).setTitle("Create New Cost");
      addButton.setText("Create Cost");
      ((javax.swing.border.TitledBorder) copyPanel.getBorder()).setTitle("Copy Existing Cost");
      copyButton.setText("Copy Cost");
      copyLabel.setText("Cost to Copy:");}
   }


}
