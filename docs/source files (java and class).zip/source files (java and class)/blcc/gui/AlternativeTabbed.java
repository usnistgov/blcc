package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import blcc.model.Alternative;
import blcc.model.CapitalComponent;
import blcc.model.ModelElement;
import blcc.model.Project;
import javax.swing.event.*;
import java.awt.GridBagConstraints;
import java.util.Vector;
import blcc.model.SimpleEscalation;
import javax.swing.tree.TreePath;
import blcc.util.DateDiff;
import blcc.util.Defaults;
import blcc.util.DOEPrices;
import java.util.Vector;
import blcc.util.Defaults;



public class AlternativeTabbed extends TabbedPane {
  Alternative alternative;
  JButton deleteButton;
  TextField alternativeName;
  TextArea comments;
  TextField componentName;
  JButton addButton;

  Chooser copyInput;
  JButton copyButton;

  TipsSubPanel generalTips;

  public AlternativeTabbed(BLCC5 blcc){
    super(blcc);
    addTab("General Information", getGeneralTab());
    addTab("Add Component", getAddComponentTab());
    addTab("Delete", getDeleteTab());
  }

  public void getInformation(ModelElement element) {
    alternative=(Alternative)element;

    Vector comps = owner.getProject().getComponentChoices();

    if(comps.size() != 0){
     copyInput.setChoices(comps);
     copyButton.setEnabled(true);}
    else
    {
     String choices[] ={"None"};
     copyInput.setChoices(choices);
     copyButton.setEnabled(false);}

    alternativeName.setValue(alternative.getName());
    comments.setValue(alternative.getComment());
  }

  public Boolean guiValidate(ModelElement element) {
    return new Boolean(true); }

  public void setInformation(ModelElement element) {}

  public JPanel getGeneralTab() {
    String tips[] = {"", "", "", ""};
    TabPanel tab = new TabPanel();
    FormPanel panel = new FormPanel("General Alternative Information");
    panel.addField(Factory.makeLabel("Name:"),
		   alternativeName = new TextField());
    alternativeName.addChangedListener(owner);
    alternativeName.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  alternative.setName(alternativeName.getValue()); }});
  alternativeName.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {comments.requestFocus(); }});


    panel.addCommentField(Factory.makeLabel("Comment:"),
			  new JScrollPane(comments = new TextArea()));
    comments.addChangedListener(owner);
    comments.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  alternative.setComment(comments.getValue()); }});

    tab.addSubPanel(panel);
    tab.addSpacerPanel();
    tab.addSubPanel(generalTips=new TipsSubPanel(tips));
    return tab; }

  public JPanel getAddComponentTab() {
    TabPanel tab = new TabPanel();
    FormPanel panel = new FormPanel("Create New Component");
    panel.addField(Factory.makeLabel("Component Name:"),
		      componentName = new TextField());
    componentName.addCaretListener(new CaretListener(){
  public void caretUpdate(CaretEvent e){
	  addButton.setEnabled(!componentName.getValue().equals("")); }});


    tab.addSubPanel(panel);
    tab.addSubPanel(Factory.makeButtonSubPanel(
    addButton = new JButton("Create Component")));
    addButton.setEnabled(false);
    addButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  BLCCTreeNode altNode = owner.getCurrentNode();
	  CapitalComponent component = new CapitalComponent();
	  ((Alternative)altNode.getElement()).addCapitalComponent(component);
	  component.setName(componentName.getText());
    owner.createComponentNode(altNode, component,true,false);
	  owner.setNeedsSave(true);
	  componentName.setValue("");
      }});

   FormPanel panel2 = new FormPanel("Copy Existing Component");
   panel2.addField(Factory.makeLabel("Component to Copy:"),
                copyInput = new Chooser());

   tab.addSubPanel(panel2);
   tab.addSubPanel(Factory.makeButtonSubPanel(copyButton = new JButton("Copy Component")));

   copyButton.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {
    CapitalComponent currentComp= (CapitalComponent)copyInput.getChoice();
    CapitalComponent newComp = currentComp.copyCapitalComponent();
    BLCCTreeNode altNode = owner.getCurrentNode();
    ((Alternative)altNode.getElement()).addCapitalComponent(newComp);
    owner.createComponentNode(altNode, newComp, true, false);
    owner.setNeedsSave(true); }});
    copyButton.setEnabled(false);
   return tab;  }

  public JPanel getDeleteTab() {
    TabPanel tab = new TabPanel();
    tab.addSubPanel(Factory.makeButtonSubPanel(
	       deleteButton = new JButton ("Delete This Alternative")));
    deleteButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e) {
    if (owner.confirmDelete("alternative") == JOptionPane.YES_OPTION) {
	    BLCCTreeNode selectedNode = (BLCCTreeNode)owner.getTree().getSelectionPath().getLastPathComponent();
	    owner.getProject().removeAlternative((Alternative)selectedNode.getElement());
	    owner.getTreeModel().removeNodeFromParent(selectedNode);
	    owner.setPreviousNode(null);
	    owner.getTree().setSelectionRow(0);
	    owner.setNeedsSave(true);
	  }}});
    return tab; }

  public void setAnalysisSpecific(int analysisType) {
    if (analysisType == Project.MILCONECIPANALYSIS){
      if(indexOfTab("Delete")!= -1){removeTabAt(2);}
      if(indexOfTab("Add Component")!= -1){removeTabAt(1);}
			String tips[]={"Cost differences (e.g., operational savings, additional investment costs) for alternative"+
			                "relative to base case are needed for ECIP report."};
			generalTips.setTipsText(tips); }
   else{
     if (indexOfTab("Add Component")== -1){addTab("Add Component", getAddComponentTab());}
     if (indexOfTab("Delete")== -1){addTab("Delete", getDeleteTab());}
		 String tips[]={"One of the alternatives can be the do-nothing case.",
                  "Enter Energy and Water Costs at the alternative level, other OM&R and "
                   +"Replacement costs at the component level."};
			generalTips.setTipsText(tips);}
  }



}
