package blcc.gui.widgets;

import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Component;
import javax.swing.SwingConstants;

public class RadioButton extends JRadioButton {
   private boolean initialValue;
   private ChangedListenerList cvlist=new ChangedListenerList();

  public RadioButton(String name){
    super(name);
    setForeground(Color.black);
    setAlignmentX(Component.LEFT_ALIGNMENT);
    setAlignmentY(Component.TOP_ALIGNMENT);
    setVerticalAlignment(SwingConstants.TOP);
    addActionListener(new ActionListener(){
     public void actionPerformed(ActionEvent e) { updateValue(); }}); }


public void setValue(boolean value){
   setSelected(initialValue = value);}

public boolean getValue(){
   return isSelected();}

protected boolean updateValue(){
    boolean value = getValue();
    if(value != initialValue){
       if(cvlist.fireAllowChange(this)) {
        initialValue = value;
        cvlist.fireChanged(this); }
      else
        setValue(initialValue); }
    return initialValue; }

  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }


}

