package blcc.gui.widgets;
import blcc.model.ModelElement;
import java.util.EventObject;

/** An Event signalled when a Widget's value has been changed from
 * its initial value. */
public class ChangedEvent extends EventObject {
  public ChangedEvent(Object source){
    super(source); }
}

    
