package blcc.gui.widgets;

import blcc.util.DateDiff;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.CellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.DefaultTableCellRenderer;
import java.text.ParseException;
import java.awt.Toolkit;
import java.awt.Component;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.InputMethodEvent;

public class DateDiffField extends JTextField {
  private DateDiff initialValue;
  private ChangedListenerList cvlist=new ChangedListenerList();

  public DateDiffField() {
    super(15);
    setHorizontalAlignment(JTextField.RIGHT);
    addFocusListener(new FocusListener(){
	public void focusGained(FocusEvent e) { selectAll(); }
	public void focusLost(FocusEvent e) { updateValue();  }});
  }

 // workaround for bug 4247522 (Mnemonic character appear in JTextComponents)
 //in 1.2; should be fixed in 1.3;
 protected synchronized void processComponentKeyEvent(KeyEvent anEvent)
      {
      super.processComponentKeyEvent(anEvent);
      // if the alt key is pressed, we don't want any input in the text-field
      ivLastKeyEventWasAlt = anEvent.isAltDown();
      }
   protected synchronized void processInputMethodEvent(InputMethodEvent e)
      {
      if (ivLastKeyEventWasAlt)
         {
         e.consume();
         }
      super.processInputMethodEvent(e);
      }
   private transient boolean ivLastKeyEventWasAlt = false;
 // end of workaround


  public DateDiff getValue() {
    DateDiff retVal = DateDiff.YEAR;
    try {
      retVal = DateDiff.valueOf(getText());
    } catch (ParseException e) {
      Toolkit.getDefaultToolkit().beep(); }
    return retVal; }

  public void setValue(DateDiff value) {
    initialValue = value;
    setText(DateDiff.toString(value)); }

  protected DateDiff updateValue(){
    DateDiff value = getValue();
    if(! value.equals(initialValue)){
      if(cvlist.fireAllowChange(this)) {
	setValue(value);
	cvlist.fireChanged(this); }
      else
	setValue(initialValue); }
  else setText(DateDiff.toString(initialValue)); //is initial value, call set
                                                 //Text to make sure "years"/"months" are shown; otherwise whatever user types will
                                                 // be shown (eg 7y 8m)

    return initialValue; }

  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }

  public CellEditor getCellEditor(){
    DefaultCellEditor ce =
      new DefaultCellEditor(this){
	  public Object getCellEditorValue(){
	    return ((DateDiffField)editorComponent).updateValue(); }
	  public Component getTableCellEditorComponent(JTable tab, Object val,
						       boolean sel,
						       int row, int col){
	    Component c = super.getTableCellEditorComponent(tab,val,sel,row,col);
	    ((DateDiffField)c).setValue((DateDiff)val);
	    return c; }
	};
    ce.setClickCountToStart(1);
    return ce; }

  public TableCellRenderer getCellRenderer(){
    final DateDiffField field = this;
    return new DefaultTableCellRenderer(){
	public Component getTableCellRendererComponent(JTable tab, Object val,
						       boolean sel,boolean foc,
						       int row, int col){
	  JLabel c = (JLabel) super.getTableCellRendererComponent(tab,val,
								  sel,foc,
								  row,col);
	  c.setText(DateDiff.toString((DateDiff)val));
	  c.setHorizontalAlignment(JLabel.RIGHT);
	  return c; }
      }; }
}
