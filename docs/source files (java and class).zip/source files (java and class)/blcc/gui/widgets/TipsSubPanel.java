package blcc.gui.widgets;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.BoxLayout;
import java.awt.Component;
import javax.swing.BorderFactory;
import javax.swing.border.TitledBorder;

public class TipsSubPanel extends JPanel {

  JTextArea text;

  public TipsSubPanel(String[] tips) {
    super();
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    setBorder(BorderFactory.createTitledBorder("Tips"));

    text = new JTextArea(tips.length,60);
    text.setLineWrap(true);
    text.setWrapStyleWord(true);
    text.setEditable(false);
    setTipsText(tips);
    JScrollPane tipsScroll = new JScrollPane(text);
    text.setCaretPosition(0);

    add(tipsScroll);
   }

 public void setTipsText(String[] tips) {
    StringBuffer buf = new StringBuffer();
    for(int i=0; i<tips.length; i++){
      buf.append(" - ");
      buf.append(tips[i]);
      buf.append("\n"); }
    text.setText(buf.toString());
    text.setCaretPosition(0);
  }
}
