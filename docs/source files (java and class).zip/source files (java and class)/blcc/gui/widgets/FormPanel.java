package blcc.gui.widgets;

import javax.swing.*;
import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.border.TitledBorder;
import java.awt.FlowLayout;


public class FormPanel extends JPanel {
  GridBagLayout layout = new GridBagLayout();
  GridBagConstraints constraints = new GridBagConstraints();


  public FormPanel(){
    super();
    setAlignmentX(Component.CENTER_ALIGNMENT);
    setAlignmentY(Component.TOP_ALIGNMENT);
    setLayout(layout);}


  public FormPanel(String name){
    super();
    setAlignmentX(Component.CENTER_ALIGNMENT);
    setAlignmentY(Component.TOP_ALIGNMENT);
    setBorder(BorderFactory.createTitledBorder(name));
    setLayout(layout);}

  public void addCommentField(JLabel jlabel, Component widget){
    constraints.anchor = GridBagConstraints.NORTHWEST;
    constraints.fill = GridBagConstraints.BOTH;
    constraints.ipadx = 10;
    constraints.ipady = 25;
    constraints.gridwidth=1;
    layout.setConstraints(jlabel,constraints);
    add(jlabel);
    constraints.gridwidth=GridBagConstraints.REMAINDER;

    layout.setConstraints(widget,constraints);
    add(widget);
  }
  public void addField(Component widget){
    constraints.anchor = GridBagConstraints.NORTHWEST;
    constraints.fill = GridBagConstraints.HORIZONTAL;
    constraints.ipadx = 10;
    constraints.ipady = 0;
    constraints.gridwidth=GridBagConstraints.REMAINDER;
    layout.setConstraints(widget,constraints);
    add(widget);
  }
  public void addField(Component widget1, Component widget2){
    constraints.anchor = GridBagConstraints.NORTHWEST;
    constraints.fill = GridBagConstraints.BOTH;
    constraints.ipadx = 10;
    constraints.ipady = 0;
    constraints.gridwidth=1;
    layout.setConstraints(widget1,constraints);
    add(widget1);
    constraints.gridwidth=GridBagConstraints.REMAINDER;
    constraints.fill = GridBagConstraints.HORIZONTAL;
    layout.setConstraints(widget2,constraints);
    add(widget2);
  }
  public void addField(Component widget1, Component widget2, Component widget3){
    constraints.anchor = GridBagConstraints.NORTHWEST;
    constraints.fill = GridBagConstraints.NONE;
    constraints.ipadx = 10;
    constraints.ipady = 0;
    constraints.gridwidth=1;
    layout.setConstraints(widget1,constraints);
    add(widget1);
    layout.setConstraints(widget2, constraints);
    add(widget2);
    constraints.gridwidth=GridBagConstraints.REMAINDER;
    constraints.fill = GridBagConstraints.HORIZONTAL;
    layout.setConstraints(widget3,constraints);
    add(widget3);
  }
  public void addField(JLabel jlabel, Component widget){
    constraints.anchor = GridBagConstraints.NORTHWEST;
    constraints.ipadx = 10;
    constraints.ipady = 0;
    constraints.gridwidth=1;
    constraints.fill = GridBagConstraints.NONE;
    layout.setConstraints(jlabel,constraints);
    add(jlabel);
    constraints.gridwidth=GridBagConstraints.REMAINDER;
    constraints.fill = GridBagConstraints.HORIZONTAL;
    layout.setConstraints(widget,constraints);
    add(widget);
  }

 public void changeLayout(){
	Component widget1 = getComponent(0);
	Component widget2 = getComponent(1);

	removeAll();
	addField(widget1, widget2);
 }

 public void changeLayout3(){
	 Component widget1 = getComponent(0);
	 Component widget2 = getComponent(1);
	 Component widget3 = getComponent(2);
	 Component widget4 = getComponent(3);
	 Component widget5 = getComponent(4);
	 Component widget6 = getComponent(5);
	 removeAll();

	 addField(widget1,widget2);
	 addField(widget3,widget4);
	 addField(widget5,widget6);

 }
}
