package blcc.gui.widgets;
import blcc.util.Date;
import javax.swing.*;
import javax.swing.table.*;

public class KeyDatesTableAdaptor extends AbstractTableModel {
  final int MAX=20;
  String descriptions[] = new String[MAX];
  Date dates[] = new Date[MAX];
  int nrows = 1;
  Class coltypes[]={String.class, Date.class};
   boolean editable = true;

  public KeyDatesTableAdaptor() {
    super();}

  public Class getColumnClass(int column){
   return coltypes[column]; }

  public int getColumnCount() {
    return 2; }

  public String getColumnName(int column){
    return (column == 0 ? "Description": "Date");}

  public int getRowCount(){
    return nrows; }

  public Object getValueAt(int row, int column){
    if (column == 0)
      return descriptions[row];
    else
      return dates[row]; }

  public void setEditable(boolean editable){
    this.editable=editable; }

  public boolean isCellEditable(int row, int column){
   return false;}
   // return true;}

  public void setCellEditors(JTable table){
   final DateField dateField = new DateField();
   table.setDefaultEditor(Date.class,
			  (TableCellEditor)dateField.getCellEditor());
   //DefaultCellEditor ce = (DefaultCellEditor) table.getDefaultEditor(String.class);
   //   ce.setClickCountToStart(1);
   //table.setCellSelectionEnabled(true);
  }

  public void setValueAt(Object value, int row, int column){
    boolean redo=false;
    if (column == 0){
      descriptions[row] = (String)value;
      if (row == nrows-1) nrows = nrows+1;  // if last row, give a new one
      redo = true;}
     else if (column == 1)
      dates[row] = (Date)value;
    if (redo)
      fireTableDataChanged();
  }
}
