package blcc.gui.widgets;

import javax.swing.JTextField;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Toolkit;
import java.awt.Component;
import javax.swing.CellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.AttributeSet;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.awt.event.KeyEvent;
import java.awt.event.InputMethodEvent;

public class DoubleField extends JTextField {
  private DecimalFormat formatter;
  private boolean signed=true;
  private boolean dollar = false;
  private boolean percent = false;
  private double initialValue;
  private ChangedListenerList cvlist=new ChangedListenerList();

  public DoubleField() {
    this((DecimalFormat)DecimalFormat.getInstance(),true);}

  public DoubleField(String format){
    this(new DecimalFormat(format));}

  public DoubleField(DecimalFormat formatter) {
    this(formatter,true);}

  public DoubleField(String format, boolean signed){
    this(new DecimalFormat(format),signed);}

  public DoubleField(DecimalFormat formatter, boolean signed) {
    super(formatter.toPattern().length());
    this.formatter = formatter;
    this.signed = signed;
    String format = formatter.toPattern();
    dollar = (format.indexOf('$') >= 0);
    percent= (format.indexOf('%') >= 0);
    setHorizontalAlignment(JTextField.RIGHT);
    addFocusListener(new FocusListener(){
	public void focusGained(FocusEvent e) { selectAll(); }
	public void focusLost(FocusEvent e) { updateValue();  }});
  }

 // workaround for bug 4247522 (Mnemonic character appear in JTextComponents)
 //in 1.2; should be fixed in 1.3;
 protected synchronized void processComponentKeyEvent(KeyEvent anEvent)
      {
      super.processComponentKeyEvent(anEvent);
      // if the alt key is pressed, we don't want any input in the text-field
      ivLastKeyEventWasAlt = anEvent.isAltDown();
      }
   protected synchronized void processInputMethodEvent(InputMethodEvent e)
      {
      if (ivLastKeyEventWasAlt)
         {
         e.consume();
         }
      super.processInputMethodEvent(e);
      }
   private transient boolean ivLastKeyEventWasAlt = false;
 // end of workaround


  public DecimalFormat getFormatter(){
    return formatter; }

  public double getValue() {
    double retVal = 0.0;
    String text = getText();
    boolean negative=false;

    if(signed) negative=(text.indexOf('-') == 0);
    if (dollar && !negative && (text.indexOf('$')<0)) text="$"+text;
    if (percent && (text.indexOf('%')<0)) text=text+"%";
    if (dollar && negative && (text.indexOf('$')<0))
       text = new StringBuffer(text).insert(1,'$').toString();  // add $ to negative number (example, -34 becomes -$34 -- not $-34)

    try {retVal = formatter.parse(text).doubleValue();}
    catch (ParseException e) {
      Toolkit.getDefaultToolkit().beep();}
    return retVal; }

  public void setValue(double value) {
    String s = formatter.format(value);
    try {
      initialValue = formatter.parse(s).doubleValue(); // `rounded'
    } catch (ParseException e) {
      initialValue=0.0; }	// ??
    setText(s); }

  protected double updateValue(){
    double value = getValue();
    if(value != initialValue){
      if(cvlist.fireAllowChange(this)) {
	setValue(value);
	cvlist.fireChanged(this); }
      else
	setValue(initialValue); }
  else // is initialValue; call setText to make sure $, commas, decimal points etc are shown
    setText(formatter.format(initialValue));
  return initialValue; }

  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }

  public CellEditor getCellEditor(){
    DefaultCellEditor ce =
      new DefaultCellEditor(this){
	  public Object getCellEditorValue(){
	    return new Double(((DoubleField)editorComponent).updateValue()); }
	  public Component getTableCellEditorComponent(JTable tab, Object val,
						       boolean sel,
						       int row, int col){
	    DoubleField c =
	      (DoubleField) super.getTableCellEditorComponent(tab,val,sel,
							      row,col);
	    c.setValue(((Double)val).doubleValue());
	    return c; }};
    ce.setClickCountToStart(1);
    return ce; }

  public TableCellRenderer getCellRenderer(){
    final DoubleField field = this;
    return new DefaultTableCellRenderer(){
	public Component getTableCellRendererComponent(JTable tab, Object val,
						       boolean sel,boolean foc,
						       int row, int col){
	  JLabel c = (JLabel) super.getTableCellRendererComponent(tab,val,
								  sel,foc,
								  row,col);
	  c.setText(field.formatter.format(((Double)val).doubleValue()));
	  c.setHorizontalAlignment(JLabel.RIGHT);
	  return c; }}; }

  protected Document createDefaultModel(){
    return  new PlainDocument() {
	public void insertString(int offs, String str, AttributeSet a)
	  throws BadLocationException {
	  String cur = getText(0, getLength());

	  if (testParse(cur.substring(0, offs) + str + cur.substring(offs)))
	    super.insertString(offs, str, a);
    else
	    Toolkit.getDefaultToolkit().beep();

	}

	public void remove(int offs, int len) throws BadLocationException {
	  String cur = getText(0, getLength());

	  if (testParse(cur.substring(0, offs) + cur.substring(len + offs)))
	    super.remove(offs, len);
	  else
	    Toolkit.getDefaultToolkit().beep();
	}

	boolean testParse(String s){
	  int i=0;
	  int l=s.length();
	  char c;
	  while((i<l) && (s.charAt(i)==' ')) i++;
	  if   ((i<l) && signed && (s.charAt(i)=='-')) i++;
    while((i<l) && (s.charAt(i)==' ')) i++;
    if   ((i<l) && dollar && s.charAt(i)=='$') i++;
    //while((i<l) && (s.charAt(i)==' ')) i++;
    //if   ((i<l) && signed && (s.charAt(i)=='-')) i++;
	  while((i<l) && ((((c=s.charAt(i)) >= '0') && (c <= '9')) || (c==','))) i++;
	  if   ((i<l) && (s.charAt(i)=='.')) i++;
	  while((i<l) && (((c=s.charAt(i)) >= '0') && (c <= '9'))) i++;
	  while((i<l) && (s.charAt(i)==' ')) i++;
	  if   ((i<l) && percent && s.charAt(i)=='%') i++;
	  while((i<l) && (s.charAt(i)==' ')) i++;

	  return (i==l); }
      }; }
}
