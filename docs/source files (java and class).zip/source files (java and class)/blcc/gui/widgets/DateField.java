package blcc.gui.widgets;

import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.CellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JCheckBox;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Component;
import blcc.util.Date;
import blcc.util.Defaults;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class DateField extends JPanel implements ChangedListener {
  Date initialValue;
  YearField year ;
  Chooser month;
  private ChangedListenerList cvlist=new ChangedListenerList();

  static String months[] = {"January", "February", "March",  "April",
			    "May", "June", "July","August",
			    "September","October","November","December"};
  public DateField() {
    super();
    setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
    add(month = new Chooser(months));
    month.setChoice(3);
    month.setAlignmentY(Component.TOP_ALIGNMENT);
    month.setAlignmentX(Component.LEFT_ALIGNMENT);
    add(year = new YearField());
    month.addChangedListener(this);
    year.addChangedListener(this);
	}

 public YearField getYearField(){
    return year;}
 public Chooser getMonthField(){
    return month;}


  public Date getValue() {
    Date retVal = null;
    try{
      int y = year.getValue();
      int m = month.getSelectedIndex();
      retVal = new Date(y,m,1);
    } catch(Exception e){retVal = new Date(Defaults.getIntegerItem("default year"), Date.APRIL, 1);}

    return retVal; }

  public void setValue(Date date) {
    initialValue = date;
    if (date != null){
      year.setValue(date.getYear());
      month.setSelectedIndex(date.getMonth());}
    else{setValue(new Date(Defaults.getIntegerItem("default year"), Date.APRIL, 1));}
  }

  protected Date updateValue(){
    Date value = getValue();
		if(! value.equals(initialValue)){
      if(cvlist.fireAllowChange(this)) {
	initialValue = value;
	cvlist.fireChanged(this); }
    }
   return initialValue; }

  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }

  /* These get notified if underlying widgets change. */
  public void noteChange(ChangedEvent e){
    updateValue(); }
  public boolean allowChange(ChangedEvent e){
    return cvlist.fireAllowChange(this); } // Pass this one on.

  protected class DateFieldCellEditor extends DefaultCellEditor {
    public DateFieldCellEditor(DateField field){
      super(new JCheckBox());	// Fool the constructor.
      editorComponent=field;
      setClickCountToStart(1); }

    public Object getCellEditorValue(){
      return ((DateField)editorComponent).updateValue(); }
    public Component getTableCellEditorComponent(JTable tab, Object val, boolean isSel,
						 int row, int column){
      ((DateField)editorComponent).setValue((Date)val);
      return editorComponent; }
  };

  public CellEditor getCellEditor(){
    return new DateFieldCellEditor(this); }

  public TableCellRenderer getCellRenderer(){
    return new DefaultTableCellRenderer(){
	public Component getTableCellRendererComponent(JTable tab, Object val,
						       boolean sel,boolean foc,
						       int row, int col){
	  JLabel c = (JLabel) super.getTableCellRendererComponent(tab,val,
								  sel,foc,
								  row,col);
	  c.setText(Date.toString((Date)val));
	  c.setHorizontalAlignment(JLabel.RIGHT);
	  return c; }
      }; }

}
