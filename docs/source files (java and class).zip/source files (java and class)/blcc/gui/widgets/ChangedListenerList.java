package blcc.gui.widgets;
import javax.swing.event.EventListenerList;

public class ChangedListenerList extends EventListenerList {

  public void addChangedListener(ChangedListener l){
    add(ChangedListener.class, l); }

  public void removeChangedListener(ChangedListener l){
    remove(ChangedListener.class, l); }

  public void fireChanged(Object source){
    Object [] listeners = getListenerList();
    ChangedEvent e = null;
    for(int i=listeners.length-2; i>=0; i-=2)
      if(listeners[i] == ChangedListener.class){
	if(e==null)
	  e=new ChangedEvent(source);
	((ChangedListener)listeners[i+1]).noteChange(e); 
      }
  }
  public boolean fireAllowChange(Object source){
    Object [] listeners = getListenerList();
    ChangedEvent e = null;
    for(int i=listeners.length-2; i>=0; i-=2)
      if(listeners[i] == ChangedListener.class){
	if(e==null)
	  e=new ChangedEvent(source);
	if (! ((ChangedListener)listeners[i+1]).allowChange(e))
	  return false;
      }
    return true;
  }
}
	
