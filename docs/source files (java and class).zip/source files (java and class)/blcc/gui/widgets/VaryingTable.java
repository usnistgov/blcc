package blcc.gui.widgets;

import blcc.model.Varying;
import blcc.util.DateDiff;
import blcc.util.Date;
import java.text.DecimalFormat;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellEditor;

/** A Table for editing a Varying. */
public class VaryingTable extends JTable implements ChangedListener {
  Varying varying;
  DecimalFormat valueformatter;
  Adaptor adaptor;

  static final Class columnTypes[]={Date.class, DateDiff.class, Double.class};
  String columnNames[] = {"From Date", "Duration", "Value"};
  DateField dateField;
  DateDiffField datediffField;
  DoubleField doubleField;

  private ChangedListenerList cvlist=new ChangedListenerList();

  public VaryingTable(String valuename, String valueformat){
    this(valuename,new DecimalFormat(valueformat)); }

  public VaryingTable(String valuename, DecimalFormat valueformat){
    this(valuename, new DoubleField(valueformat)); }

  public VaryingTable(String valuename, DoubleField doubleField){
    super();

    dateField = new DateField();
    datediffField = new DateDiffField();
    datediffField.addChangedListener(this);
    this.doubleField=doubleField;
    valueformatter = doubleField.getFormatter();
    doubleField.addChangedListener(this);
    columnNames[2] = valuename;
    setModel(adaptor= new Adaptor());

    setDefaultEditor(Double.class, (TableCellEditor) doubleField.getCellEditor());
    setDefaultEditor(DateDiff.class, (TableCellEditor) datediffField.getCellEditor());
    setDefaultEditor(Date.class, (TableCellEditor) dateField.getCellEditor());
    setDefaultRenderer(Double.class,   doubleField.getCellRenderer());
    setDefaultRenderer(DateDiff.class, datediffField.getCellRenderer());
    setDefaultRenderer(Date.class,     dateField.getCellRenderer());
    setCellSelectionEnabled(true);
  }

  public void setValue(Varying varying){
    this.varying = varying;
    adaptor.fireTableDataChanged(); }

  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }

  /* These get notified if underlying widgets change. */
  public void noteChange(ChangedEvent e){}
  public boolean allowChange(ChangedEvent e){
    return cvlist.fireAllowChange(this); } // Pass this one on.

  protected class Adaptor extends AbstractTableModel {
    public int getColumnCount() { return 3; }
    public Class getColumnClass(int column){ return columnTypes[column]; }
    public String getColumnName(int column){ return columnNames[column]; }

    public int getRowCount(){
      return (varying == null ? 0 : varying.getIntervalCount()+1); }

    public Object getValueAt(int row, int column){
      if (column == 0)      return varying.getDate(row);
      else if (column == 1) return varying.getInterval(row);
      else       return new Double(varying.getValue(row)); }

    public boolean isCellEditable(int row, int column){
      //return (column == 0 ? row == 0 : true); }
      return (column >0); }

    public void setValueAt(Object value, int row, int column){

    if(value.equals(getValueAt(row,column))) return; // no change.
      //if ((column == 0) && (row == 0)){
  //varying.setStartDate((Date)value);
  //fireTableDataChanged(); }
    if (column == 1){
     varying.setInterval(row,(DateDiff)value);
     fireTableDataChanged();}
      else if (column == 2) {
	if(valueformatter.format(value).
	   equals(valueformatter.format(getValueAt(row,column)))) return;
	varying.setValue(row,((Double)value).doubleValue()); }

    cvlist.fireChanged(this);

    }
  }
}
