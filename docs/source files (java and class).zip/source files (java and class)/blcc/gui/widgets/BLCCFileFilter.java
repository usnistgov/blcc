package blcc.gui.widgets;

import javax.swing.filechooser.FileFilter;


public class BLCCFileFilter extends javax.swing.filechooser.FileFilter {

public static final int XML=0;
public static final int HTML=1;

public static final String[] extensions={"xml", "html"};
public static final String[] descriptions={"BLCC5 Project File", "BLCC5 Report File"};

int typeOfFile=0;


public BLCCFileFilter(int type) {
	super();
  typeOfFile = type;
}
public boolean accept(java.io.File f) {

	if(f != null) {
	    if(f.isDirectory()) {
		return true;
	    }
	    String extension = getExtension(f);
      if(extension != null && extension.equals(extensions[typeOfFile])) {
		return true;
	    };
	}
	return false;
	}

public String getDescription() {
  return descriptions[typeOfFile];
}
public static String getExtension(java.io.File f) {
		String ext = null;
		String s = f.getName();
		int i = s.lastIndexOf('.');

		if (i > 0 &&  i < s.length() - 1) {
			ext = s.substring(i+1).toLowerCase();
		}
		return ext;
	}
}
