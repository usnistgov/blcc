package blcc.gui.widgets;

import javax.swing.JTextField;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Toolkit;
import java.awt.Component;
import javax.swing.CellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.AttributeSet;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.awt.event.KeyEvent;
import java.awt.event.InputMethodEvent;

public class YearField extends JTextField {
  private DecimalFormat formatter;
  private int initialValue;
  private ChangedListenerList cvlist=new ChangedListenerList();

  public YearField() {
    super(15);
    formatter =  new DecimalFormat("0000");
    setHorizontalAlignment(JTextField.RIGHT);
    setAlignmentY(Component.TOP_ALIGNMENT);
    setAlignmentX(Component.LEFT_ALIGNMENT);
    addFocusListener(new FocusListener(){
	public void focusGained(FocusEvent e) { selectAll(); }
	public void focusLost(FocusEvent e) { updateValue();  }});
  }

 // workaround for bug 4247522 (Mnemonic character appear in JTextComponents)
 //in 1.2; should be fixed in 1.3;
 protected synchronized void processComponentKeyEvent(KeyEvent anEvent)
      {
      super.processComponentKeyEvent(anEvent);
      // if the alt key is pressed, we don't want any input in the text-field
      ivLastKeyEventWasAlt = anEvent.isAltDown();
      }
   protected synchronized void processInputMethodEvent(InputMethodEvent e)
      {
      if (ivLastKeyEventWasAlt)
         {
         e.consume();
         }
      super.processInputMethodEvent(e);
      }
   private transient boolean ivLastKeyEventWasAlt = false;
 // end of workaround

  public int getValue() {
    int retVal = 0;
     try {
      formatter =  new DecimalFormat("0000");  // workaround for 1.2 bug; will be fixed? in 1.3
      retVal = formatter.parse(getText()).intValue();
    } catch (ParseException e) {
      Toolkit.getDefaultToolkit().beep(); }
    return retVal; }

  public void setValue(int value) {
    formatter =  new DecimalFormat("0000");  // workaround for 1.2 bug; will be fixed? in 1.3
    setText(formatter.format(initialValue = value));  }

  protected int updateValue(){
    int value = getValue();
    if(value != initialValue){
      if(cvlist.fireAllowChange(this)) {
	initialValue= value;
	cvlist.fireChanged(this); }}
    return initialValue; }

  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }

  public CellEditor getCellEditor(){
    DefaultCellEditor ce =
      new DefaultCellEditor(this){
	  public Object getCellEditorValue(){
      return new Integer(((YearField)editorComponent).updateValue()); }
	  public Component getTableCellEditorComponent(JTable tab, Object val,
						       boolean sel,
						       int row, int col){
      YearField c =
        (YearField) super.getTableCellEditorComponent(tab,val,sel,row,col);
	    c.setValue(((Integer)val).intValue());
	    return c; }};
    ce.setClickCountToStart(1);
    return ce; }

  protected Document createDefaultModel() {
    return new PlainDocument() {
	public void insertString(int offs, String str, AttributeSet a)
	  throws BadLocationException {
	  char[] source = str.toCharArray();
	  char[] result = new char[source.length];
	  int j = 0;

	  for (int i = 0; i < result.length; i++) {
      if (Character.isDigit(source[i]) ||  source[i] == ',')
	      result[j++] = source[i];
	    else
        Toolkit.getDefaultToolkit().beep();
	  }
	  super.insertString(offs, new String(result, 0, j), a);
	}}; }
}
