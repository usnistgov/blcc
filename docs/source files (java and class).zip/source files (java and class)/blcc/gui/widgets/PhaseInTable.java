package blcc.gui.widgets;

import blcc.model.PhaseIn;
import blcc.util.DateDiff;
import blcc.util.Date;
import java.text.DecimalFormat;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellEditor;

/** A Table for editing a Varying. */
public class PhaseInTable extends JTable {
  PhaseIn phasein;
  DecimalFormat valueformatter;
  Adaptor adaptor;
  boolean editable = true;

  static final Class columnTypes[]={DateDiff.class, Date.class, Double.class};
  String columnNames[] = {"Years/Months (from Date)", "Date", "Portion"};
  DateDiffField datediffField = new DateDiffField();
  DateField dateField = new DateField();
  DoubleField doubleField;

  private ChangedListenerList cvlist=new ChangedListenerList();

  public PhaseInTable(){
    super();

    doubleField= new DoubleField(new DecimalFormat("##0.0%"));
    valueformatter = doubleField.getFormatter();
    setModel(adaptor= new Adaptor());

    setDefaultEditor(Double.class, (TableCellEditor) doubleField.getCellEditor());
    setDefaultEditor(DateDiff.class, (TableCellEditor) datediffField.getCellEditor());
    setDefaultEditor(Date.class, (TableCellEditor) dateField.getCellEditor());
    setDefaultRenderer(Double.class,   doubleField.getCellRenderer());
    setDefaultRenderer(DateDiff.class, datediffField.getCellRenderer());
    setDefaultRenderer(Date.class,     dateField.getCellRenderer());
    setCellSelectionEnabled(true);
  }

  public void setValue(PhaseIn phasein){
    this.phasein = phasein;
    adaptor.fireTableDataChanged(); }

  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }

  /* These get notified if underlying widgets change. */
  public void noteChange(ChangedEvent e){}
  public boolean allowChange(ChangedEvent e){
    return cvlist.fireAllowChange(this); } // Pass this one on.

  protected class Adaptor extends AbstractTableModel {
    public int getColumnCount() { return 3; }
    public Class getColumnClass(int column){ return columnTypes[column]; }
    public String getColumnName(int column){ return columnNames[column]; }

    public int getRowCount(){
      return (phasein == null ? 0 : phasein.getIntervalCount()); }

    public Object getValueAt(int row, int column){
      if (column == 0)      return phasein.getInterval(row);
      else if (column == 1) return phasein.getDate(row);
      else       return new Double(phasein.getPortion(row)); }

    public boolean isCellEditable(int row, int column){
      return column != 1; }

    public void setValueAt(Object value, int row, int column){
      if(value.equals(getValueAt(row,column))) return; // no change.
      if (column == 0){
				if ( value != DateDiff.FOREVER ) {
					phasein.setInterval(row,(DateDiff)value);
	        fireTableDataChanged(); }
				}
      else if (column == 2) {
	if(valueformatter.format(value).
	   equals(valueformatter.format(getValueAt(row,column)))) return;
	phasein.setPortion(row,((Double)value).doubleValue());
	fireTableDataChanged(); }
      cvlist.fireChanged(this);
    }
  }
}
