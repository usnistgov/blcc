package blcc.gui.widgets;
import blcc.model.ModelElement;

/** An experiment on noting changed VALUES of widget.
 * Currently, not exactly a `listener', but....
 */
public interface ChangedValueListener {
  public boolean allowChange(ModelElement element, String attribute);
  public void noteChange(ModelElement element, String attribute);
}

    
