package blcc.gui.widgets;

import javax.swing.JTextField;
import java.awt.Component;
import javax.swing.CellEditor;
import javax.swing.DefaultCellEditor;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.InputMethodEvent;

public class TextField extends JTextField {
  private String initialValue;
  private ChangedListenerList cvlist=new ChangedListenerList();

  public TextField() {
    this(20);
    setAlignmentY(Component.TOP_ALIGNMENT);
    setAlignmentX(Component.LEFT_ALIGNMENT);
  }

  public TextField(int width){
    super(width);
    addFocusListener(new FocusListener(){
	public void focusGained(FocusEvent e) { selectAll(); }
	public void focusLost(FocusEvent e) { updateValue();  }});
  }

 // workaround for bug 4247522 (Mnemonic character appear in JTextComponents)
 //in 1.2; should be fixed in 1.3;
 protected synchronized void processComponentKeyEvent(KeyEvent anEvent)
      {
      super.processComponentKeyEvent(anEvent);
      // if the alt key is pressed, we don't want any input in the text-field
      ivLastKeyEventWasAlt = anEvent.isAltDown();
      }
   protected synchronized void processInputMethodEvent(InputMethodEvent e)
      {
      if (ivLastKeyEventWasAlt)
         {
         e.consume();
         }
      super.processInputMethodEvent(e);
      }
   private transient boolean ivLastKeyEventWasAlt = false;
 // end of workaround


  public String getValue() {
    return getText(); }

  public void setValue(String value) {
    initialValue = value;
    setText(value); }

  protected String updateValue(){
    String value = getValue();
    if(!value.equals(initialValue)){
      if(cvlist.fireAllowChange(this)) {
	initialValue = value;
	cvlist.fireChanged(this); }
      else
	setValue(initialValue); }
    return initialValue; }

  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }

  public CellEditor getCellEditor(){
    DefaultCellEditor ce =
      new DefaultCellEditor(this){
	  public Object getCellEditorValue(){
	    return ((TextField)editorComponent).updateValue(); }};
    ce.setClickCountToStart(1);
    return ce; }
}
