package blcc.gui.widgets;

import javax.swing.tree.*;
import blcc.model.*;

public class BLCCTreeNode extends DefaultMutableTreeNode {
  int nodeType;
  ModelElement modelElement;

  public final static int PROJECT_NODE = 0;
  public final static int ALTERNATIVE_NODE = 1;
  public final static int COMPONENT_NODE =2;
  public final static int NARC_NODE = 3;
  public final static int ADD_REPLACEMENT_NODE = 4;
  public final static int REPLACEMENT_NODE = 5;
  public final static int ADD_ENERGY_NODE = 6;
  public final static int ENERGY_NODE = 7;
  public final static int WATER_NODE = 8;
  public final static int NARC_CONTRACT_NODE = 9;
  public final static int ADD_NARC_CONTRACT_NODE = 10;
  public final static int ARC_NODE = 11;
  public final static int ADD_ARC_NODE = 12;
  public final static int ADD_WATER_NODE = 13;
  public final static int ADD_NARC_NODE = 14;
  public final static int INVESTMENT_NODE = 15;
  public final static int ARC_CONTRACT_NODE =16;
  public final static int ADD_ARC_CONTRACT_NODE=17;
  // MILCON, Energy
  public final static int REPAIR_AND_REPLACEMENT_NODE=18;
  public final static int ADD_REPAIR_AND_REPLACEMENT_NODE=19;
  public final static int ROUTINE_ARC_NODE=20;
  public final static int ADD_ROUTINE_ARC_NODE=21;
  public final static int ROUTINE_NARC_NODE=22;
  public final static int ADD_ROUTINE_NARC_NODE=23;
  public final static int MAJOR_REPAIR_REPLACEMENT_NODE=24;
  public final static int ADD_MAJOR_REPAIR_REPLACEMENT_NODE=25;
  // MILCON, ECIP
  public final static int ALTERNATIVE_SAVINGS_NODE = 26;
  public final static int COMPONENT_SAVINGS_NODE =27;
  public final static int ADD_ARC_SAVINGS_NODE=28;
  public final static int ARC_SAVINGS_NODE=29;
  public final static int ADD_NARC_SAVINGS_NODE=30;
  public final static int NARC_SAVINGS_NODE=31;
  public final static int ADD_ENERGY_SAVINGS_NODE = 32;
  public final static int ENERGY_SAVINGS_NODE = 33;
  public final static int ADD_WATER_SAVINGS_NODE = 34;
  public final static int WATER_SAVINGS_NODE = 35;
  public final static int ECIP_INVESTMENT_NODE = 36;

  public final static int MAXTYPES=37;

  boolean allowsChildren[]={true,  //0
                            true,  //1
                            true,  //2
                            false, //3
                            true,  //4
                            false, //5
                            true,  //6
                            false, //7
                            false, //8
                            false, //9
                            true,  //10
                            false, //11
                            true,  //12
                            true,  //13
                            true,  //14
                            false, //15
                            false, //16
                            true,  //17
                            false, //18
                            true,  //19
                            false, //20
                            true,  //21
                            false, //22
                            true,  //23
                            false, //24
                            true,  //25
                            true,  //26
                            true,  //27
                            true,  //28
                            false, //29
                            true,  //30
                            false, //31
                            true,  //32
                            false, //33
                            true,  //34
                            false, //35
                            false}; //36


  String prefix[]={ "Project",             //0
                    "Alternative",         //1
                    "Capital Component",   //2
                    "Cost",   //NARC       //3
                    "Replacement Costs",   //4
                    "Cost",                //5
                    "Energy Costs",        //6
                    "Cost",                //7
                    "Cost",                //8
                    "Cost",                //9
                    "Contract Costs - Non-Annually Recurring",  //10
                    "Cost",                                     //11
                    "OM&R Costs - Annually Recurring",          //12
                    "Water Costs",                              //13
                    "OM&R Costs - Non-Annually Recurring",      //14
                    "Investment Cost",                          //15
                    "Cost",                                     //16
                    "Contract Costs - Annually Recurring",      //17
                    "Cost",                                     //18
                    "Major Repair and Replacement Costs",       //19
                    "Cost",                                     //20
                    "Routine OM&R Costs - Annually Recurring",  //21
                    "Cost",                                     //22
                    "Routine OM&R Costs - Non-Annually Recurring",  //23
                    "Cost",                                  //24
                    "Major Repair And Replacement Costs",    //25
                    "Savings from Alternative",              //26
                    "Capital Component Savings/Costs",       //27
                    "Annually Recurring Savings/Costs",      //28
                    "Savings/Cost",                          //29
                    "Non-Annually Recurring Savings/Costs",  //30
                    "Savings/Cost",                          //31
                    "Energy Savings/Costs",                  //32
                    "Savings/Cost",                          //33
                    "Water Savings/Costs",                   //34
                    "Savings/Cost",                          //35
                    "Additional Investment Cost"};           //36

  /* A node is forelement if it directly represents a model element.*/
  boolean forelement[]={true,  //0
                        true,  //1
                        true,  //2
                        true,  //3
                        false, //4
                        true,  //5
                        false, //6
                        true,  //7
                        true,  //8
                        true,  //9
                        false, //10
                        true,  //11
                        false, //12
                        false, //13
                        false, //14
                        false, //15
                        true,  //16
                        false, //17
                        true,  //18
                        false, //19
                        true,  //20
                        false, //21
                        true,  //22
                        false, //23
                        true,  //24
                        false, //25
                        true,  //26
                        true,  //27
                        false, //28
                        true,  //29
                        false, //30
                        true,  //31
                        false, //32
                        true,  //33
                        false, //34
                        true,  //35
                        false};//36


  public BLCCTreeNode(int type, ModelElement element) {
    super();
    nodeType = type;
    setElement(element);
  }

  public boolean getAllowsChildren(){
    return allowsChildren[nodeType]; }

  public void setAllowsChildren(int index, boolean children){
    allowsChildren[index] = children;}

  public ModelElement getElement() {
    return modelElement;  }

  public int getNodeType() {
    return nodeType;  }

  public void resetName(){
    String name = prefix[nodeType];
    if(forelement[nodeType]){
	name += ": ";
	name += (modelElement == null ? "<none>" : modelElement.getName()); }
    setUserObject(name); }

  public void setElement(ModelElement element) {
    modelElement = element;
    resetName(); }

  public ModelElement getParentElement(){
    return ((BLCCTreeNode) getParent()).getElement(); }
}
