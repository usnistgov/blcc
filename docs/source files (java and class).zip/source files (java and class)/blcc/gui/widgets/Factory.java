package blcc.gui.widgets;

import javax.swing.*;
import java.awt.Component;
import java.awt.BorderLayout;
import blcc.gui.widgets.*;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.JTextArea;
import blcc.util.Choosable;

public class Factory {


  public static Color makeBlueColor(){
    return new Color(1, 112, 254);
  }

  public static Color backgroundColor(){
    return new Color(224,224,224); }

  public static JPanel makeButtonSubPanel(JButton button){
    JPanel buttonpanel = new JPanel();
    button.setAlignmentX(Component.CENTER_ALIGNMENT);
    buttonpanel.setLayout(new BoxLayout(buttonpanel, BoxLayout.Y_AXIS));
    buttonpanel.add(Box.createRigidArea(new java.awt.Dimension(20, 20)));
    buttonpanel.add(button);
    return buttonpanel;}
  public static JRadioButton makeRadioButton(String text, boolean selected) {
    JRadioButton button = new JRadioButton(text, selected);
    button.setForeground(Color.black);
    button.setAlignmentX(Component.LEFT_ALIGNMENT);
    button.setAlignmentY(Component.TOP_ALIGNMENT);
    button.setVerticalAlignment(SwingConstants.TOP);
    return button;}
  public static JComboBox makeComboBox(){
    JComboBox box = new JComboBox();
    box.setAlignmentY(Component.TOP_ALIGNMENT);
    box.setAlignmentX(Component.LEFT_ALIGNMENT);
    box.setForeground(Color.black);
    return box;}

  public static JComboBox makeComboBox(Object[] items, int selected){
    JComboBox box = new JComboBox(items);
    box.setAlignmentY(Component.TOP_ALIGNMENT);
    box.setAlignmentX(Component.LEFT_ALIGNMENT);
    box.setForeground(Color.black);
    box.setSelectedIndex(selected);
    return box;}
  public static JComboBox makeChooserBox(){
    JComboBox chooser = new JComboBox();
    chooser.setRenderer(new ChooserBoxRenderer());
    chooser.setAlignmentY(Component.TOP_ALIGNMENT);
    chooser.setAlignmentX(Component.LEFT_ALIGNMENT);
    chooser.setForeground(Color.black);
    return chooser;}

  public static JComboBox makeChooserBox(Choosable[] choices, int selected){
    JComboBox chooser = new JComboBox(choices);
    chooser.setRenderer(new ChooserBoxRenderer());
    chooser.setAlignmentY(Component.TOP_ALIGNMENT);
    chooser.setAlignmentX(Component.LEFT_ALIGNMENT);
    chooser.setForeground(Color.black);
    chooser.setSelectedIndex(selected);
    return chooser;}

  public static JLabel makeLabel(String text){
    JLabel label = new JLabel(text);
    label.setAlignmentY(Component.TOP_ALIGNMENT);
    label.setAlignmentX(Component.LEFT_ALIGNMENT);
    label.setForeground(Color.black);
    label.setVerticalAlignment(SwingConstants.TOP);
    return label;
  }
  public static JPanel makeSubPanel(String name){
    return makeSubPanel(name,null); }

  public static JPanel makeSubPanel(String name, Component contents){
    JPanel subpanel = new JPanel();
    subpanel.setAlignmentX(Component.CENTER_ALIGNMENT);
    subpanel.setAlignmentY(Component.TOP_ALIGNMENT);
    subpanel.setLayout(new BoxLayout(subpanel, BoxLayout.Y_AXIS));
    subpanel.setBorder(BorderFactory.createTitledBorder(name));
    if (contents != null)
      subpanel.add(contents);
    return subpanel;
  }

  public static JPanel makeSubPanel(String name, JLabel label, Component widget,Component contents){
    JPanel subpanel = new JPanel();
    subpanel.setAlignmentX(Component.CENTER_ALIGNMENT);
    subpanel.setAlignmentY(Component.TOP_ALIGNMENT);
    subpanel.setLayout(new BoxLayout(subpanel, BoxLayout.Y_AXIS));
    subpanel.setBorder(BorderFactory.createTitledBorder(name));

    if(label!=null && widget!=null){
      FormPanel formPanel = new FormPanel();
      formPanel.addField(label,widget);
      subpanel.add(formPanel);}
    if (contents != null){
      JPanel componentPanel = new JPanel();
      componentPanel.setLayout(new BoxLayout(componentPanel, BoxLayout.X_AXIS));
      componentPanel.add(contents);
      subpanel.add(componentPanel);}

    return subpanel;
  }



  public static JTextArea makeTextArea(){
    JTextArea comments = new JTextArea(1,1);
    comments.setForeground(Color.black);
    comments.setLineWrap(true);
    return comments;}
  public static JTextField makeTextField(){
    JTextField text = new JTextField(15);
    text.setAlignmentY(Component.TOP_ALIGNMENT);
    text.setAlignmentX(Component.LEFT_ALIGNMENT);
    text.setForeground(Color.black);
    return text;}
 public static JButton makeSmallButton(Action act){
   JButton button = new JButton((Icon)act.getValue(Action.SMALL_ICON));
   button.setToolTipText((String) act.getValue(Action.NAME));
   button.addActionListener(act);
   return button;}

}
