package blcc.gui.widgets;

import javax.swing.JLabel;
import javax.swing.ListCellRenderer;
import javax.swing.JList;
import java.awt.Component;
import blcc.util.Choosable;


class ChooserBoxRenderer extends JLabel implements ListCellRenderer {
     public ChooserBoxRenderer() {
         setOpaque(true);}
     public Component getListCellRendererComponent(JList list,
         Object value, int index, boolean isSelected, boolean cellHasFocus){
         setText(((Choosable)value).getPrettyName());
         setBackground(isSelected ? list.getSelectionBackground() : list.getBackground());
         setForeground(isSelected ? list.getSelectionForeground(): list.getForeground());
         return this;}
 }



