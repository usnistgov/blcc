package blcc.gui.widgets;

/** A default implementation of ChangedListener. */
public class DefaultChangedListener implements ChangedListener {
  public boolean allowChange(ChangedEvent event) { return true; }
  public void noteChange(ChangedEvent event) {}
}

    
