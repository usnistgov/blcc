package blcc.gui.widgets;
import blcc.model.ModelElement;
import java.util.EventListener;

/** Listens for ChangedEvents. */
public interface ChangedListener extends EventListener{
  public boolean allowChange(ChangedEvent event);
  public void noteChange(ChangedEvent event);
}

    
