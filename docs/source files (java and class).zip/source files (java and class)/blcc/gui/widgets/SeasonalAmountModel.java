package blcc.gui.widgets;

import javax.swing.*;
import javax.swing.table.*;

public class SeasonalAmountModel extends AbstractTableModel {

  boolean editable = true;
  private ChangedListenerList cvlist=new ChangedListenerList();


  static String seasons[] = {"Summer", "Winter"};
  double amounts[] = new double[2];
  double costs[] = new double[2];

  static String columnNames[] = {"Season", "Units/Year", "Price/Unit"};
  public SeasonalAmountModel() {
	super(); }
  public Class getColumnClass(int column){
	return (column == 0 ? String.class : Double.class); }
  public int getColumnCount(){ return 3; }
  public String getColumnName(int column){ return columnNames[column]; }
  public int getRowCount(){    return 2; }
  public double getSummerAmount(){  return amounts[0]; }
  public double getSummerCost(){  return costs[0]; }
  public Object getValueAt(int row, int column){
	if (column == 0){       return seasons[row]; }
	else if (column == 1) { return new Double(amounts[row]); }
	else {                  return new Double(costs[row]); }}
  public double getWinterAmount(){  return amounts[1]; }
  public double getWinterCost(){  return costs[1]; }
  public boolean isCellEditable(int row, int column){
	return (column == 0 ? false : editable); }
  public void setCellEditors(JTable table){
	final DoubleField doubleField = new DoubleField("##0.000");
	table.setDefaultEditor(Double.class,
			     (TableCellEditor) doubleField.getCellEditor());
  table.setDefaultRenderer(Double.class, doubleField.getCellRenderer());
  table.setCellSelectionEnabled(true);

  // price/unit column has $ in format
  TableColumn priceColumn = table.getColumnModel().getColumn(2);
  DoubleField priceField = new DoubleField("$##0.00000");
  priceColumn.setCellEditor((TableCellEditor)priceField.getCellEditor());
  priceColumn.setCellRenderer(priceField.getCellRenderer());
  }
  public void setEditable(boolean editable){
	this.editable=editable; }
  public void setSummerAmount(double x){ amounts[0]=x; fireTableDataChanged();  }
  public void setSummerCost(double x){  costs[0]=x; fireTableDataChanged(); }
  public void setValueAt(Object value, int row, int column){
    double val = ((Double) value).doubleValue();
    double initial = ((Double) getValueAt(row, column)).doubleValue();
    if(initial != val){
      if(cvlist.fireAllowChange(this)) {
      cvlist.fireChanged(this); } }
	if (column == 1){       amounts[row] = ((Double) value).doubleValue(); }
	else if (column == 2) { costs[row] = ((Double) value).doubleValue(); }}
  public void setWinterAmount(double x){ amounts[1]=x; fireTableDataChanged(); }
  public void setWinterCost(double x){  costs[1]=x; fireTableDataChanged();}
   public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }


}




