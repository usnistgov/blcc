package blcc.gui.widgets;

import javax.swing.*;
import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;


public class TabPanel extends JPanel {
  GridBagLayout layout = new GridBagLayout();
  GridBagConstraints constraints = new GridBagConstraints();


  public TabPanel(){
    super();
    setLayout(layout);
    //setBackground(Factory.backgroundColor());
    constraints.ipady = 5;
    constraints.gridheight = 1;
    // Try to stretch all components to full width.
    constraints.anchor = GridBagConstraints.CENTER;
    constraints.gridwidth=GridBagConstraints.REMAINDER;
    constraints.weightx = 1.0;
    //setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
  }
  public void addSpacerPanel() {
    JLabel spacer = new JLabel();
    constraints.fill = GridBagConstraints.BOTH;
    constraints.weighty = .8;  // Give this the most excess space
    layout.setConstraints(spacer, constraints);
    add(spacer);
  }
  public void addSubPanel(FormPanel panel) {
    constraints.fill = GridBagConstraints.BOTH;
    constraints.weighty = 0.0;	// Forms already have enough space.
    layout.setConstraints(panel, constraints);
    add(panel);
  }
  public void addSubPanel(TipsSubPanel tips) {
    constraints.fill = GridBagConstraints.BOTH;
    constraints.weighty = 0.6;  // Tips could stretch abit.
    layout.setConstraints(tips, constraints);
    add(tips);
  }

  public void addSubPanel(JPanel panel) {
    constraints.fill = GridBagConstraints.BOTH;
    constraints.weighty = 0.7;	// Others might scroll, so can stretch more.
    layout.setConstraints(panel, constraints);
    add(panel);
  }

  public void addSubPanel(JComponent panel) {
    constraints.fill = GridBagConstraints.BOTH;
    constraints.weighty = 0.6;  // Tips could stretch abit.
    layout.setConstraints(panel, constraints);
    add(panel);
  }
}
