package blcc.gui.widgets;

import blcc.util.Choosable;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ListDataEvent;
import java.util.Vector;
import java.util.Enumeration;


public class Chooser extends JComboBox {
  Object choices[] ={"None"};
  int initialSelection=0;
  int selected = 0;
  boolean choosables=false;
  private ChangedListenerList cvlist=new ChangedListenerList();
  Model model;
  public Chooser(){
    super();
    setModel(model=new Model());
    setRenderer(new Renderer());
    addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e) { updateChoice(); }});
  }


  public Chooser(String choices[]){
    this();
    setChoices(choices); }


  public Chooser(Choosable choices[]){
    this();
    setChoices(choices); }

  protected int findChoice(Object item){
    for(int i=0; i<choices.length; i++)
      if(choices[i].equals(item)) return  i;
    return 0; }


  public void setChoice(int i){
    setSelectedIndex(initialSelection=i); }


  public void setChoice(Object item){
    setChoice(findChoice(item)); }


  public Object getChoice(){
    return choices[selected]; }

  public void setChoices(Vector list){
    Choosable[] choosables = new Choosable[list.size()];
    int i=0;
    for (Enumeration enum1 = list.elements(); enum1.hasMoreElements();) {
     choosables[i] = (Choosable)enum1.nextElement();
     i++;}
    setChoices(choosables);}


  public void setChoices(String choices[]){
    if (this.choices != choices)
      initialSelection = selected = 0;
    this.choices = choices;
    choosables = false;
    model.noteContentsChanged();
  }


  public void setChoices(Choosable choices[]){
    if (this.choices != choices)
      initialSelection = selected = 0;
    this.choices = choices;
    choosables = true;
    model.noteContentsChanged();
  }


  protected int updateChoice(){
    if(selected != initialSelection){
      if(cvlist.fireAllowChange(this)) {
        initialSelection = selected;
        cvlist.fireChanged(this); }
      else
        setSelectedIndex(initialSelection); }
    return initialSelection; }


  public void addChangedListener(ChangedListener l){
    cvlist.addChangedListener(l); }
  public void removeChangedListener(ChangedListener l){
    cvlist.removeChangedListener(l); }


  protected class Model extends DefaultComboBoxModel {
    public int getSize(){ return choices.length; }
    public Object getElementAt(int i){ return choices[i]; }
    public Object getSelectedItem(){   return choices[selected]; }
    public void setSelectedItem(Object item){
      selected = findChoice(item);
      updateChoice(); }         // Redundant??
    public void noteContentsChanged(){
      fireContentsChanged(this,0,choices.length-1); }
  }
  protected class Renderer extends JLabel implements ListCellRenderer {
    public Renderer() {setOpaque(true);}  // needed to let background selection color show
    public Component getListCellRendererComponent(JList list, Object value,
                                                  int index, boolean sel,
                                                  boolean foc){
      setText(choosables ? ((Choosable)value).getPrettyName()
              : value.toString());
      setBackground(sel ? list.getSelectionBackground()  : list.getBackground());  // when selected, blue background and white text
      setForeground(sel ? list.getSelectionForeground(): list.getForeground());
       return this; }
  }
}
