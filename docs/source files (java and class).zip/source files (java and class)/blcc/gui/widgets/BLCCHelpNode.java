package blcc.gui.widgets;

import javax.swing.tree.*;
import java.util.Hashtable;

public class BLCCHelpNode extends DefaultMutableTreeNode {
	String fileName = null;
  private final static Hashtable helpNodes = new Hashtable();
public BLCCHelpNode(Object arg1, String name) {
	super(arg1);
	fileName = name;
  helpNodes.put(name, this);}

public String getFileName() {
	return fileName;

}
}
