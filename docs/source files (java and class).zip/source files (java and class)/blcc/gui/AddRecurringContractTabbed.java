package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import blcc.model.Alternative;
import blcc.model.RecurringContractCost;
import blcc.model.ModelElement;
import java.util.Vector;

public class AddRecurringContractTabbed extends TabbedPane {
  Chooser typeInput;
  JButton addButton;

  Chooser copyInput;
  JButton copyButton;


  public AddRecurringContractTabbed(BLCC5 blcc) {
    super(blcc);
    TabPanel tab = new TabPanel();
    FormPanel addPanel = new FormPanel("Create New Cost");
    String types[] =  {"Annual Contract Payment", "Debt Service",
           "Performance Period Expense"};
    addPanel.addField(Factory.makeLabel("Cost Type:"),
		      typeInput = new Chooser(types));
    tab.addSubPanel(addPanel);
    tab.addSubPanel(Factory.makeButtonSubPanel(
                 addButton = new JButton ("Create Cost")));
    addButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	  BLCCTreeNode node = owner.getCurrentNode();
    RecurringContractCost cost = new RecurringContractCost();
    cost.setName((String)typeInput.getChoice());
    ((Alternative) node.getParentElement()).addRecurringContractCost(cost);
    owner.createRecurringContractSubNode(node, cost,true);
	  owner.setNeedsSave(true);
	}});

 FormPanel panel2 = new FormPanel("Copy Existing Cost");
 panel2.addField(Factory.makeLabel("Cost to Copy:"),
                copyInput = new Chooser());

 tab.addSubPanel(panel2);
 tab.addSubPanel(Factory.makeButtonSubPanel(copyButton = new JButton("Copy Cost")));

 copyButton.addActionListener(new ActionListener(){
 public void actionPerformed(ActionEvent e) {
  RecurringContractCost currentCost= (RecurringContractCost)copyInput.getChoice();
  RecurringContractCost newCost = currentCost.copyRecurringContractCost();
  BLCCTreeNode node = owner.getCurrentNode();
  ((Alternative) node.getParentElement()).addRecurringContractCost(newCost);
  owner.createRecurringContractSubNode(node, newCost, true);
  owner.setNeedsSave(true); }});

  copyButton.setEnabled(false);

    addTab("Add Annually Recurring Contract-Related Cost", tab); }

  public void getInformation(ModelElement element) {

  Vector costs = owner.getProject().getRecurringContractChoices();

  if(costs.size() != 0){
   copyInput.setChoices(costs);
   copyButton.setEnabled(true);}
  else
  {
   String choices[] ={"None"};
   copyInput.setChoices(choices);
   copyButton.setEnabled(false);}
  }


}
