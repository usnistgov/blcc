package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import blcc.model.CapitalComponent;
import blcc.model.CapitalReplacement;
import blcc.model.ModelElement;
import blcc.model.Project;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import java.util.Vector;

public class AddReplacementTabbed extends TabbedPane {
  TextField nameInput;
  JButton addButton;

  Chooser copyInput;
  JButton copyButton;


  public AddReplacementTabbed(BLCC5 blcc) {
    super(blcc);
    TabPanel tab = new TabPanel();
    FormPanel addPanel = new FormPanel("Create New Cost");
    addPanel.addField(Factory.makeLabel("Cost Name:"),
		      nameInput = new TextField());
    nameInput.addCaretListener(new CaretListener(){
	public void caretUpdate(CaretEvent e){
	  addButton.setEnabled(!nameInput.getValue().equals("")); }});

    tab.addSubPanel(addPanel);
    tab.addSubPanel(Factory.makeButtonSubPanel(
                addButton = new JButton("Create Cost")));
    addButton.setEnabled(false);
    addButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	BLCCTreeNode node = owner.getCurrentNode();
	CapitalReplacement repl = new CapitalReplacement();
	repl.setName(nameInput.getText());
	((CapitalComponent) node.getParentElement()).addCapitalReplacement(repl);
	owner.createReplacementSubNode(node, repl,true);
	owner.setNeedsSave(true);
  nameInput.setValue("");  }});


  FormPanel panel2 = new FormPanel("Copy Existing Cost");
  panel2.addField(Factory.makeLabel("Cost to Copy:"),
               copyInput = new Chooser());
  tab.addSubPanel(panel2);
  tab.addSubPanel(Factory.makeButtonSubPanel(copyButton = new JButton("Copy Cost")));

  copyButton.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent e) {
   CapitalReplacement currentCost= (CapitalReplacement)copyInput.getChoice();
   CapitalReplacement newCost = currentCost.copyCapitalReplacement();
   BLCCTreeNode node = owner.getCurrentNode();
   ((CapitalComponent) node.getParentElement()).addCapitalReplacement(newCost);
   owner.createReplacementSubNode(node, newCost, true);
   owner.setNeedsSave(true); }});

   copyButton.setEnabled(false);
addTab("Add Replacement Cost", tab); }

  public void getInformation(ModelElement element) {

   Vector cost = owner.getProject().getReplacementChoices();

   if(cost.size() != 0){
    copyInput.setChoices(cost);
    copyButton.setEnabled(true);}
   else
   {
    String choices[] ={"None"};
    copyInput.setChoices(choices);
    copyButton.setEnabled(false);}
  }

  public void setAnalysisSpecific(int analysisType) {
     if(analysisType==Project.MILCONENERGYANALYSIS || analysisType==Project.MILCONNONENERGYANALYSIS){setTitleAt(0, "Add Major Repair and Replacement Cost");}
     else{setTitleAt(0, "Add Replacement Cost");}
   }





}
