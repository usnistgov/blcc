package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import blcc.model.NonRecurringCost;
import blcc.model.CapitalComponent;
import blcc.model.Project;
import blcc.model.ModelElement;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import java.util.Vector;

public class AddNonRecurringTabbed extends TabbedPane {
  TextField nameInput;
  Chooser copyInput;
  JButton addButton, copyButton;
  FormPanel addPanel, copyPanel;
  JLabel addLabel, copyLabel;


  public AddNonRecurringTabbed(BLCC5 blcc) {
    super(blcc);
    TabPanel tab = new TabPanel();
    addPanel = new FormPanel("");
    addPanel.addField(addLabel=Factory.makeLabel(""),
		      nameInput = new TextField());
    nameInput.addCaretListener(new CaretListener(){
	public void caretUpdate(CaretEvent e){
	  addButton.setEnabled(!nameInput.getValue().equals("")); }});

    tab.addSubPanel(addPanel);
    tab.addSubPanel(Factory.makeButtonSubPanel(
        addButton = new JButton("")));
    addButton.setEnabled(false);
    addButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	BLCCTreeNode node = owner.getCurrentNode();
	NonRecurringCost cost = new NonRecurringCost();
	cost.setName(nameInput.getText());
	((CapitalComponent)node.getParentElement()).addNonRecurringCost(cost);
	owner.createNonRecurringSubNode(node, cost,true);
	owner.setNeedsSave(true);
  nameInput.setValue(""); }});

  copyPanel = new FormPanel("");
  copyPanel.addField(copyLabel=Factory.makeLabel(""),
               copyInput = new Chooser());
  tab.addSubPanel(copyPanel);
  tab.addSubPanel(Factory.makeButtonSubPanel(copyButton = new JButton("")));

  copyButton.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent e) {
   NonRecurringCost currentCost= (NonRecurringCost)copyInput.getChoice();
   NonRecurringCost newCost = currentCost.copyNonRecurringCost();
   BLCCTreeNode node = owner.getCurrentNode();
   ((CapitalComponent) node.getParentElement()).addNonRecurringCost(newCost);
   owner.createNonRecurringSubNode(node, newCost, true);
   owner.setNeedsSave(true); }});

   copyButton.setEnabled(false);
  addTab("", tab);  }

  public void getInformation(ModelElement element) {

   Vector cost = owner.getProject().getNonRecurringOMRChoices();

   if(cost.size() != 0){
    copyInput.setChoices(cost);
    copyButton.setEnabled(true);}
   else
   {
    String choices[] ={"None"};
    copyInput.setChoices(choices);
    copyButton.setEnabled(false);}
  }

   public void setAnalysisSpecific(int analysisType) {
      if(analysisType==Project.MILCONECIPANALYSIS){
      addLabel.setText("Savings/Cost Name:");
      setTitleAt(0, "Add Non-Annually Recurring Savings/Cost");
      ((javax.swing.border.TitledBorder) addPanel.getBorder()).setTitle("Create New Savings/Cost");
      addButton.setText("Create Savings/Cost");
      ((javax.swing.border.TitledBorder) copyPanel.getBorder()).setTitle("Copy Existing Savings/Cost");
      copyButton.setText("Copy Savings/Cost");
      copyLabel.setText("Savings/Cost to Copy:");}

      else{
      addLabel.setText("Cost Name:");
      if(analysisType==Project.MILCONENERGYANALYSIS || analysisType==Project.MILCONNONENERGYANALYSIS){setTitleAt(0, "Add Routine Non-Annually Recurring OM&R Cost");}
      else{setTitleAt(0, "Add Non-Annually Recurring OM&R Cost");}
      ((javax.swing.border.TitledBorder) addPanel.getBorder()).setTitle("Create New Cost");
      addButton.setText("Create Cost");
      ((javax.swing.border.TitledBorder) copyPanel.getBorder()).setTitle("Copy Existing Cost");
      copyButton.setText("Copy Cost");
      copyLabel.setText("Cost to Copy:");}
   }



}
