package blcc.gui;

import javax.swing.*;
import javax.swing.tree.TreePath;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import blcc.gui.widgets.*;

import blcc.model.Alternative;
import blcc.model.EnergyUsage;
import blcc.model.VaryingEscalation;
import blcc.model.SimpleEscalation;
import blcc.model.Escalation;
import blcc.model.UsageIndex;
import blcc.model.ModelElement;
import blcc.model.Project;
import java.util.Date;
import blcc.util.Units;
import blcc.util.DOEPrices;
import blcc.util.Emissions;
import blcc.util.FuelType;
import java.util.Hashtable;

public class EnergyTabbed extends TabbedPane {
  EnergyUsage energy;

  TextField nameInput;
  Chooser unitsInput;
  Chooser stateInput;
  Chooser scheduleInput;
  Chooser emissionsInput;
  JLabel emissionsLabel;
  JLabel consumptionLabel;
  DoubleField consumptionInput;
  DoubleField priceInput;
  JLabel priceLabel;
  DoubleField demandInput;
  DoubleField rebateInput;
  JButton deleteButton;
  JPanel escalationForm;
  VaryingTable indicesTable;
  VaryingTable escalationTable;

  JButton clear;
  JButton restore;

  TipsSubPanel usageTipsPanel;
	TipsSubPanel costTipsPanel;

  String deleteMessage;


  public EnergyTabbed(BLCC5 blcc) {
    super(blcc);
    addTab("Energy Usage", getUsageTab());
    addTab("Energy Cost", getCostTab());
    addTab("Delete", getDeleteTab());
  }

  public void getInformation (ModelElement element) {
    energy = (EnergyUsage) element;
    FuelType fueltype = energy.getFuelType();

    nameInput.setValue(energy.getName());

    // Setup Units choices  appropriate for fuel.
    unitsInput.setChoices(fueltype.getUnits());
    setUnits(energy.getUnits());

    // Setup Rate Schedule choices appropriate for fuel.
    String scheds[]=DOEPrices.getRateSchedules(fueltype);
    scheduleInput.setChoices(scheds);
    scheduleInput.setChoice(energy.getRateSchedule());

    stateInput.setChoice(energy.getState());

    // Set Emissions choices appropriate for fuel.
    emissionsInput.setChoices(energy.getEmissionsChoices());    
    emissionsInput.setChoice(energy.getEmissions());
   
    if(fueltype==FuelType.ELECTRICITY)
     emissionsLabel.setText("Location:");
    else
     emissionsLabel.setText("End-Use:");


    indicesTable.setValue(energy.getUsageIndex());
    setEscalation(energy.getEscalation());
    consumptionInput.setValue(energy.getYearlyUsage());
    priceInput.setValue(energy.getUnitCost());
    demandInput.setValue(energy.getDemandCharge());
    rebateInput.setValue(energy.getUtilityRebate());

    repaint(); //to refresh combo boxes

  }

  public void setInformation (ModelElement element) {
     stopEditing();
  }

  public JPanel getUsageTab() {
    String tips[]= {"","",""};

    TabPanel tab = new TabPanel();

    FormPanel form = new FormPanel("Energy Usage");
    form.addField(Factory.makeLabel("Name:"),
		    nameInput = new TextField());
    nameInput.addChangedListener(owner);
    nameInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
    energy.setName(nameInput.getValue()); }});
   nameInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {consumptionInput.requestFocus(); }});

    form.addField(consumptionLabel = Factory.makeLabel(""),
      consumptionInput = new DoubleField("###,##0.00",true),
		  unitsInput = new Chooser());
    consumptionInput.addChangedListener(owner);
    consumptionInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e) {
	  energy.setYearlyUsage(consumptionInput.getValue()); }});
    unitsInput.addChangedListener(owner);
    unitsInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e) {
	  setUnits((Units)unitsInput.getChoice()); }});
  consumptionInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {unitsInput.requestFocus(); }});
    tab.addSubPanel(form);

    indicesTable = new VaryingTable("Usage Index","##0.0%");
    tab.addSubPanel(Factory.makeSubPanel("Energy Usage Indices",
					 new JScrollPane(indicesTable)));
    indicesTable.addChangedListener(owner);

    FormPanel eform = new FormPanel("Emissions");
    eform.addField(emissionsLabel=Factory.makeLabel(""),emissionsInput = new Chooser());
    emissionsInput.addChangedListener(owner);
    emissionsInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e) {
	  energy.setEmissions((Emissions)emissionsInput.getChoice());  }});

    tab.addSubPanel(eform);

    tab.addSubPanel(usageTipsPanel=new TipsSubPanel(tips));
    return tab; }


  public JPanel getCostTab() {
		String tips[]={"","",""};
		TabPanel tab = new TabPanel();
    FormPanel costPanel = new FormPanel("Energy Costs");
    costPanel.addField(Factory.makeLabel("Rate Schedule:"),
                  scheduleInput = new Chooser());
    scheduleInput.addChangedListener(owner);
    scheduleInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e) {
	  energy.setRateSchedule((String)scheduleInput.getChoice());
	  setEscalation(energy.getEscalation()); }});

    costPanel.addField(Factory.makeLabel("State:"),
		  stateInput = new Chooser(DOEPrices.getStates()));
    stateInput.addChangedListener(owner);
    stateInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e) {
	  energy.setState((String)stateInput.getChoice());
	  setEscalation(energy.getEscalation()); }});


    costPanel.addField(priceLabel=Factory.makeLabel("Price/Unit:"),
      priceInput = new DoubleField("$#0.00000", false));
    priceInput.addChangedListener(owner);
    priceInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  energy.setUnitCost(priceInput.getValue()); }});
   priceInput.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent e) {demandInput.requestFocus(); }});

    costPanel.addField(Factory.makeLabel("Annual Demand Charge:"),
      demandInput = new DoubleField("$#,##0.00",false));
    demandInput.addChangedListener(owner);
    demandInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  energy.setDemandCharge(demandInput.getValue());}});
   demandInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {rebateInput.requestFocus(); }});


    costPanel.addField(Factory.makeLabel("Annual Utility Rebate:"),
      rebateInput = new DoubleField("$#,##0.00",false));
    rebateInput.addChangedListener(owner);
    rebateInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  energy.setUtilityRebate(rebateInput.getValue()); }});
   rebateInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {escalationTable.requestFocus(); }});

    tab.addSubPanel(costPanel);

    escalationTable = new VaryingTable("Escalation","##0.00%");
    escalationTable.addChangedListener(owner);
    escalationTable.addChangedListener(new ChangedListener(){
  public boolean allowChange(ChangedEvent e){
    VaryingEscalation esc = (VaryingEscalation) energy.getEscalation();
	  if(esc == energy.defaultEscalation()){
	    VaryingEscalation nesc = esc.copy();
      nesc.setName("Modified DOE Price Escalation Rates (" + energy.getFuelType().getPrettyName() +")");
	    setEscalation(nesc); }
	  return true; }
	public void noteChange(ChangedEvent e){}});

    escalationForm = Factory.makeSubPanel("Price Escalation Rates");

    JPanel buttons = new JPanel();
    clear   = new JButton("Clear Rates");
    restore = new JButton("Restore DOE Rates");
    buttons.add(clear );
    buttons.add(restore);
    escalationForm.add(buttons);
    escalationForm.add(new JScrollPane(escalationTable));

    tab.addSubPanel(escalationForm);
    tab.addSubPanel(costTipsPanel=new TipsSubPanel(tips));

    clear.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
    stopEditing();
    VaryingEscalation esc = new VaryingEscalation();
    esc.setName("User Rates (" + energy.getFuelType().getPrettyName() +")");
	  setEscalation(esc);
	  owner.setNeedsSave(true); }});
    restore.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
    stopEditing();
    setEscalation(null);
	  owner.setNeedsSave(true); }});
    return tab; }

  public JPanel getDeleteTab() {
    TabPanel tab = new TabPanel();
    tab.addSubPanel(Factory.makeButtonSubPanel(
        deleteButton = new JButton ("Delete This Cost")));
    deleteButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e) {
    if (owner.confirmDelete(deleteMessage) == JOptionPane.YES_OPTION){
	    BLCCTreeNode selectedNode = owner.getCurrentNode();
	    BLCCTreeNode parentNode = (BLCCTreeNode) selectedNode.getParent();
	    Alternative alt = (Alternative)parentNode.getElement();
	    alt.removeEnergyUsage((EnergyUsage)selectedNode.getElement());
	    owner.getTreeModel().removeNodeFromParent(selectedNode);
	    owner.setPreviousNode(null);
	    // find a path from root to the node that should be selected
	    TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(parentNode));
	    // select the path
	    owner.getTree().setSelectionPath(newPath);
      owner.setNeedsSave(true);
	  }
	}
      });
    return tab; }

  void setEscalation(Escalation esc){
    energy.setEscalation(esc);
    VaryingEscalation vesc = (VaryingEscalation)energy.getEscalation();
    escalationForm.setBorder(BorderFactory.createTitledBorder(vesc.getName()));
    escalationTable.setValue(vesc);
    restore.setEnabled(vesc != energy.defaultEscalation());
  }

  void setUnits(Units units){
    unitsInput.setChoice(units);
    energy.setUnits(units);
    priceLabel.setText("Price/"+units); }

  public void stopEditing(){
    // stop editing and save model
    if (indicesTable.isEditing())
      indicesTable.editingStopped(new javax.swing.event.ChangeEvent(indicesTable));
    if (escalationTable.isEditing())
      escalationTable.editingStopped(new javax.swing.event.ChangeEvent(escalationTable));}


  public void setAnalysisSpecific(int analysisType) {
    if(analysisType==Project.MILCONECIPANALYSIS){
     String tips[]={"Enter annual savings in energy consumption for alternative relative to base case.",
                    "Use Usage Indices to specify variable energy usage pattern.",
                    "Enter region, state or end-use for emissions calculation."};
      usageTipsPanel.setTipsText(tips);
      String tips2[] ={"Enter all dollar amounts in base-year dollars.",
                       "Energy Usage Indices also apply to demand charges and utility rebates.",
                       "If applicable, edit DOE price escalation rates.",
		                   "Constant-dollar amounts, real discount rate, and escalation rates exclude general inflation."};
		  costTipsPanel.setTipsText(tips2);
      deleteButton.setText("Delete This Savings/Cost");
      consumptionLabel.setText("Annual Savings:");
      deleteMessage="savings/cost";}
    else{
      String tips[]={"Enter the base-year annual energy consumption of the specified energy type.",
                     "Use Usage Indices to specify variable energy usage pattern.",
                     "Enter region, state or end-use for emissions calculation."};
      usageTipsPanel.setTipsText(tips);
      String tips2[] ={"Enter all dollar amounts in base-year dollars.",
                      "Energy Usage Indices also apply to demand charges and utility rebates.",
                      "If applicable, edit DOE price escalation rates.",
                      "Use real rates of price escalation in constant-dollar analysis, nominal rates "+
                      "in current-dollar analysis."};
      costTipsPanel.setTipsText(tips2);
      deleteButton.setText("Delete This Cost");
      consumptionLabel.setText("Annual Consumption:");
      deleteMessage="cost";}

     }

}
