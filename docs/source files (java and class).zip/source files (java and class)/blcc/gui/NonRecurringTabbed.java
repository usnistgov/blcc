package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import blcc.model.CapitalComponent;
import blcc.model.ModelElement;
import blcc.model.Project;
import blcc.model.NonRecurringCost;
import blcc.model.SimpleEscalation;
import blcc.util.DateDiff;
import javax.swing.tree.TreePath;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NonRecurringTabbed extends TabbedPane {
  NonRecurringCost cost;
  TextField nameInput;
  DateDiffField timingInput;
  JLabel timingLabel, amountLabel;
  DoubleField amountInput;
  DoubleField rateInput;
  TipsSubPanel costTips;
  JButton deleteButton;
  FormPanel panel;
  String deleteMessage;


  public NonRecurringTabbed(BLCC5 blcc) {
    super(blcc);
    addTab(" ", getNonRecurringTab());
    addTab("Delete", getDeleteTab());
  }

  public void getInformation(ModelElement element) {
    cost = (NonRecurringCost)element;
    nameInput.setText(cost.getName());
    amountInput.setValue(cost.getAmount());
    timingInput.setValue(cost.getStart());
    rateInput.setValue(((SimpleEscalation)cost.getEscalation()).getRate());
  }

  public void setInformation(ModelElement element) {}

  public JPanel getNonRecurringTab() {
    String tips[] = {" ", " ", " "};
    TabPanel tab = new TabPanel();
    panel = new FormPanel(" ");

    panel.addField(Factory.makeLabel("Name:"),
		   nameInput = new TextField());
    nameInput.addChangedListener(owner);
    nameInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  cost.setName(nameInput.getValue()); }});
   nameInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {timingInput.requestFocus(); }});


    panel.addField(timingLabel=Factory.makeLabel(" "),
		   timingInput = new DateDiffField());
    timingInput.addChangedListener(owner);
    timingInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  cost.setStart(timingInput.getValue()); }});
   timingInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {amountInput.requestFocus(); }});


    panel.addField(amountLabel=Factory.makeLabel(" "),
       amountInput = new DoubleField("$#,##0.00", true));
    amountInput.addChangedListener(owner);
    amountInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  cost.setAmount(amountInput.getValue()); }});
   amountInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {rateInput.requestFocus(); }});


    panel.addField(Factory.makeLabel("Annual Rate of Increase:"),
       rateInput = new DoubleField("##0.00%", true));
    rateInput.addChangedListener(owner);
    rateInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  ((SimpleEscalation)cost.getEscalation())
	    .setRate(rateInput.getValue()); }});
   rateInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {nameInput.requestFocus(); }});


    tab.addSubPanel(panel);
    tab.addSpacerPanel();
    tab.addSubPanel(costTips = new TipsSubPanel(tips));
    return tab; }

  public JPanel getDeleteTab() {
    TabPanel tab = new TabPanel();
    tab.addSubPanel(Factory.makeButtonSubPanel(
       deleteButton = new JButton (" ")));
    deleteButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e) {
    if (owner.confirmDelete(deleteMessage) == JOptionPane.YES_OPTION) {
	    BLCCTreeNode selectedNode = owner.getCurrentNode();
	    BLCCTreeNode parentNode = (BLCCTreeNode) selectedNode.getParent();
	    CapitalComponent comp = (CapitalComponent)parentNode.getElement();
	    comp.removeNonRecurringCost((NonRecurringCost)selectedNode.getElement());
	    owner.getTreeModel().removeNodeFromParent(selectedNode);
	    owner.setPreviousNode(null);
	    // find a path from root to the node that should be selected
	    TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(parentNode));
	    // select the path
	    owner.getTree().setSelectionPath(newPath);
	    owner.setNeedsSave(true);
	  }}});
    return tab; }

  public Boolean guiValidate(ModelElement element) {

    // warning
    NonRecurringCost cost = (NonRecurringCost)element;
    
    // workaround; see guiValidate in ProjectTabbed; 
    cost.setStart(timingInput.getValue());

   if(!cost.getStartDate().between(cost.getProject().getBaseDate(),cost.getProject().getEndDate()))
      JOptionPane.showMessageDialog(owner,
                  "Years/Months not in your study period; cost will be saved but not used.",
                  "Warning",
                  JOptionPane.WARNING_MESSAGE);

    boolean show = true;
    try {element.validate(false);}
    catch(blcc.model.ValidationException e){
      TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(owner.getPreviousNode()));  // go back to node with validation exception
      owner.setPreviousNode(null);  // set previousNode to null so it won't reset (and revalidate) the node
      owner.getTree().setSelectionPath(newPath);
      JOptionPane.showMessageDialog(owner,
				    e.getMessage(),
            "Error",
				    JOptionPane.ERROR_MESSAGE);
      show = false;}
    return new Boolean(show); }

  public void setAnalysisSpecific(int analysisType) {
    String test;
    if (analysisType ==Project.FINANCEDANALYSIS) {
      String tips[] = {"Enter years and months from Base Date.",
                       "Enter the amount in base-year dollars.",
                       "Use real rates of increase in constant-dollar analysis, "+
                       "nominal rates in current-dollar analysis."};
      costTips.setTipsText(tips);
      amountLabel.setText("Amount:");
      setTitleAt(0, "Non-Annually Recurring OM&R Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Non-Annually Recurring Operating, Maintenance and Repair Cost");
      timingLabel.setText("Years/Months (from Base Date):");
      deleteButton.setText("Delete This Cost");
      deleteMessage="cost";}

     else if (analysisType==Project.AGENCYFUNDEDANALYSIS) {
      String tips[] = {"Enter years and months from Service Date.",
                       "Enter the amount in base-year dollars.",
                       "Use real rates of increase in constant-dollar analysis, "+
                       "nominal rates in current-dollar analysis."};
      costTips.setTipsText(tips);
      amountLabel.setText("Amount:");
      setTitleAt(0, "Non-Annually Recurring OM&R Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Non-Annually Recurring Operating, Maintenance and Repair Cost");
      timingLabel.setText("Years/Months (from Service Date):");
      deleteButton.setText("Delete This Cost");
      deleteMessage="cost";}

   else if (analysisType==Project.MILCONENERGYANALYSIS){
       String tips[] = {"Include relevant non-capital replacement costs",
                      "Enter years and months from BOD.",
                      "Enter the amount in base-year dollars.",
                      "Use real rates of increase in constant-dollar analysis, "+
                      "nominal rates in current-dollar analysis."};
      costTips.setTipsText(tips);
      amountLabel.setText("Amount:");
      setTitleAt(0, "Routine Non-Annually Recurring OM&R Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Routine Non-Annually Recurring Operating, Maintenance and Repair Cost");
      timingLabel.setText("Years/Months (from BOD):");
      deleteButton.setText("Delete This Cost");
      deleteMessage="cost";}

		else if (analysisType ==Project.OMBANALYSIS) {
      String tips[] = {"Enter years and months from Service Date.",
                       "Enter the amount in base-year dollars.",
                       "Use real rates of increase in constant-dollar analysis, "+
                       "nominal rates in current-dollar analysis."};
      costTips.setTipsText(tips);
      amountLabel.setText("Amount:");
      setTitleAt(0, "Non-Annually Recurring OM&R Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Non-Annually Recurring Operating, Maintenance and Repair Cost");
      timingLabel.setText("Years/Months (from Service Date):");
      deleteButton.setText("Delete This Cost");
      deleteMessage="cost";}

		else if (analysisType==Project.MILCONNONENERGYANALYSIS){
       String tips[] = {"Include relevant non-capital replacement costs",
                      "Enter years and months from BOD.",
                      "Enter the amount in base-year dollars.",
                      "Use real rates of increase in constant-dollar analysis, "+
                      "nominal rates in current-dollar analysis."};
      costTips.setTipsText(tips);
      amountLabel.setText("Amount:");
      setTitleAt(0, "Routine Non-Annually Recurring OM&R Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Routine Non-Annually Recurring Operating, Maintenance and Repair Cost");
      timingLabel.setText("Years/Months (from BOD):");
      deleteButton.setText("Delete This Cost");
      deleteMessage="cost";}


    else{
     String tips[] = {"Enter savings in non-annually recurring costs for alternative relative to base case.",
		                  "Enter dollar amounts in base-year dollars.",
                      "Enter negative amount for additional cost.",
											"Constant-dollar amounts, real discount rate, and escalation rates exclude general inflation."};
     costTips.setTipsText(tips);
     amountLabel.setText("Annual Amount Saved:");
     setTitleAt(0, "Non-Annually Recurring Cost");
     ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Non-Annually Recurring Cost");
     timingLabel.setText("Years/Months (from BOD):");
     deleteButton.setText("Delete This Savings/Cost");
     deleteMessage="savings/cost";}


  }

}
