package blcc.gui;

import javax.swing.*;
import javax.swing.event.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.text.html.*;
import javax.swing.tree.*;
import blcc.gui.widgets.BLCCHelpNode;
import blcc.gui.widgets.PrintableEditorPane;
import java.awt.Cursor;
import blcc.util.Defaults;

public class Help extends JFrame {

	JTree tree;
	DefaultTreeModel treeModel;
  PrintableEditorPane editorPane;
	BLCCHelpNode rootNode;
  JMenuItem printItem;

public Help(String title) {
	super(title);

  JMenuBar menuBar = new JMenuBar();
  setJMenuBar(menuBar);
  JMenu fileMenu = new JMenu("File");
  menuBar.add(fileMenu);

   printItem = new JMenuItem("Print Help Topic",
    new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/print.gif"), "Print"));
    printItem.setEnabled(false);
    fileMenu.add(printItem);
    printItem.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        try{print();}
        catch(Exception ex){ex.printStackTrace();}

      }
    });


  fileMenu.addSeparator();

  JMenuItem closeItem = new JMenuItem("Close",
   new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/folderout.gif"), "Close"));
  fileMenu.add(closeItem);
  closeItem.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent e){
      Help.this.dispose();}
   });

	JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, false);

	// left pane

  rootNode = new BLCCHelpNode("BLCC5 Help", "blank.html");
	treeModel = new DefaultTreeModel(rootNode);
	tree = new JTree(treeModel);

 	tree.setSelectionRow(0);
  	tree.putClientProperty("JTree.lineStyle", "Angled");
	tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);

	// right pane
  editorPane = new PrintableEditorPane();
	editorPane.setEditable(false);

	splitPane.setLeftComponent(new JScrollPane(tree));
	splitPane.setRightComponent(new JScrollPane(editorPane));
	splitPane.setDividerLocation(300);

	getContentPane().add(splitPane);


	addNodes();

	tree.expandPath(new TreePath(rootNode.getPath()));


  	tree.addTreeSelectionListener(new TreeSelectionListener(){
	 public void valueChanged(TreeSelectionEvent e){
	  BLCCHelpNode node = (BLCCHelpNode) tree.getLastSelectedPathComponent();
	 if (node == null)
 		 return;
 	else
	  {
		 	String s = null;
	   try {
       s = Help.class.getResource("/blcc/resources/help/") + node.getFileName();
		   URL helpURL = new URL(s);
		   editorPane.setPage(helpURL);
       if (node.getFileName().equals("blank.html")) printItem.setEnabled(false);
       else printItem.setEnabled(true);
	} catch (Exception ex) {
    System.err.println(e.toString() + "Error loading help system");}

	  }

	  }
 });


  	editorPane.addHyperlinkListener(new HyperlinkListener()
	 {
	  public void hyperlinkUpdate(HyperlinkEvent e)
	  {
		if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
		JEditorPane pane = (JEditorPane) e.getSource();
		if (e instanceof HTMLFrameHyperlinkEvent) {
		  HTMLFrameHyperlinkEvent  evt = (HTMLFrameHyperlinkEvent)e;
		  HTMLDocument doc = (HTMLDocument)pane.getDocument();
		  doc.processHTMLFrameHyperlinkEvent(evt);
		} else {
		 try {
		  pane.setPage(e.getURL());
	  } catch (Throwable t) {
	  t.printStackTrace();
   }
	 }
	}
	  }
	 });
}

public void addNodes() {

  BLCCHelpNode node=new BLCCHelpNode("Getting Help", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Program Help", "programhelp.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Internet Help", "internet.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("LCC Publications", "publications.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Web sites for LCC Legislative Rules", "websites.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Training", "training.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("NIST LCC and Software Support", "support.html"), node, node.getChildCount());

  node=new BLCCHelpNode("Getting Started", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Background", "background.html"), node, node.getChildCount());    
  treeModel.insertNodeInto(new BLCCHelpNode("Data Entry Conventions", "entry.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Steps In BLCC Analysis", "steps.html"), node, node.getChildCount());

  node = new BLCCHelpNode("Creating and Editing Data Files", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Create/Open Project File", "create.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Type of Analysis", "type.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("General Project Information", "general.html"), node, node.getChildCount());
	treeModel.insertNodeInto(new BLCCHelpNode("Analysis Purpose", "purpose.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Discounting Convention", "discounting.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Inflation Adjustment", "inflation.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Discount Rate", "discount.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Key Dates", "key.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Contract-Related Costs", "contract.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Energy Costs", "energy.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Energy Usage Indices", "indices.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Central Steam/Chilled Water", "centralsteam.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Emissions", "emissions.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Energy Price Escalation", "price.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Water Costs", "water.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Water Price Escalation Rates", "waterprice.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Water Usage and Disposal Indices", "waterusage.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Component-Related Data", "component.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Capital Investment Data", "capital.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Cost Phasing of Initial Costs", "cost.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Capital Replacement Costs", "replacement.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Annually Recurring Operating, Maintenance and Repair (OM&R) Costs", "annually.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Non-Annually Recurring OM&R Costs", "non.html"), node, node.getChildCount());

  node = new BLCCHelpNode("Performing Alternative Financing Analyses", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("General Information on Alternative Financing Projects", "info1.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Timing of Life-Cycle Cost Analysis (LCCA) for Alternative Financing Projects", "timing.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Base Date and Service Date in Alternative Financing Projects", "date.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Cost of Feasibility Studies in Alternative Financing Projects", "feasibility.html"), node, node.getChildCount());
	treeModel.insertNodeInto(new BLCCHelpNode("Meaning of SIR in ESPC and UC Contracts", "sir.html"), node, node.getChildCount());
	treeModel.insertNodeInto(new BLCCHelpNode("Bundling Energy Conservation Measures", "bundling.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Evaluating Independent versus Interdependent ECMs", "evaluating.html"), node, node.getChildCount());
    	treeModel.insertNodeInto(new BLCCHelpNode("Escalation Rate for Contract Payments from EERC", "eerc.html"), node, node.getChildCount());

	node = new BLCCHelpNode("Performing OMB Analyses", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("OMB Analysis, Non-Energy Project ", "OMB1.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Designating a Project as an OMB Project", "OMB2.html"), node, node.getChildCount());
	treeModel.insertNodeInto(new BLCCHelpNode(Defaults.getIntegerItem("default year")+ " OMB Discount Rates", "OMBRates.html"), node, node.getChildCount());


  node = new BLCCHelpNode("Performing MILCON Analyses", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("MILCON Analysis, Energy Project ", "milcon1.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("MILCON Analysis, ECIP Project", "milcon2.html"), node, node.getChildCount());
	treeModel.insertNodeInto(new BLCCHelpNode("MILCON Analysis, Non Energy Project", "milcon3.html"), node, node.getChildCount());


	node = new BLCCHelpNode("Emissions Calculations", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Emissions Calculations", "emiss.html"), node, node.getChildCount());

  node = new BLCCHelpNode("Reports", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Input Data Report", "input.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Detailed LCC Analysis Report", "detailed.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Annual Cash-Flow Report", "cash.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Summary LCC Report ", "summary.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Lowest LCC Report ", "lowest.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Comparative Analysis Report", "compare.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("ECIP Report", "ecip.html"), node, node.getChildCount());


  node=new BLCCHelpNode("Glossary and Acronyms", "blank.html");
  treeModel.insertNodeInto(node, rootNode, rootNode.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Glossary", "gloss.html"), node, node.getChildCount());
  treeModel.insertNodeInto(new BLCCHelpNode("Acronyms", "acronyms.html"), node, node.getChildCount());



}
public static void main(java.lang.String[] args)
{

  Help help;
  help = new Help("BLCC5 Help");
  help.setSize(new Dimension (300, 500));
  help.show();


}



 public void print() {
   editorPane.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
   java.awt.print.PrinterJob job = java.awt.print.PrinterJob.getPrinterJob();
   job.setPrintable(editorPane);
   if (job.printDialog()) {
    try { job.print();}
    catch (Exception ex) {ex.printStackTrace();}
   }
   editorPane.setCursor(Cursor.getDefaultCursor());}

}
