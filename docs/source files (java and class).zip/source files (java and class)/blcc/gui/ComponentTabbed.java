package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import blcc.model.CapitalComponent;
import blcc.model.Alternative;
import javax.swing.tree.TreePath;
import blcc.model.ModelElement;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import blcc.model.Project;
import blcc.model.CapitalComponent;
import blcc.model.ModelElement;
import blcc.model.SimpleEscalation;
import blcc.util.DateDiff;
import blcc.util.Date;
import javax.swing.tree.TreePath;
import java.awt.Component;

public class ComponentTabbed extends TabbedPane {
  CapitalComponent component;
  JButton deleteButton;
  TextArea comments;
  TextField componentName;

  public ComponentTabbed(BLCC5 blcc) {
    super(blcc);
    addTab("General Information", getGeneralTab());
    addTab("Delete", getDeleteTab());
  }

  public void getInformation(ModelElement element) {
    component = (CapitalComponent)element;
    componentName.setValue(component.getName());
    comments.setText(component.getComment());
  }

  public JPanel getGeneralTab() {
    TabPanel tab = new TabPanel();
    FormPanel panel = new FormPanel("General Component Information");
    panel.addField(Factory.makeLabel("Name:"),
		   componentName = new TextField());
    componentName.addChangedListener(owner);
    componentName.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  component.setName(componentName.getValue()); }});
   componentName.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {comments.requestFocus(); }});


    panel.addCommentField(Factory.makeLabel("Comment:"),
			  new JScrollPane(comments = new TextArea()));
    comments.addChangedListener(owner);
    comments.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  component.setComment(comments.getValue()); }});

    tab.addSubPanel(panel);
    tab.addSpacerPanel();    // added to keep sub panel on top of tab
    return tab;
  }


 public JPanel getDeleteTab() {
    TabPanel tab = new TabPanel();
    tab.addSubPanel(Factory.makeButtonSubPanel(
        deleteButton = new JButton ("Delete This Componenet")));
    deleteButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e) {
    if (owner.confirmDelete("component") == JOptionPane.YES_OPTION) {
	    // remove node from tree model
	    BLCCTreeNode selectedNode = owner.getCurrentNode();
	    BLCCTreeNode parentNode = (BLCCTreeNode) selectedNode.getParent();
	    Alternative alternative = (Alternative)parentNode.getElement();
	    alternative.removeCapitalComponent((CapitalComponent)selectedNode.getElement());
	    owner.setPreviousNode(null);
	    owner.getTreeModel().removeNodeFromParent(selectedNode);
	    // find a path from root to the node that should be selected
	    TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(parentNode));
	    // select the path
	    owner.getTree().setSelectionPath(newPath);
	    owner.setNeedsSave(true);
	}}});
    return tab; }

   public void setAnalysisSpecific(int analysisType) {
    if (analysisType == Project.MILCONECIPANALYSIS){
      if(indexOfTab("Delete")!= -1){removeTabAt(1);}
    }
   else{
     if (indexOfTab("Delete")== -1){addTab("Delete", getDeleteTab());}
    }
   }





}
