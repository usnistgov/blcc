package blcc.gui;

import blcc.gui.BLCC5;
import blcc.model.ModelElement;
import blcc.gui.widgets.*;
import javax.swing.*;
import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

public class TabbedPane extends JTabbedPane {
  protected BLCC5 owner = null; 

  public TabbedPane(BLCC5 blcc) {
    super();
    owner = blcc;
    setTabPlacement(JTabbedPane.TOP);
    // setBackground(Factory.backgroundColor());
  }

  public void addTab(String title, Component component){
    super.addTab(title,component);
    setBackgroundAt(getTabCount()-1,Factory.makeBlueColor()); 
  }

  /** Stub to get/set information from a ModelElement. */
  public void getInformation(ModelElement element) { }
  public void setInformation(ModelElement element) {}

  public Boolean guiValidate(ModelElement element) {
    return new Boolean(true); }

  public void setAnalysisSpecific(int analysisType) {}
}
