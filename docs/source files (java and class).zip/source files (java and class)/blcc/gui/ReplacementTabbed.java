package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import blcc.model.CapitalReplacement;
import blcc.model.SimpleEscalation;
import blcc.util.DateDiff;
import blcc.gui.widgets.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import blcc.model.CapitalComponent;
import javax.swing.tree.TreePath;
import blcc.model.ModelElement;
import javax.swing.tree.TreePath;
import java.util.Enumeration;

public class ReplacementTabbed extends TabbedPane {
  CapitalReplacement replacement;
  TipsSubPanel replacementTips;
  TextField nameInput;
  DateDiffField timingInput;
  JLabel timingLabel;
  DoubleField amountInput;
  DoubleField rateInput;
  DateDiffField lifeInput;
  DoubleField residualInput;
  FormPanel panel;

  JButton deleteButton;

  public ReplacementTabbed(BLCC5 blcc) {
    super(blcc);
    addTab("", getReplacementTab());
    addTab("Delete", getDeleteTab());
  }

  public void getInformation(ModelElement element) {
    replacement = (CapitalReplacement) element;
    nameInput.setText(replacement.getName());
    amountInput.setValue(replacement.getInitialCost());
    // for now, assume SimpleEscalation
    rateInput.setValue(((SimpleEscalation)replacement.getEscalation()).getRate());
    lifeInput.setValue(replacement.getDuration());
    timingInput.setValue(replacement.getStart());
    residualInput.setValue(replacement.getResaleValueFactor());
  }

  public void setInformation(ModelElement element) { }

  public JPanel getReplacementTab() {
    String tips[] = {""};  // set in setAnalysisSpecific()

    TabPanel tab = new TabPanel();

    panel = new FormPanel("");

    panel.addField(Factory.makeLabel("Name:"),
		   nameInput = new TextField());
    nameInput.addChangedListener(owner);
    nameInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  replacement.setName(nameInput.getValue()); }});
   nameInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {timingInput.requestFocus(); }});

    panel.addField(timingLabel=Factory.makeLabel(""),
		   timingInput = new DateDiffField());
    timingInput.addChangedListener(owner);
    timingInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  replacement.setStart(timingInput.getValue()); }});
   timingInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {amountInput.requestFocus(); }});


    panel.addField(Factory.makeLabel("Amount:"),
		   amountInput = new DoubleField("$#,##0.00", false));
    amountInput.addChangedListener(owner);
    amountInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  replacement.setInitialCost(amountInput.getValue()); }});
   amountInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {rateInput.requestFocus(); }});


    panel.addField(Factory.makeLabel("Annual Rate of Increase:"),
       rateInput = new DoubleField("##0.00%", true));
    rateInput.addChangedListener(owner);
    rateInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  ((SimpleEscalation)replacement.getEscalation())
	    .setRate(rateInput.getValue()); }});
   rateInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {lifeInput.requestFocus(); }});


    panel.addField(Factory.makeLabel("Expected Life:"),
		   lifeInput = new DateDiffField());
    lifeInput.addChangedListener(owner);
    lifeInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  replacement.setDuration(lifeInput.getValue()); }});
   lifeInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {residualInput.requestFocus(); }});


    panel.addField(Factory.makeLabel("Residual Value Factor:"),
		   residualInput = new DoubleField("##0.00%", true));
    residualInput.addChangedListener(owner);
    residualInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  replacement.setResaleValueFactor(residualInput.getValue()); }});
   residualInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {nameInput.requestFocus(); }});


    tab.addSubPanel(panel);
    tab.addSpacerPanel();
    tab.addSubPanel(replacementTips = new TipsSubPanel(tips));
    return tab;  }

  public JPanel getDeleteTab() {
    TabPanel tab = new TabPanel();
    tab.addSubPanel(Factory.makeButtonSubPanel(
           deleteButton = new JButton ("Delete This Cost")));
    deleteButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e) {
    if (owner.confirmDelete("cost") == JOptionPane.YES_OPTION) {
	    BLCCTreeNode selectedNode = owner.getCurrentNode();
	    BLCCTreeNode parentNode = (BLCCTreeNode) selectedNode.getParent();
	    CapitalComponent comp = (CapitalComponent)parentNode.getElement();
	    comp.removeCapitalReplacement((CapitalReplacement)selectedNode.getElement());
	    owner.getTreeModel().removeNodeFromParent(selectedNode);
	    owner.setPreviousNode(null);
	    // find a path from root to the node that should be selected
	    TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(parentNode));
	    // select the path
	    owner.getTree().setSelectionPath(newPath);
	    owner.setNeedsSave(true);
	  }}});
    return tab; }


  public Boolean guiValidate(ModelElement element) {
    // warning
    CapitalReplacement replacement = (CapitalReplacement)element;

   // workaround; see guiValidate in ProjectTabbed; 
     replacement.setStart(timingInput.getValue());

   if(!replacement.getStartDate().between(replacement.getProject().getBaseDate(),replacement.getProject().getEndDate()))
      JOptionPane.showMessageDialog(owner,
                  "Years/Months not in your study period; cost will be saved but not used.",
                  "Warning",
                  JOptionPane.WARNING_MESSAGE);

   boolean show = true;
   try {element.validate(false);}
   catch(blcc.model.ValidationException e){
      TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(owner.getPreviousNode()));  // go back to node with validation exception
      owner.setPreviousNode(null);  // set previousNode to null so it won't reset (and revalidate) the node
      owner.getTree().setSelectionPath(newPath);
      JOptionPane.showMessageDialog(owner,
                  e.getMessage(),
                  "Error",
                  JOptionPane.ERROR_MESSAGE);
      show = false;}
    return new Boolean(show); }

  public void setAnalysisSpecific(int analysisType) {
    if (analysisType == blcc.model.Project.FINANCEDANALYSIS){
      String tips[] = {"Enter years and months from Base Date.",
         "Enter the amount in base-year dollars.",
         "Use real rates of increase in constant-dollar analysis, nominal rates "+
         "in current-dollar analysis.",
         "Enter the Residual Value Factor as a percent of initial replacement cost."};
      replacementTips.setTipsText(tips);
      setTitleAt(0, "Replacement Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Capital Replacement Cost");
      timingLabel.setText("Years/Months (from Base Date):");}

    else if (analysisType==blcc.model.Project.AGENCYFUNDEDANALYSIS){
      String tips[] = {"Enter years and months from Service Date.",
         "Enter the amount in base-year dollars.",
         "Use real rates of increase in constant-dollar analysis, nominal rates "+
         "in current-dollar analysis.",
         "Enter the Residual Value Factor as a percent of initial replacement cost."};
      replacementTips.setTipsText(tips);
      setTitleAt(0, "Replacement Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Capital Replacement Cost");
      timingLabel.setText("Years/Months (from Service Date):");}
		else if (analysisType==blcc.model.Project.OMBANALYSIS){
       String tips[] = {"Enter years and months from Service Date.",
         "Enter the amount in base-year dollars.",
         "Use real rates of increase in constant-dollar analysis, nominal rates "+
         "in current-dollar analysis.",
         "Enter the Residual Value Factor as a percent of initial replacement cost."};
      replacementTips.setTipsText(tips);
      setTitleAt(0, "Replacement Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Capital Replacement Cost");
      timingLabel.setText("Years/Months (from Service Date):");}
			else if (analysisType==blcc.model.Project.MILCONNONENERGYANALYSIS){
      String tips[] = {"Enter years and months from BOD.",
         "Enter the amount in base-year dollars.",
         "Use real rates of increase in constant-dollar analysis, nominal rates "+
         "in current-dollar analysis.",
         "Enter the Residual Value Factor as a percent of initial replacement cost."};
      replacementTips.setTipsText(tips);
      setTitleAt(0, "Major Repair and Replacement Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Major Repair and Replacement Cost");
      timingLabel.setText("Years/Months (from BOD):");}

     else{
       String tips[] = {"Enter years and months from BOD.",
         "Enter the amount in base-year dollars.",
         "Use real rates of increase in constant-dollar analysis, nominal rates "+
         "in current-dollar analysis.",
         "Enter the Residual Value Factor as a percent of initial replacement cost.",
				 "Major Repair and Replacement Costs are treated as capital costs in the calculation of SIR and AIRR."};
       replacementTips.setTipsText(tips);
       setTitleAt(0, "Major Repair and Replacement Cost");
      ((javax.swing.border.TitledBorder) panel.getBorder()).setTitle("Major Repair and Replacement Cost");
       timingLabel.setText("Years/Months (from BOD):");}



  }
}
