package blcc.gui;

import javax.swing.*;
import java.awt.Dimension;
import java.awt.Component;
import javax.swing.table.DefaultTableModel;
import blcc.gui.widgets.*;
import blcc.model.RecurringContractCost;
import blcc.model.Alternative;
import blcc.model.ModelElement;
import blcc.model.VaryingEscalation;
import blcc.model.Escalation;
import blcc.model.SimpleEscalation;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.tree.TreePath;
import java.awt.Color;

public class RecurringContractTabbed extends TabbedPane {
  RecurringContractCost cost;
  TextField nameInput;
  DoubleField amountInput;
  //DoubleField rateInput;
  JButton deleteButton;
  VaryingTable indicesTable;
	VaryingTable escalationTable;
	TipsSubPanel recurringTips;

  public RecurringContractTabbed(BLCC5 blcc) {
    super(blcc);
    addTab("Annually Recurring Contract-Related Cost", getRecurringTab());
    addTab("Usage Indices", getIndicesTab());
    addTab("Delete", getDeleteTab());
  }

  public void getInformation (ModelElement element) {
    cost = (RecurringContractCost) element;
    nameInput.setValue(cost.getName());
    amountInput.setValue(cost.getAmount());

		Escalation esc = cost.getEscalation();
		if (esc == null){
			esc = VaryingEscalation.createVaryingEscalation(0.0);
			cost.setEscalation(esc);}
    else if (esc instanceof SimpleEscalation){
			esc=VaryingEscalation.createVaryingEscalation(((SimpleEscalation)esc).getRateWithoutInflation());
		  cost.setEscalation(esc);
			//System.out.println(((VaryingEscalation)esc).getValues()[0]);

			}

		escalationTable.setValue(((VaryingEscalation)esc));

    // for now, assume SimpleEscalation
    //rateInput.setValue(((SimpleEscalation)cost.getEscalation()).getRate());
    indicesTable.setValue(cost.getIndex());
  }

  public void setInformation (ModelElement element) {
    // stop editing and save model
    if (indicesTable.isEditing())
      indicesTable.editingStopped(new javax.swing.event.ChangeEvent(indicesTable));
    if (escalationTable.isEditing())
      escalationTable.editingStopped(new javax.swing.event.ChangeEvent(escalationTable));

  }

  public JPanel getRecurringTab() {

    TabPanel tab = new TabPanel();
    FormPanel panel =
      new FormPanel("Annually Recurring Contract-Related Cost");
		String tips[] = {"", "", "", ""};
    panel.addField(Factory.makeLabel("Name:"),
		   nameInput = new TextField());
    nameInput.addChangedListener(owner);
    nameInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  cost.setName(nameInput.getValue()); }});
   nameInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {amountInput.requestFocus(); }});


    panel.addField(Factory.makeLabel("Amount:"),
       amountInput = new DoubleField("$#,##0.00", false));
    amountInput.addChangedListener(owner);
    amountInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  cost.setAmount(amountInput.getValue()); }});
   amountInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {escalationTable.requestFocus(); }});



		/*
    panel.addField(Factory.makeLabel("Annual Rate of Increase:"),
       rateInput = new DoubleField("##0.00%", true));
    rateInput.addChangedListener(owner);
    rateInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  ((SimpleEscalation)cost.getEscalation())
	    .setRate(rateInput.getValue()); }});
   rateInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {nameInput.requestFocus(); }});
	 */

    tab.addSubPanel(panel);

		escalationTable = new VaryingTable("Escalation","##0.00%");
    tab.addSubPanel(Factory.makeSubPanel("Escalation Rates",
       new JScrollPane(escalationTable)));
    escalationTable.addChangedListener(owner);
    escalationTable.addChangedListener(new DefaultChangedListener(){
	  public void noteChange(ChangedEvent e){
	    owner.setNeedsSave(true); }});




    tab.addSpacerPanel();
		tab.addSubPanel(recurringTips = new TipsSubPanel(tips));

    return tab;  }

  public JPanel getIndicesTab() {
    String tips[] = {"Enter duration and percentage of the base-year amount "+
    "for the appropriate period."};

    TabPanel tab = new TabPanel();
    indicesTable = new VaryingTable("Usage Factor","##0.00%");
    tab.addSubPanel(Factory.makeSubPanel("Usage Indices",
       new JScrollPane(indicesTable)));
    indicesTable.addChangedListener(owner);
    indicesTable.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  owner.setNeedsSave(true); }});

    tab.addSpacerPanel();
    tab.addSubPanel(new TipsSubPanel(tips));
    return tab;  }

  public JPanel getDeleteTab() {
    TabPanel tab = new TabPanel();
    tab.addSubPanel(Factory.makeButtonSubPanel(
         deleteButton = new JButton ("Delete This Cost")));
    deleteButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e) {
    if (owner.confirmDelete("cost") == JOptionPane.YES_OPTION) {
	    BLCCTreeNode selectedNode = owner.getCurrentNode();
	    BLCCTreeNode parentNode = (BLCCTreeNode) selectedNode.getParent();
      Alternative alt = (Alternative)parentNode.getElement();
      alt.removeRecurringContractCost((RecurringContractCost)selectedNode.getElement());
	    owner.getTreeModel().removeNodeFromParent(selectedNode);
	    owner.setPreviousNode(null);
	    // find a path from root to the node that should be selected
	    TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(parentNode));
	    // select the path
	    owner.getTree().setSelectionPath(newPath);
	    owner.setNeedsSave(true);
	  }}});
    return tab; }


    public void setAnalysisSpecific(int analysisType) {
    if (analysisType == blcc.model.Project.OMBANALYSIS) {
      String tips[] = {
    	"Enter amount in base-year dollars.",
    	"Use real rates of escalation in constant-dollar analysis, nominal rates in current-dollar analysis.",
    	"Use Usage Indices to specify variable pattern of occurrence."};
			recurringTips.setTipsText(tips);}
    else {
		   String tips[] = {
    		"Enter amount in base-year dollars.",
    		"Use real rates of escalation in constant-dollar analysis, nominal rates in current-dollar analysis.",
    		"Use Usage Indices to specify variable pattern of occurrence.",
	  		"Use the Energy Escalation Rate Calculator (EERC) if you need to compute an average annual contract escalation rate based on DOE energy price forecasts."};
      recurringTips.setTipsText(tips);}
		}




  public Boolean guiValidate(ModelElement element) {
    boolean show = true;
    try {element.validate(false);}
    catch(blcc.model.ValidationException e){
      TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(owner.getPreviousNode()));  // go back to node with validation exception
      owner.setPreviousNode(null);  // set previousNode to null so it won't reset (and revalidate) the node
      owner.getTree().setSelectionPath(newPath);
      JOptionPane.showMessageDialog(owner,
            e.getMessage(),
            "Error",
				    JOptionPane.ERROR_MESSAGE);
      show = false; }
    return new Boolean(show); }


}
