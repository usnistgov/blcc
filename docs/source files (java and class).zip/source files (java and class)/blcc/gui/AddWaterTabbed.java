package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import blcc.model.WaterUsage;
import blcc.model.Alternative;
import blcc.model.ModelElement;
import blcc.model.Project;
import java.util.Vector;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;

public class AddWaterTabbed extends TabbedPane {
  TextField nameInput;
  Chooser copyInput;
  JButton copyButton, addButton;
  FormPanel addPanel, copyPanel;
  JLabel addLabel, copyLabel;



  public AddWaterTabbed(BLCC5 blcc) {
    super(blcc);
    TabPanel tab = new TabPanel();
    addPanel = new FormPanel("");
    addPanel.addField(addLabel=Factory.makeLabel(""),
		      nameInput = new TextField());
    nameInput.addCaretListener(new CaretListener(){
	public void caretUpdate(CaretEvent e){
	  addButton.setEnabled(!nameInput.getValue().equals("")); }});

    tab.addSubPanel(addPanel);

    tab.addSubPanel(Factory.makeButtonSubPanel(
                 addButton = new JButton("")));
    addButton.setEnabled(false);
    addButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	BLCCTreeNode node = owner.getCurrentNode();
	WaterUsage water = new WaterUsage();
	water.setName(nameInput.getText());
	((Alternative)node.getParentElement()).addWaterUsage(water);
	owner.createWaterSubNode(node, water,true);
	owner.setNeedsSave(true);
  nameInput.setValue("");  }});

 copyPanel = new FormPanel("");
 copyPanel.addField(copyLabel=Factory.makeLabel(""),
                copyInput = new Chooser());

 tab.addSubPanel(copyPanel);
 tab.addSubPanel(Factory.makeButtonSubPanel(copyButton = new JButton("")));

 copyButton.addActionListener(new ActionListener(){
 public void actionPerformed(ActionEvent e) {
  WaterUsage currentWater= (WaterUsage)copyInput.getChoice();
  WaterUsage newWater = currentWater.copyWaterUsage();
  BLCCTreeNode node = owner.getCurrentNode();
  ((Alternative) node.getParentElement()).addWaterUsage(newWater);
  owner.createWaterSubNode(node, newWater, true);
  owner.setNeedsSave(true); }});

  copyButton.setEnabled(false);



    addTab("", tab); }

 public void getInformation(ModelElement element) {

  Vector water = owner.getProject().getWaterChoices();

  if(water.size() != 0){
   copyInput.setChoices(water);
   copyButton.setEnabled(true);}
  else
  {
   String choices[] ={"None"};
   copyInput.setChoices(choices);
   copyButton.setEnabled(false);}
 }

  public void setAnalysisSpecific(int analysisType) {
    if (analysisType == Project.MILCONECIPANALYSIS){
      addLabel.setText("Savings/Cost Name:");
      setTitleAt(0, "Add Water Savings/Cost");
      ((javax.swing.border.TitledBorder) addPanel.getBorder()).setTitle("Create New Savings/Cost");
      addButton.setText("Create Savings/Cost");
      ((javax.swing.border.TitledBorder) copyPanel.getBorder()).setTitle("Copy Existing Savings/Cost");
      copyButton.setText("Copy Savings/Cost");
      copyLabel.setText("Savings/Cost to Copy:");}
  else{
      addLabel.setText("Cost Name:");
      setTitleAt(0, "Add Water Cost");
      ((javax.swing.border.TitledBorder) addPanel.getBorder()).setTitle("Create New Cost");
      addButton.setText("Create Cost");
      ((javax.swing.border.TitledBorder) copyPanel.getBorder()).setTitle("Copy Existing Cost");
      copyButton.setText("Copy Cost");
      copyLabel.setText("Cost to Copy:");}
  }



}
