package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import blcc.model.Project;
import blcc.model.Alternative;
import blcc.model.CapitalComponent;
import blcc.model.ModelElement;
import blcc.model.SimpleEscalation;
import javax.swing.event.*;
import javax.swing.tree.TreePath;
import blcc.util.DateDiff;
import blcc.util.Defaults;
import blcc.util.DOEPrices;
import java.util.Vector;
import blcc.util.Defaults;
import java.awt.FlowLayout;


public class ProjectTabbed extends TabbedPane {
  Project project;

  TextField nameInput;
  Chooser locationInput;
  TextField analystInput;
  TextArea descriptionInput;
  DoubleField discountInput;
  JLabel discountLabel;
  RadioButton constantDollarInput;
  RadioButton currentDollarInput;
	DateDiffField FirststudyLengthInput;

  RadioButton endYearInput;
  RadioButton midYearInput;
  RadioButton endYearInputalt;
  RadioButton midYearInputalt;
	TabPanel Generaltab;


	RadioButton regInput;    //LIS addition
	RadioButton costInput;
	FormPanel panel2a;
	FormPanel panel2;
	FormPanel panel3;

  TipsSubPanel datesTips;
  DateDiffField studyLengthInput;
  DateField baseDateInput;
  DateDiffField PCPeriodInput;
  JLabel PCPeriodLabel;
	JLabel StudyPeriodLabel;
  JLabel baseDateLabel;

	TipsSubPanel generalTips;

	int projectType;

  TextField alternativeName;
  JButton addButton;

  Chooser copyInput;
  JButton copyButton;
	boolean already=false;

  public ProjectTabbed(BLCC5 blcc) {
    super(blcc);
		addTab("General Information", getGeneralTab());
    addTab("Key Dates", getKeyDatesTab());
    addTab("Add Alternative", getAddAlternativeTab());
  }

  public void getInformation(ModelElement element) {
    project = (Project)element;

    Vector alts = project.getAlternativeChoices();
    if(alts.size() != 0){
     copyInput.setChoices(alts);
     copyButton.setEnabled(true);}
    else
    {
     String choices[] ={"None"};
     copyInput.setChoices(choices);
     copyButton.setEnabled(false);}

    nameInput.setValue(project.getName());
    locationInput.setChoice(project.getLocation());
    analystInput.setValue(project.getAnalyst());
    descriptionInput.setValue(project.getComment());
    baseDateInput.setValue(project.getBaseDate());

    PCPeriodInput.setValue(project.getPCPeriod());
    studyLengthInput.setValue(project.getDuration());

		FirststudyLengthInput.setValue(project.getDuration());  //lis addition

    discountInput.setValue(project.getDiscountRate());

    endYearInput.setValue(project.getDiscountingMethod() == Project.ENDYEARDISCOUNTING);
    midYearInput.setValue(project.getDiscountingMethod() == Project.MIDYEARDISCOUNTING);

	  if (project.getDollarMethod() == Project.CONSTANTDOLLARMETHOD) {
      constantDollarInput.setValue(true);
      currentDollarInput.setValue(false);
      discountLabel.setText("Real Discount Rate:");
    }
    else {
      currentDollarInput.setValue(true);
      constantDollarInput.setValue(false);
      discountLabel.setText("Nominal Discount Rate:");
    }
		if ( project.getAnalysisPurpose()==Project.INVEST_REGULATION ) {
			regInput.setValue(true);
			costInput.setValue(false);
		}else if (project.getAnalysisPurpose()==Project.COST_LEASE){
			regInput.setValue(false);
			costInput.setValue(true);
		}


  }

  public void setInformation(ModelElement element) {}

  public JPanel getGeneralTab() {
		String tips[] = {"","","","",""};
    Generaltab = new TabPanel();
    FormPanel panel1 = new FormPanel("General Project Information");
    panel1.addField(Factory.makeLabel("Name:"),
		    nameInput = new TextField());
    nameInput.addChangedListener(owner);
    nameInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  project.setName(nameInput.getValue()); }});
   nameInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {locationInput.requestFocus(); }});


    panel1.addField(Factory.makeLabel("Location:"),
          locationInput = new Chooser(DOEPrices.getStates()));
    locationInput.addChangedListener(owner);
    locationInput.addChangedListener(new DefaultChangedListener(){
    public void noteChange(ChangedEvent e){
      project.setLocation((String)locationInput.getChoice()); }});

    panel1.addField(Factory.makeLabel("Analyst:"),
		    analystInput = new TextField());
    analystInput.addChangedListener(owner);
    analystInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  project.setAnalyst(analystInput.getValue()); }});
   analystInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {descriptionInput.requestFocus(); }});


    panel1.addCommentField(Factory.makeLabel("Comment:"),
			   new JScrollPane(descriptionInput = new TextArea()));
    descriptionInput.addChangedListener(owner);
    descriptionInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  project.setComment(descriptionInput.getValue()); }});

	 //Begin Schultz Change

			 	panel2a = new FormPanel("Analysis Purpose");   					//Schultz Addition for OMB analysis.  What is the purpose of analysis?

			panel2a.addField(costInput = new RadioButton("Cost Effectiveness, Lease Purchase, Internal Government Investment or Asset Sale Analysis"));
			costInput.addChangedListener(owner);
			costInput.addChangedListener(new DefaultChangedListener(){
				public void noteChange(ChangedEvent e){
					project.setAnalysisPurpose(Project.COST_LEASE);
					regInput.setValue(false);
					project.setDiscountRate();
				 discountInput.setValue(project.getDiscountRate());}});

				panel2a.addField(regInput = new RadioButton("Public Investment or Regulatory Analysis"));
				regInput.setValue(!costInput.getValue());
				regInput.addChangedListener(owner);
				regInput.addChangedListener(new DefaultChangedListener(){
				public void noteChange(ChangedEvent e){
					project.setAnalysisPurpose(Project.INVEST_REGULATION);
				 	costInput.setValue(false);
					project.setDiscountRate();
					discountInput.setValue(project.getDiscountRate());}});




		//End Schultz Change
		ButtonGroup purpose = new ButtonGroup();
		purpose.add(costInput);
		purpose.add(regInput);
		panel2a.setVisible(false);


    panel2 = new FormPanel("Discounting Convention");
    panel2.addField(endYearInput = new RadioButton("End-of-Year Discounting"));
    endYearInput.addChangedListener(owner);
    endYearInput.addChangedListener(new DefaultChangedListener(){
    public void noteChange(ChangedEvent e){
      project.setDiscountingMethod(Project.ENDYEARDISCOUNTING);
      midYearInput.setValue(false); }});

    panel2.addField(midYearInput = new RadioButton("Mid-Year Discounting"));
    midYearInput.addChangedListener(owner);
    midYearInput.addChangedListener(new DefaultChangedListener(){
    public void noteChange(ChangedEvent e){
      project.setDiscountingMethod(Project.MIDYEARDISCOUNTING);
      endYearInput.setValue(false); }});

    ButtonGroup discounting = new ButtonGroup();
    discounting.add(endYearInput);
    discounting.add(midYearInput);
		panel2.setVisible(true);


		panel3 = new FormPanel("Analysis Information");
    panel3.addField(constantDollarInput= new RadioButton("Constant Dollar Analysis"));
    constantDollarInput.addChangedListener(owner);
    constantDollarInput.addChangedListener(new DefaultChangedListener(){
    public void noteChange(ChangedEvent e){
      project.setDollarMethod(Project.CONSTANTDOLLARMETHOD);
      discountLabel.setText("Real Discount Rate:");
      discountInput.setValue(project.getDiscountRate());
      currentDollarInput.setValue(false); }});
   constantDollarInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {discountInput.requestFocus(); }});

    panel3.addField(currentDollarInput= new RadioButton("Current Dollar Analysis"));
    currentDollarInput.addChangedListener(owner);
    currentDollarInput.addChangedListener(new DefaultChangedListener(){
    public void noteChange(ChangedEvent e){
      project.setDollarMethod(Project.CURRENTDOLLARMETHOD);
      discountLabel.setText("Nominal Discount Rate:");
      discountInput.setValue(project.getDiscountRate());
      constantDollarInput.setValue(false); }});
   currentDollarInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {discountInput.requestFocus(); }});
   currentDollarInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {discountInput.requestFocus(); }});



    ButtonGroup dollar = new ButtonGroup();
    dollar.add(constantDollarInput);
    dollar.add(currentDollarInput);


		//lis addition:  Need to know study period earlier to determine discount rate
		panel3.addField(StudyPeriodLabel=Factory.makeLabel("Length of Study Period:"),   //Need to know the length of the study period to determine discount rate
		FirststudyLengthInput = new DateDiffField());
    FirststudyLengthInput.addChangedListener(owner);
    FirststudyLengthInput.addChangedListener(new DefaultChangedListener(){
	    public void noteChange(ChangedEvent e){
       project.setDuration(FirststudyLengthInput.getValue());
			 studyLengthInput.setValue(project.getDuration());
			 project.setDiscountRate();
			 discountInput.setValue(project.getDiscountRate());}});
    FirststudyLengthInput.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {baseDateInput.getMonthField().requestFocus(); }});
		StudyPeriodLabel.setVisible(false);
		FirststudyLengthInput.setVisible(false);

		//end lis addition

    panel3.addField(discountLabel = Factory.makeLabel(""),
                    discountInput = new DoubleField("##0.0%", true));
    discountInput.addChangedListener(owner);
    discountInput.addChangedListener(new DefaultChangedListener(){
    public void noteChange(ChangedEvent e){
      project.setDiscountRate(discountInput.getValue()); }});
   discountInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {nameInput.requestFocus(); }});


    Generaltab.addSubPanel(panel1);
    Generaltab.addSubPanel(panel2a);
		Generaltab.addSubPanel(panel2);
    Generaltab.addSubPanel(panel3);
    Generaltab.addSpacerPanel();
    Generaltab.addSubPanel(generalTips=new TipsSubPanel(tips));

    return Generaltab;  }

  public JPanel getKeyDatesTab() {
    String tips[] = {"","",""};
    TabPanel datesTab = new TabPanel();
    FormPanel dates1 = new FormPanel("General Information");
    dates1.addField(baseDateLabel = Factory.makeLabel("Base Date:"),
		    baseDateInput = new DateField());
    baseDateInput.addChangedListener(owner);
    baseDateInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
   project.setBaseDate(baseDateInput.getValue()); }});
   baseDateInput.getYearField().addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {if(PCPeriodInput.isVisible()) PCPeriodInput.requestFocus();
                                               else studyLengthInput.requestFocus(); }});



    dates1.addField(PCPeriodLabel = Factory.makeLabel(""),
		    PCPeriodInput = new DateDiffField());
    PCPeriodInput.addChangedListener(owner);
    PCPeriodInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  project.setPCPeriod(PCPeriodInput.getValue()); }});
   PCPeriodInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {studyLengthInput.requestFocus(); }});


    dates1.addField(Factory.makeLabel("Length of Study Period:"),
		    studyLengthInput = new DateDiffField());
    studyLengthInput.addChangedListener(owner);
    studyLengthInput.addChangedListener(new DefaultChangedListener(){
	    public void noteChange(ChangedEvent e){
       project.setDuration(studyLengthInput.getValue());
			 FirststudyLengthInput.setValue(project.getDuration());
			 project.setDiscountRate();
			 discountInput.setValue(project.getDiscountRate()); }});
   //lis change
    studyLengthInput.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {baseDateInput.getMonthField().requestFocus(); }});

    datesTab.addSubPanel(dates1);
    datesTab.addSpacerPanel();
    datesTab.addSubPanel(datesTips = new TipsSubPanel(tips));
    return datesTab;  }

  public JPanel getAddAlternativeTab() {
    String[] tips = {"A project consists of two or more alternatives, one of which is "+
     "the base case."};
    TabPanel tab = new TabPanel();
    FormPanel panel = new FormPanel("Create New Alternative");
    panel.addField(Factory.makeLabel("Alternative Name:"),
		   alternativeName = new TextField());
    alternativeName.addCaretListener(new CaretListener(){
	public void caretUpdate(CaretEvent e){
	  addButton.setEnabled(!alternativeName.getValue().equals("")); }});

    tab.addSubPanel(panel);
    tab.addSubPanel(Factory.makeButtonSubPanel(
         addButton = new JButton("Create Alternative")));
    addButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e) {
	  Alternative alternative = new Alternative();
	  alternative.setName(alternativeName.getText());
	  owner.getProject().addAlternative(alternative);
	  CapitalComponent component = new CapitalComponent();
	  alternative.addCapitalComponent(component);
    owner.createAlternativeNode(alternative,true, false);
	  alternativeName.setText("");
	  owner.setNeedsSave(true);
	}});
   addButton.setEnabled(false);

   FormPanel panel2 = new FormPanel("Copy Existing Alternative");
   panel2.addField(Factory.makeLabel("Alternative to Copy:"),
                copyInput = new Chooser());
   tab.addSubPanel(panel2);
   tab.addSubPanel(Factory.makeButtonSubPanel(copyButton = new JButton("Copy Alternative")));


   copyButton.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {

    Alternative currentAlt = (Alternative)copyInput.getChoice();
    Alternative newAlt = currentAlt.copyAlternative();
    currentAlt.getProject().addAlternative(newAlt);
    owner.createAlternativeNode(newAlt, true, false);
    owner.setNeedsSave(true); }});

    copyButton.setEnabled(false);

    tab.addSpacerPanel();
    tab.addSubPanel(new TipsSubPanel(tips));

   return tab;  }

  public JRadioButton getEndYearInput() {
    return endYearInput;  }

  public Boolean guiValidate(ModelElement element) {
    boolean show = true;

   // workaround:  updated to Java 1.6 in version 5.3-10; problem occurs when validation is done;
   // values were NOT being saved before the validation so the error message would appear even though the
   // values were fine or the error message would not always appear when the values were not valid

   project.setDuration(studyLengthInput.getValue());
   project.setBaseDate(baseDateInput.getValue());
   project.setDiscountRate(discountInput.getValue());
   project.setPCPeriod(PCPeriodInput.getValue());

    try{element.validate(false);}
    catch(blcc.model.ValidationException e){
      TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(owner.getPreviousNode()));  // go back to node with validation exception
      owner.setPreviousNode(null);  // set previousNode to null so it won't reset (and revalidate) the node
      owner.getTree().setSelectionPath(newPath);

      if (e.getAttribute().equals("DiscountRate") ||
          e.getAttribute().equals("InflationRate")||
          e.getAttribute().equals("MonetaryUnits"))
       setSelectedIndex(0);  // general info tab
      else setSelectedIndex(1); // key dates tab
      JOptionPane.showMessageDialog(owner,
				    e.getMessage(),
            "Error",
				    JOptionPane.ERROR_MESSAGE);
      show = false; }
    return new Boolean(show); }

  public void setAnalysisSpecific(int analysisType) {
		// get defaults for tips from file so numbers aren't hardcoded
		int aprilTip = Defaults.getIntegerItem("default year");
	 	int marchTip = Defaults.getIntegerItem("default year")+1;
		double realTip = Defaults.getDoubleItem("real discount")*100;
		double inflationTip = Defaults.getDoubleItem("inflation")*100;
		String InflationTip = new java.text.DecimalFormat("##.##").format(inflationTip);
		String nominalTip = new java.text.DecimalFormat("##.0").format(((1.0 + Defaults.getDoubleItem("real discount"))*(1.0 + blcc.util.Defaults.getDoubleItem("inflation")) - 1.0) *100);
		//System.out.println(analysisType);
    if (analysisType == Project.FINANCEDANALYSIS) {
      PCPeriodLabel.setVisible(false);
      PCPeriodInput.setVisible(false);
      String daTips[] = {
      "Base Date is beginning of Study Period.",
      "For financed projects, operational costs and replacement costs are timed from the Base Date, i.e., Base Date "+
      "and Service Date coincide.",
      "Study Period cannot exceed 25 years for financed projects.",
      "Add 'y' to number of years and 'm' to number of months, e.g., 2y 4m or enter 'r' for Remaining (years in study period)."};
      datesTips.setTipsText(daTips);
      String genTips[] = {
      "For locations outside the contiguous United States, the selection of U.S. Average may be appropriate.",
      "Annually recurring costs can be discounted from the end of the year (FEMP) or the middle of the year (DoD) to the Base Date.",
      "Constant-dollar amounts and real discount and escalation rates exclude general inflation.",
      "Current-dollar amounts and nominal discount and escalation rates include general inflation.",
      "FEMP discount and inflation rates, valid for energy and water conservation and renewable energy analyses " +
      "conducted between April 1, "+ aprilTip + " and March 31, "+ marchTip+ ":\n" +
      "\tDiscount rates:\t"+realTip+"% real\n" +
      "\t\t"+nominalTip+"% nominal\n" +
      "\tInflation rate:\t"+InflationTip+ "%"};
			generalTips.setTipsText(genTips);
			//constantDollarInput.setEnabled(true);
			currentDollarInput.setEnabled(true);
      if(indexOfTab("Add Alternative")== -1) {addTab("Add Alternative", getAddAlternativeTab());}}
    else if (analysisType == Project.AGENCYFUNDEDANALYSIS)  {
      PCPeriodLabel.setText("Service Date (from Base Date):");
      PCPeriodLabel.setVisible(true);
      PCPeriodInput.setVisible(true);
      String daTips[] = {
      "Base Date is beginning of Study Period.",
      "Operational costs and replacement costs are timed from Service Date.",
			"Length of Study Period includes Planning/Construction/Installation Period and Service Period. "+
      "Service Period cannot exceed 40 years in FEMP analyses.",
      "Add 'y' to number of years and 'm' to number of months, e.g., 2y 4m or enter 'r' for Remaining (years in study period)."};
      datesTips.setTipsText(daTips);
      String genTips[] = {
      "For locations outside the contiguous United States, the selection of U.S. Average may be appropriate.",
      "Annually recurring costs can be discounted from the end of the year (FEMP) or the middle of the year (DoD) to the Base Date.",
      "Constant-dollar amounts and real discount and escalation rates exclude general inflation.",
      "Current-dollar amounts and nominal discount and escalation rates include general inflation.",
      "FEMP discount and inflation rates, valid for energy and water conservation and renewable energy analyses " +
      "conducted between April 1, "+ aprilTip + " and March 31, "+ marchTip+ ":\n" +
      "\tDiscount rates:\t"+realTip+"% real\n" +
      "\t\t"+nominalTip+"% nominal\n" +
      "\tInflation rate:\t"+InflationTip+ "%"};
			generalTips.setTipsText(genTips);
			//constantDollarInput.setEnabled(true);
			currentDollarInput.setEnabled(true);
			//panel2a.setVisible(false);
      if(indexOfTab("Add Alternative")== -1) {addTab("Add Alternative", getAddAlternativeTab());}}
     else if (analysisType == Project.MILCONENERGYANALYSIS){
      PCPeriodLabel.setText("Beneficial Occupancy Date (from Base Date):");
      PCPeriodLabel.setVisible(true);
      PCPeriodInput.setVisible(true);
     String daTips[] = {
      "Base Date is beginning of Study Period.",
      "Operational costs and replacement costs are timed from Beneficial Occupancy Date.",
      "Length of Study Period includes Planning/Construction/Installation Period and Beneficial Occupancy Period (Service Period). " +
      "Beneficial Occupancy Period cannot exceed 40 years for energy or water conservation or renewable energy project.",
      "Add 'y' to number of years and 'm' to number of months, e.g., 2y 4m or enter 'r' for Remaining (years in study period)."};
      datesTips.setTipsText(daTips);
      String genTips[] = {
      "For locations outside the contiguous United States, the selection of U.S. Average may be appropriate.",
      "Annually recurring costs can be discounted from the end of the year (FEMP) or the middle of the year (DoD) to the Base Date.",
      "Constant-dollar amounts and real discount and escalation rates exclude general inflation.",
      "Current-dollar amounts and nominal discount and escalation rates include general inflation.",
      "FEMP discount and inflation rates, valid for energy and water conservation and renewable energy analyses " +
      "conducted between April 1, "+ aprilTip + " and March 31, "+ marchTip+ ":\n" +
      "\tDiscount rates:\t"+realTip+"% real\n" +
      "\t\t"+nominalTip+"% nominal\n" +
      "\tInflation rate:\t"+InflationTip+ "%"};
			generalTips.setTipsText(genTips);
			//constantDollarInput.setEnabled(true);
			currentDollarInput.setEnabled(true);
		 //	panel2a.setVisible(false);
      if(indexOfTab("Add Alternative")== -1) {addTab("Add Alternative", getAddAlternativeTab());}}
    else if (analysisType == Project.MILCONECIPANALYSIS){
      PCPeriodLabel.setText("Beneficial Occupancy Date (from Base Date):");
      PCPeriodLabel.setVisible(true);
      PCPeriodInput.setVisible(true);
      String daTips[] = {
      "Base Date is beginning of Study Period.",
      "Operational costs are timed from Beneficial Occupancy Date and discounted to the Base Date.",
      "Length of Study Period includes Planning/Construction/Installation Period and Beneficial Occupancy Period (Service Period). " +
      "Beneficial Occupancy Period cannot exceed 40 years for energy or water conservation or renewable energy project.",
      "Add 'y' to number of years and 'm' to number of months, e.g., 2y 4m or enter 'r' for Remaining (years in study period)."};
      datesTips.setTipsText(daTips);
      String genTips[] = {
      "For locations outside the contiguous United States, the selection of U.S. Average may be appropriate.",
      "Annually recurring costs can be discounted from the end of the year (FEMP) or the middle of the year (DoD) to the Base Date.",
      "Constant-dollar amounts and real discount and escalation rates exclude general inflation.",
      "FEMP discount and inflation rates, valid for energy and water conservation and renewable energy analyses " +
      "conducted between April 1, "+ aprilTip + " and March 31, "+ marchTip+ ":\n" +
      "\tDiscount rates:\t"+realTip+"% real\n" +
      "\t\t"+nominalTip+"% nominal\n" +
      "\tInflation rate:\t"+InflationTip+ "%"};
			generalTips.setTipsText(genTips);
			//constantDollarInput.setEnabled(false);
			currentDollarInput.setEnabled(false);
			//panel2a.setVisible(false);
      if(indexOfTab("Add Alternative")!= -1){removeTabAt(2);}
     } else if (analysisType==Project.OMBANALYSIS){                   //lis:  Only OMB analysis depends on Project Purpose.
			 				FirststudyLengthInput.setVisible(true);
				StudyPeriodLabel.setVisible(true);

      	PCPeriodLabel.setText("Service Date (from Base Date):");
      	PCPeriodLabel.setVisible(true);
      	PCPeriodInput.setVisible(true);
        String daTips[] = {
         "Base Date is beginning of Study Period.",
         "Length of Study Period includes Planning/Construction/Installation Period "+
				 "and Service Period.  OMB analyses allow unlimited study periods.",
      	 "Add 'y' to number of years and 'm' to number of months, e.g., 2y 4m or enter 'r' for Remaining (years in study period).",
				 "Operational costs and replacement costs are timed from Service Date"};
      	datesTips.setTipsText(daTips);
      	String genTips[] = {
      		"For locations outside the contiguous United States, the selection of U.S. Average may be appropriate.",
      		"Annually recurring costs can be discounted from the end of the year (FEMP) or the middle of the year (DoD) to the Base Date.",
		      "Constant-dollar amounts and real discount and escalation rates exclude general inflation.",
		      "Current-dollar amounts and nominal discount and escalation rates include general inflation.",
					"OMB discount rates vary with the length of the study period to be used in the economic analysis.",
					"For a list of current OMB discount and inflation rates, see HELP - Performing OMB Analyses - "+aprilTip+" OMB Discount Rates."};
				generalTips.setTipsText(genTips);
			//constantDollarInput.setEnabled(true);
			currentDollarInput.setEnabled(true);

			 panel2a.setVisible(true);
			 panel2.changeLayout();
			 panel3.changeLayout3();
			 if ( !already ) {
					Generaltab.remove(4);
					already=true;
			 }

      if(indexOfTab("Add Alternative")== -1) {addTab("Add Alternative", getAddAlternativeTab());}
      }else if (analysisType==Project.MILCONNONENERGYANALYSIS){
				FirststudyLengthInput.setVisible(true);
				StudyPeriodLabel.setVisible(true);

      	PCPeriodLabel.setText("Beneficial Occupancy Date (from Base Date):");
      	PCPeriodLabel.setVisible(true);
      	PCPeriodInput.setVisible(true);
	     	String daTips[] = {
  	    "Base Date is beginning of Study Period.",
    	  "Operational costs and replacement costs are timed from Beneficial Occupancy Date.",
				"Length of Study Period includes Planning/Construction/Installation Period and Beneficial Occupancy Period (Service Period).",
				"Add 'y' to number of years and 'm' to number of months, e.g., 2y 4m or enter 'r' for Remaining (years in study period)."};

      	datesTips.setTipsText(daTips);
      	String genTips[] = {
      		"For locations outside the contiguous United States, the selection of U.S. Average may be appropriate.",
      		"Annually recurring costs can be discounted from the end of the year (FEMP) or the middle of the year (DoD) to the Base Date.",
		      "Constant-dollar amounts and real discount and escalation rates exclude general inflation.",
		      "Current-dollar amounts and nominal discount and escalation rates include general inflation.",
					"OMB discount rates apply to MILCON design projects that are not primarily energy or water conservation projects.",
					"OMB discount rates vary with the length of the study period to be used in the economic analysis.",
					"For a list of current OMB discount and inflation rates, see HELP - Performing OMB Analyses - "+aprilTip+" OMB Discount Rates."};
				generalTips.setTipsText(genTips);
			//constantDollarInput.setEnabled(true);
			currentDollarInput.setEnabled(true);
//			 panel2a.setVisible(false);
//			 panel2.changeLayout();
			 panel3.changeLayout3();
      if(indexOfTab("Add Alternative")== -1) {addTab("Add Alternative", getAddAlternativeTab());}
		 }				 																																	//
  }
}
