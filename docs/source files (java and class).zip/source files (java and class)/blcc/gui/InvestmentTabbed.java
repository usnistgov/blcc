package blcc.gui;

import javax.swing.*;
import javax.swing.table.TableModel;
import javax.swing.table.AbstractTableModel;
import blcc.gui.widgets.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Calendar;
import blcc.util.DateDiff;
import blcc.model.RecurringCost;
import blcc.model.ModelElement;
import blcc.model.CapitalComponent;
import blcc.model.SimpleEscalation;
import javax.swing.tree.TreePath;

public class InvestmentTabbed extends TabbedPane {
  CapitalComponent component;
  DoubleField initialCostInput;
  JLabel initialCostLabel;
  JLabel expectedLifeLabel;
  DateDiffField expectedLifeInput;
  DoubleField resaleInput;
  JLabel resaleLabel;
  DoubleField escalationInput;
  TipsSubPanel investmentTips;
  PhaseInTable pcTable;
  DoubleField resaleEscalationInput;
  JLabel financedLabel;
  DoubleField financedInput;

  public InvestmentTabbed(BLCC5 blcc) {
    super(blcc);
    addTab("Investment Cost", getInvestmentTab()); }

  public void getInformation (ModelElement element) {
    component = (CapitalComponent) element;
    initialCostInput.setValue(component.getInitialCost());
    financedInput.setValue(component.getAmountFinanced());
    expectedLifeInput.setValue(component.getDuration());

    resaleInput.setValue(component.getResaleValueFactor());
    // assume SimpleEscalation
    escalationInput.setValue(((SimpleEscalation)component
			      .getEscalation()).getRate());
    resaleEscalationInput.setValue(((SimpleEscalation)component
				     .getResaleEscalation()).getRate());
    pcTable.setValue(component.getPhaseIn());
  }
  public void setInformation(ModelElement element){

    if (pcTable.isEditing())
      pcTable.editingStopped(new javax.swing.event.ChangeEvent(pcTable));}

  public JPanel getInvestmentTab() {
    String tips[] = {"", "", "", ""};
    TabPanel tab = new TabPanel();
    FormPanel panel = new FormPanel("Initial Cost");
    panel.addField(initialCostLabel=Factory.makeLabel(""),
		   initialCostInput = new DoubleField("$#,##0.00",false));
    initialCostInput.addChangedListener(owner);
    initialCostInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
    component.setInitialCost(initialCostInput.getValue()); }});
  initialCostInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) { if(financedInput.isVisible()) financedInput.requestFocus();
                                                else resaleEscalationInput.requestFocus(); }});


    panel.addField(financedLabel = Factory.makeLabel("Initial Cost Financed (Base Year $):"),
       financedInput = new DoubleField("$#,##0.00",false));
    financedInput.addChangedListener(owner);
    financedInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
    component.setAmountFinanced(financedInput.getValue()); }});
  financedInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) { resaleEscalationInput.requestFocus(); }});


   panel.addField(Factory.makeLabel("Annual Rate of Increase:"),
     resaleEscalationInput = new DoubleField("##0.00%", true));
    resaleEscalationInput.addChangedListener(owner);
    resaleEscalationInput.addChangedListener(new DefaultChangedListener(){
    public void noteChange(ChangedEvent e){
     ((SimpleEscalation)component.getResaleEscalation())
	    .setRate(resaleEscalationInput.getValue()); }});
   resaleEscalationInput.addActionListener(new ActionListener(){
     public void actionPerformed(ActionEvent e) { expectedLifeInput.requestFocus(); }});


    panel.addField(expectedLifeLabel=Factory.makeLabel(""),
		   expectedLifeInput = new DateDiffField());
    expectedLifeInput.addChangedListener(owner);
    expectedLifeInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  component.setDuration(expectedLifeInput.getValue()); }});
  expectedLifeInput.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent e) { resaleInput.requestFocus(); }});


    panel.addField(resaleLabel=Factory.makeLabel(""),
		   resaleInput = new DoubleField("##0.00%", true));
    resaleInput.addChangedListener(owner);
    resaleInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  component.setResaleValueFactor(resaleInput.getValue()); }});
  resaleInput.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent e) { escalationInput.requestFocus(); }});

    tab.addSubPanel(panel);
    pcTable = new PhaseInTable();

    tab.addSubPanel(Factory.makeSubPanel("Cost-Phasing of Initial Cost",
                     Factory.makeLabel("Cost Adjustment Factor:"),
                     escalationInput = new DoubleField("##0.00%", true),
                     new JScrollPane(pcTable)));
    escalationInput.addChangedListener(owner);
    escalationInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  ((SimpleEscalation)component.getEscalation())
	    .setRate(escalationInput.getValue()); }});
  escalationInput.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent e) { pcTable.requestFocus(); }});

    pcTable.addChangedListener(owner);

    tab.addSpacerPanel();
    tab.addSubPanel(investmentTips = new TipsSubPanel(tips));
    return tab; }

  public void setAnalysisSpecific(int analysisType) {
    if (analysisType == blcc.model.Project.FINANCEDANALYSIS) {
      String tips[] = {
      "Initial (investment) Costs Paid by Agency in base-year dollars are costs not included in "+
      "annual Contract Payment (e.g., down-payment).",
      "Sum of Initial (investment) Cost Paid by Agency and Initial (investment) "+
      "Cost Financed is used to calculate Residual Value.",
      "Enter expected rate of equipment price increase during Study Period.",
      "Enter Cost Adjustment Factor for phased-in initial investment cost.",
      "Use real rates of increase in constant-dollar analysis, nominal rates in current-dollar analysis."};
      investmentTips.setTipsText(tips);
      initialCostLabel.setText("Initial Cost Paid By Agency (Base Year $):");
      resaleLabel.setText("Residual Value Factor (% of Total Investment):");
      financedInput.setVisible(true);
      financedLabel.setVisible(true);
      expectedLifeLabel.setText("Expected Life (from Base Date):");}
    else if(analysisType == blcc.model.Project.AGENCYFUNDEDANALYSIS){
      String tips[] = {
      "Initial Cost is incurred at the Base Date or phased in during the P/C Period.",
      "Enter expected rate of equipment price increase during Study Period.",
      "Enter Cost Adjustment Factor for phased-in initial investment cost.",
      "Use real rates in constant-dollar analysis, nominal rates in current-dollar analysis."};
      investmentTips.setTipsText(tips);
      initialCostLabel.setText("Initial Cost (Base Year Dollars):");
      resaleLabel.setText("Residual Value Factor (% of Initial Cost):");
      financedInput.setVisible(false);
      financedLabel.setVisible(false);
      expectedLifeLabel.setText("Expected Life (from Service Date):");}
    else if(analysisType == blcc.model.Project.MILCONENERGYANALYSIS){
      String tips[] = {
      "Use Cost Phasing feature if initial costs are incurred at Midpoint of Construction or any other date during P/C period.",
      "Enter expected rate of equipment price increase during Study Period.",
      "Enter Cost Adjustment Factor for phased-in initial investment cost.",
      "Use real rates in constant-dollar analysis, nominal rates in current-dollar analysis."};
      investmentTips.setTipsText(tips);
      initialCostLabel.setText("Initial Cost (Base Year Dollars):");
      resaleLabel.setText("Residual Value Factor (% of Initial Cost):");
      financedInput.setVisible(false);
      financedLabel.setVisible(false);
      expectedLifeLabel.setText("Expected Life (from BOD):");}
	 else if(analysisType == blcc.model.Project.OMBANALYSIS){
      String tips[] = {
			"Initial Cost is incurred at the Base Date or phased in during the P/C Period.",
      "Enter expected rate of equipment price increase during Study Period.",
      "Enter Cost Adjustment Factor for phased-in initial investment cost.",
      "Use real rates in constant-dollar analysis, nominal rates in current-dollar analysis."};

			investmentTips.setTipsText(tips);
      initialCostLabel.setText("Initial Cost (Base Year Dollars):");
      resaleLabel.setText("Residual Value Factor (% of Initial Cost):");
      financedInput.setVisible(false);
      financedLabel.setVisible(false);
      expectedLifeLabel.setText("Expected Life (from Service Date):"); }
	 else if(analysisType == blcc.model.Project.MILCONNONENERGYANALYSIS){
			String tips[] = {
      "Use Cost Phasing feature if initial costs are incurred at Midpoint of Construction or any other date during P/C period.",
      "Enter expected rate of equipment price increase during Study Period.",
      "Enter Cost Adjustment Factor for phased-in initial investment cost.",
      "Use real rates in constant-dollar analysis, nominal rates in current-dollar analysis."};

			investmentTips.setTipsText(tips);
      initialCostLabel.setText("Initial Cost (Base Year Dollars):");
      resaleLabel.setText("Residual Value Factor (% of Initial Cost):");
      financedInput.setVisible(false);
      financedLabel.setVisible(false);
      expectedLifeLabel.setText("Expected Life (from BOD):"); }  }


 public Boolean guiValidate(ModelElement element) {
    boolean show = true;

    // workaround; guiValidate() in ProjectTabbed
    component.setResaleValueFactor(resaleInput.getValue());

    try{element.validate(false);}
    catch(blcc.model.ValidationException e){
      // go back to node with validation exception
      TreePath newPath = new TreePath(owner.getTreeModel()
				      .getPathToRoot(owner.getPreviousNode()));
      // set previousNode to null so it won't reset (and revalidate) the node
      owner.setPreviousNode(null);
      owner.getTree().setSelectionPath(newPath);
      JOptionPane.showMessageDialog(owner, e.getMessage(),
            "Error",
				    JOptionPane.ERROR_MESSAGE);
      show = false; }
    return new Boolean(show);
  }
}
