package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import blcc.model.Alternative;
import blcc.model.NonRecurringContractCost;
import blcc.model.ModelElement;
import java.util.Vector;

public class AddNonRecurringContractTabbed extends TabbedPane {
  Chooser typeInput;
  JButton addButton;

  Chooser copyInput;
  JButton copyButton;


  public AddNonRecurringContractTabbed(BLCC5 blcc) {
    super(blcc);
    TabPanel tab = new TabPanel();
    FormPanel addPanel = new FormPanel("Create New Cost");
    String types[] =  {"Implementation Cost", "Financing Procurement Cost"};
    addPanel.addField(Factory.makeLabel("Cost Type:"),
		      typeInput = new Chooser(types));
    tab.addSubPanel(addPanel);
    tab.addSubPanel(Factory.makeButtonSubPanel(
                 addButton = new JButton ("Create Cost")));
    addButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	  BLCCTreeNode node = owner.getCurrentNode();
    NonRecurringContractCost cost = new NonRecurringContractCost();
    cost.setName((String)typeInput.getChoice());
    ((Alternative) node.getParentElement()).addNonRecurringContractCost(cost);
    owner.createNonRecurringContractSubNode(node, cost,true);
	  owner.setNeedsSave(true);
	}});

FormPanel panel2 = new FormPanel("Copy Existing Cost");
 panel2.addField(Factory.makeLabel("Cost to Copy:"),
                copyInput = new Chooser());

 tab.addSubPanel(panel2);
 tab.addSubPanel(Factory.makeButtonSubPanel(copyButton = new JButton("Copy Cost")));

 copyButton.addActionListener(new ActionListener(){
 public void actionPerformed(ActionEvent e) {
  NonRecurringContractCost currentCost= (NonRecurringContractCost)copyInput.getChoice();
  NonRecurringContractCost newCost = currentCost.copyNonRecurringContractCost();
  BLCCTreeNode node = owner.getCurrentNode();
  ((Alternative) node.getParentElement()).addNonRecurringContractCost(newCost);
  owner.createNonRecurringContractSubNode(node, newCost, true);
  owner.setNeedsSave(true); }});

  copyButton.setEnabled(false);


    addTab("Add Non-Annually Recurring Contract-Related Cost", tab); }

 public void getInformation(ModelElement element) {

  Vector costs = owner.getProject().getNonRecurringContractChoices();

  if(costs.size() != 0){
   copyInput.setChoices(costs);
   copyButton.setEnabled(true);}
  else
  {
   String choices[] ={"None"};
   copyInput.setChoices(choices);
   copyButton.setEnabled(false);}
  }



}
