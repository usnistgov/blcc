package blcc.gui;

import blcc.gui.widgets.TabPanel;
import blcc.model.ModelElement;

abstract public class FuelSubtab extends TabPanel {
  abstract public void getInformation (ModelElement element);
  abstract Boolean guiValidate(ModelElement element);
  abstract public void setInformation (ModelElement element);
}
