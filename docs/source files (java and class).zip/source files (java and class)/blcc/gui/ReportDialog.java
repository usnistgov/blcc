package blcc.gui;

import javax.swing.*;
import javax.swing.text.DefaultEditorKit;
import blcc.model.Alternative;
import blcc.model.Project;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import blcc.analysis.Analysis;
import blcc.reports.*;
import java.io.PrintWriter;
import java.io.StringWriter;
import blcc.gui.widgets.PrintableEditorPane;
import java.awt.Cursor;
import java.io.File;
import blcc.gui.widgets.BLCCFileFilter;



public class ReportDialog extends JFrame {
	PrintableEditorPane viewerPane;
  javax.swing.text.html.HTMLDocument doc;
  javax.swing.text.html.HTMLEditorKit ekit;
  String defaultDirectory =  System.getProperty("user.dir") + java.io.File.separatorChar+"projects";

  public ReportDialog(Project project, String type, String fileName) {
    this(project, type, fileName, null, null);}


  public ReportDialog(Project project, String type, String fileName, Alternative alt1, Alternative alt2){
    super(type + " Report");

    JMenuBar menuBar = new JMenuBar();
    setJMenuBar(menuBar);
    JMenu fileMenu = new JMenu("File");
    fileMenu.setMnemonic('f');
    menuBar.add(fileMenu);

    JMenuItem saveItem = new JMenuItem("Save as HTML",
     new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/save.gif"), "Save"));
    saveItem.setMnemonic('s');
    fileMenu.add(saveItem);

    JMenuItem printItem = new JMenuItem("Print",
     new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/print.gif"), "Print"));
    printItem.setMnemonic('p');
    fileMenu.add(printItem);

    fileMenu.addSeparator();
    JMenuItem closeItem = new JMenuItem("Close",
     new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/folderout.gif"), "Close"));
    closeItem.setMnemonic('c');
    fileMenu.add(closeItem);

    saveItem.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
      saveReport();}});

    printItem.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        try{printReport();}
        catch(Exception ex){ex.printStackTrace();}}});

    closeItem.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        ReportDialog.this.dispose();}});

    try {
      Analysis analysis = new Analysis(project);
      analysis.analyze();
      blcc.reports.HTMLFormatter fmt = null;
      StringWriter buffer = new StringWriter();
      fmt = new HTMLFormatter(new PrintWriter(buffer));
      if (type.equals("Detailed LCC"))
        new LCCReport(analysis,fmt, project, fileName).report();
      else if (type.equals("Cash Flow"))
       new CashFlowReport(analysis,fmt,project,fileName).report();
      else if (type.equals("Input")){
        if(project.getAnalysisType()==Project.MILCONECIPANALYSIS){new ECIPInputReport(project, fmt, fileName).report();}
        else {new InputReport(project, fmt, fileName).report();}}
      else if (type.equals("Lowest"))
         new LowestLCCReport(analysis,fmt,project,fileName).report();
      else if (type.equals("Summary"))
         new SummaryReport(analysis,fmt, project, fileName).report();
      else if (type.equals("Comparative Analysis"))
         new CompareReport(analysis,fmt,project,fileName, alt1, alt2).report();
      else if (type.equals("ECIP"))
         new ECIPReport(analysis,fmt,project,fileName).report();


      viewerPane = new PrintableEditorPane();
      viewerPane.setEditable(false);
      viewerPane.setContentType("text/html");
		  setPage(viewerPane,buffer,fmt.getStyleSheet());
			getContentPane().add(new JScrollPane(viewerPane));
			setSize(new java.awt.Dimension(750, 600));
			show();
			viewerPane.setCaretPosition(0);   // workaround for bug; bug causes bottom of document to be displayed when window is displayed
		 } catch(Exception f){
      f.printStackTrace(); }
  }


  void setPage(JEditorPane viewerPane, StringWriter buffer, java.net.URL sheeturl){
    try {
      javax.swing.text.html.StyleSheet sheet=new javax.swing.text.html.StyleSheet();
      sheet.loadRules(new java.io.InputStreamReader(sheeturl.openStream()),sheeturl);
      doc =  new javax.swing.text.html.HTMLDocument(sheet);
			viewerPane.setDocument(doc);
      ekit= (javax.swing.text.html.HTMLEditorKit)viewerPane.getEditorKit();
      ekit.read(new java.io.StringReader(buffer.toString()),doc,0);
		} catch (Throwable t) { t.printStackTrace(); }
  }

  public void printReport() {
   viewerPane.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
   java.awt.print.PrinterJob job = java.awt.print.PrinterJob.getPrinterJob();
   job.setPrintable(viewerPane);
   if (job.printDialog()) {
    try { job.print();}
    catch (Exception ex) {ex.printStackTrace();}
   }
   viewerPane.setCursor(Cursor.getDefaultCursor());}

  public void saveReport(){

    BLCCFileFilter filter;
    JFileChooser chooser = new JFileChooser(defaultDirectory);
    chooser.setMultiSelectionEnabled(false);  // not implemented yet in the current LFs
    chooser.setFileFilter(filter = new BLCCFileFilter(BLCCFileFilter.HTML));
    int returnVal = chooser.showSaveDialog(ReportDialog.this);

    if (returnVal != JFileChooser.APPROVE_OPTION)
          return;

    // first, does it already exist
     java.io.File temp=chooser.getSelectedFile();
    // does it have an extension?
     if(filter.getExtension(temp) == null)
      temp=new java.io.File(temp.toString() + ".html");
     if(temp.exists()){
       int n=replaceFile(temp);
       if(n==JOptionPane.CANCEL_OPTION)
         return;
       if(n==JOptionPane.NO_OPTION){
         saveReport();
         return;}
     }

    File file = chooser.getSelectedFile();
    String fileName = file.toString();  // string so extension can be added if needed
    if (filter.getExtension(file) == null) // user didn't type in ext
       fileName = fileName + ".html";
      try {
         java.io.OutputStreamWriter out = new java.io.OutputStreamWriter(new java.io.FileOutputStream(fileName));  // used writer per Bug ID 4267840
         ekit.write(out, doc, 0, doc.getLength());
         out.close();}
       catch (Exception ex) {
         ex.printStackTrace();}}

  public int replaceFile(java.io.File file){
   Object[] options = {"Yes",
          "No",
          "Cancel"};
    int n =  JOptionPane.showOptionDialog(this,
            "Do you want to replace " + file.toString() + " ?",
             "Replace?",
              JOptionPane.YES_NO_CANCEL_OPTION,
              JOptionPane.QUESTION_MESSAGE,
              null,
              options,
              options[0]);
  return n;}



 }


