package blcc.gui;

import javax.swing.*;
import blcc.gui.widgets.*;
import blcc.model.Alternative;
import blcc.model.WaterUsage;
import blcc.model.ModelElement;
import blcc.model.Escalation;
import blcc.model.SimpleEscalation;
import blcc.model.VaryingEscalation;
import blcc.model.UsageIndex;
import blcc.model.Project;
import java.util.Enumeration;
import blcc.util.Units;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.tree.TreePath;


public class WaterTabbed extends TabbedPane {
  WaterUsage water;
  Chooser unitInput;
  TextField nameInput;
  JButton deleteButton;

  JTable disposalTable;
  JTable usageTable;
  SeasonalAmountModel usageModel;
  SeasonalAmountModel disposalModel;

  VaryingTable disposalEscalationTable;
  VaryingTable usageEscalationTable;
  VaryingTable disposalIndicesTable;
  VaryingTable usageIndicesTable;

  String deleteMessage;

  TipsSubPanel costTips;

  public WaterTabbed(BLCC5 blcc) {
    super(blcc);
    addTab("Water Costs", getWaterTab());
    addTab("Price Escalation Rates", getEscalationTab());
    addTab("Usage Indices", getIndicesTab());
    addTab("Delete", getDeleteTab());
  }

  public void getInformation(ModelElement element) {
    water = (WaterUsage) element;

    nameInput.setValue(water.getName());
    unitInput.setChoice(water.getUnits());
    usageIndicesTable.setValue(water.getUsageIndex());
    disposalIndicesTable.setValue(water.getDisposalIndex());

    // Create usage & disposal varying escalation rates if needed.
    Escalation esc = water.getUsageEscalation();
    if (esc == null){ esc = VaryingEscalation.createVaryingEscalation(0.0);  }
    else if (esc instanceof SimpleEscalation){
      esc=VaryingEscalation.createVaryingEscalation(((SimpleEscalation)esc).getRateWithoutInflation()); }
    water.setUsageEscalation(esc);
    usageEscalationTable.setValue((VaryingEscalation) esc);
    esc = water.getDisposalEscalation();
    if (esc == null){ esc = VaryingEscalation.createVaryingEscalation(0.0);  }
    else if (esc instanceof SimpleEscalation){
      esc=VaryingEscalation.createVaryingEscalation(((SimpleEscalation)esc).getRate()); }
    water.setDisposalEscalation(esc);
    disposalEscalationTable.setValue((VaryingEscalation) esc);

    usageModel.setSummerAmount(water.getSummerYearlyUsage());
    usageModel.setWinterAmount(water.getWinterYearlyUsage());
    usageModel.setSummerCost(water.getSummerUsageUnitCost());
    usageModel.setWinterCost(water.getWinterUsageUnitCost());
    disposalModel.setSummerAmount(water.getSummerYearlyDisposal());
    disposalModel.setWinterAmount(water.getWinterYearlyDisposal());
    disposalModel.setSummerCost(water.getSummerDisposalUnitCost());
    disposalModel.setWinterCost(water.getWinterDisposalUnitCost());


    repaint();  //to refresh combo boxes
  }

  public void setInformation(ModelElement element) {
    WaterUsage water = (WaterUsage) element;
    stopEditting();

    water.setSummerYearlyUsage(usageModel.getSummerAmount());
    water.setWinterYearlyUsage(usageModel.getWinterAmount());
    water.setSummerUsageUnitCost(usageModel.getSummerCost());
    water.setWinterUsageUnitCost(usageModel.getWinterCost());
    water.setSummerYearlyDisposal(disposalModel.getSummerAmount());
    water.setWinterYearlyDisposal(disposalModel.getWinterAmount());
    water.setSummerDisposalUnitCost(disposalModel.getSummerCost());
    water.setWinterDisposalUnitCost(disposalModel.getWinterCost());
    }

  public JPanel getWaterTab() {
    String tips[]={"", "", "", ""};
    TabPanel tab = new TabPanel();
    FormPanel water1 = new FormPanel("General Information");
    water1.addField(Factory.makeLabel("Name:"),
		    nameInput = new TextField());
    nameInput.addChangedListener(owner);
    nameInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  water.setName(nameInput.getValue()); }});
   nameInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {unitInput.requestFocus(); }});

    water1.addField(Factory.makeLabel("Units:"),
		    unitInput = new Chooser(Units.VOLUMES));
    unitInput.addChangedListener(owner);
    unitInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  water.setUnits((Units)unitInput.getChoice()); }});

    tab.addSubPanel(water1);


    usageTable = new JTable();
    usageModel = new SeasonalAmountModel();
    usageTable.setModel(usageModel);
    usageModel.setCellEditors(usageTable);
    usageModel.addChangedListener(owner);
    //usageModel.addChangedListener(new DefaultChangedListener(){
    //public void noteChange(ChangedEvent e){
     //water.setSummerYearlyUsage(usageModel.getSummerAmount());
     //water.setWinterYearlyUsage(usageModel.getWinterAmount());
     //water.setSummerUsageUnitCost(usageModel.getSummerCost());
     //water.setWinterUsageUnitCost(usageModel.getWinterCost()); }});
    tab.addSubPanel(Factory.makeSubPanel("Annual Water Usage",new JScrollPane(usageTable)));
    disposalTable = new JTable();
    disposalModel = new SeasonalAmountModel();
    disposalTable.setModel(disposalModel);
    disposalModel.setCellEditors(disposalTable);
    disposalModel.addChangedListener(owner);
    //disposalModel.addChangedListener(new DefaultChangedListener(){
    //public void noteChange(ChangedEvent e){
    //water.setSummerYearlyDisposal(disposalModel.getSummerAmount());
    //water.setWinterYearlyDisposal(disposalModel.getWinterAmount());
    //water.setSummerDisposalUnitCost(disposalModel.getSummerCost());
    //water.setWinterDisposalUnitCost(disposalModel.getWinterCost()); }});
    tab.addSubPanel(Factory.makeSubPanel("Annual Water Disposal",
					      new JScrollPane(disposalTable)));
    tab.addSpacerPanel();
    tab.addSubPanel(costTips=new TipsSubPanel(tips));
    return tab; }

  public JPanel getEscalationTab() {
    String tips[]={
      "Enter duration and annual average rate (%)."};

    TabPanel tab = new TabPanel();

    usageEscalationTable = new VaryingTable("Usage Cost Escalation","##0.00%");
    tab.addSubPanel(Factory.makeSubPanel("Price Escalation Rates - Water Usage",
					 new JScrollPane(usageEscalationTable)));
    usageEscalationTable.addChangedListener(owner);
    usageEscalationTable.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  owner.setNeedsSave(true); }});

    disposalEscalationTable = new VaryingTable("Disposal Cost Escalation","##0.00%");
    tab.addSubPanel(Factory.makeSubPanel("Price Escalation Rates - Water Disposal",
					 new JScrollPane(disposalEscalationTable)));
    disposalEscalationTable.addChangedListener(owner);
    disposalEscalationTable.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  owner.setNeedsSave(true); }});

    tab.addSpacerPanel();
    tab.addSubPanel(new TipsSubPanel(tips));
    return tab; }

  public JPanel getIndicesTab() {
    String tips[]={
      "Enter duration and percentage of the base annual water "
      + "usage/disposal for the corresponding period.",
      "Base index is 100%."};

    TabPanel tab = new TabPanel();
    usageIndicesTable = new VaryingTable("Usage Index","##0.0%");
    tab.addSubPanel(Factory.makeSubPanel("Usage Indices - Water Usage",
					 new JScrollPane(usageIndicesTable)));
    usageIndicesTable.addChangedListener(owner);
    usageIndicesTable.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  owner.setNeedsSave(true); }});

    disposalIndicesTable = new VaryingTable("Disposal Index","##0.0%");
    tab.addSubPanel(Factory.makeSubPanel("Usage Indices - Water Disposal",
					 new JScrollPane(disposalIndicesTable)));
    disposalIndicesTable.addChangedListener(owner);
    disposalIndicesTable.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
	  owner.setNeedsSave(true); }});

    tab.addSpacerPanel();
    tab.addSubPanel(new TipsSubPanel(tips));
    return tab; }

  public JPanel getDeleteTab() {
    TabPanel tab = new TabPanel();
    tab.addSubPanel(Factory.makeButtonSubPanel(
        deleteButton = new JButton ("")));
    deleteButton.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e) {
    if (owner.confirmDelete(deleteMessage) == JOptionPane.YES_OPTION){
	    BLCCTreeNode selectedNode = owner.getCurrentNode();
	    BLCCTreeNode parentNode = (BLCCTreeNode) selectedNode.getParent();
	    Alternative alt = (Alternative)parentNode.getElement();
	    alt.removeWaterUsage((WaterUsage)selectedNode.getElement());
	    owner.getTreeModel().removeNodeFromParent(selectedNode);
	    owner.setPreviousNode(null);
	    // find a path from root to the node that should be selected
	    TreePath newPath = new TreePath(owner.getTreeModel().getPathToRoot(parentNode));
	    // select the path
	    owner.getTree().setSelectionPath(newPath);
	    owner.setNeedsSave(true);
	  }}});
    return tab; }

  public void stopEditting(){
  if (usageTable.isEditing())
      usageTable.editingStopped(new javax.swing.event.ChangeEvent(usageTable));
    if (disposalTable.isEditing())
      disposalTable.editingStopped(new javax.swing.event.ChangeEvent(disposalTable));

    if (usageEscalationTable.isEditing())
      usageEscalationTable.editingStopped(new javax.swing.event.ChangeEvent(usageEscalationTable));
    if (disposalEscalationTable.isEditing())
      disposalEscalationTable.editingStopped(new javax.swing.event.ChangeEvent(disposalEscalationTable));

    if (usageIndicesTable.isEditing())
      usageIndicesTable.editingStopped(new javax.swing.event.ChangeEvent(usageIndicesTable));
    if (disposalIndicesTable.isEditing())
      disposalIndicesTable.editingStopped(new javax.swing.event.ChangeEvent(disposalIndicesTable));}



  public void setAnalysisSpecific(int analysisType) {
    if(analysisType==Project.MILCONECIPANALYSIS){
      String tips[]={"Enter savings in water usage and disposal for alternative relative to base case.",
                     "Enter all dollar amounts in base-year dollars.",
									   "Constant-dollar amounts, real discount rate, and escalation rates exclude general inflation.",
                     "Use Usage Indices to specify variable water usage and disposal."};
      costTips.setTipsText(tips);
      deleteButton.setText("Delete This Savings/Cost");
      deleteMessage="savings/cost";}
    else{
      String tips[]= {"Enter all dollar amounts in base-year dollars.",
                      "Use real rates of price escalation in constant-dollar analysis, "+
                      "nominal rates in current-dollar analysis.",
                      "Use Usage Indices to specify variable water usage and disposal."};
       costTips.setTipsText(tips);
       deleteButton.setText("Delete This Cost");
       deleteMessage="cost";}
  }

}


