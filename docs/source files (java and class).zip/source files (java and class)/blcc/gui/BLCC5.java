package blcc.gui;

import javax.swing.*;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.CardLayout;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.event.*;
import blcc.gui.widgets.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import blcc.model.*;
import blcc.parser.*;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.util.Enumeration;
import blcc.reports.*;
import java.awt.Cursor;
import blcc.util.Date;
import javax.swing.UIDefaults;
import blcc.util.FuelType;
import java.util.Vector;
import blcc.gui.AlternativeTabbed;

/* -----------------5/26/2004 9:09AM-----------------
 *  Adding a new module     Based on the addition of MILCON Non-Energy Module May 2004
 *   Laura Schultz
 *
 * In model.project.java:  Add new Analysis Type Constant
 * 												Add name to analysisNames
 * In BLCC5.java:  Add new action for menu.
 * 								 Define action item and add to menu.
 *
 * --------------------------------------------------*/



public class BLCC5 extends JFrame  implements ChangedListener {
  JDialog about;
//  JDialog credits;   // 5-18-07 asr removed credits (commented out code incase we want it back)
  private Project project;
  String fileName = null;

  Help help = null;

  JSplitPane splitPane;

  BLCCTreeNode previousNode=null;

  BLCCTreeNode projectNode;
  DefaultTreeModel treeModel;
  JTree tree;

  JPanel mainPanel;
  CardLayout mainCardLayout;

  String defaultDirectory =  System.getProperty("user.dir") + java.io.File.separatorChar+"projects";

  public int analysisType = Project.AGENCYFUNDEDANALYSIS;

  CardLayout rightLayout;
  JPanel rightPanel;

  boolean needsSave=false;

 Action actionNewAgency;
 Action actionNewFinanced;
 Action actionNewMilconEnergy;
 Action actionNewMilconECIP;
 Action actionNewMilconNonEnergy;
 Action actionNewOMB;
 Action actionOpen;
 Action actionClose;
 Action actionSave;
 Action actionSaveAs;
 Action actionExit;
 Action actionDetailed;
 Action actionCashFlow;
 Action actionInput;
 Action actionLowest;
 Action actionCompare;
 Action actionECIP;
 Action actionSummary;
 Action actionHelp;
 Action actionExpandAll;
 Action actionCollapseAll;

 JButton saveButton;
 JButton closeButton;
 JButton expandAllButton;
 JButton collapseAllButton;

 JDialog box;
 Chooser base;
 Chooser alt;



 Cursor normalCursor = getCursor();
 Cursor waitCursor = new Cursor(Cursor.WAIT_CURSOR);

  TabbedPane tabcache[]=new TabbedPane[BLCCTreeNode.MAXTYPES];
  String tabclass[]=new String[BLCCTreeNode.MAXTYPES];

  public BLCC5(String arg1) {
    super(arg1);

    setCursor(waitCursor);   // cursor set back to normal in createMenuBar()

    splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, false);

    rightLayout = new CardLayout();
    rightPanel = new JPanel(rightLayout);

    //tree
    projectNode = new BLCCTreeNode(BLCCTreeNode.PROJECT_NODE,null);
    treeModel = new DefaultTreeModel(projectNode);
    treeModel.setAsksAllowsChildren(true);

    tree = new JTree(treeModel);

    tree.setSelectionRow(0);
    tree.putClientProperty("JTree.lineStyle", "Angled");
    tree.getSelectionModel().setSelectionMode(
			     TreeSelectionModel.SINGLE_TREE_SELECTION);

    tree.addTreeSelectionListener(new TreeSelectionListener(){
      public void valueChanged(TreeSelectionEvent e){
	doTreeEvent(true); }
    });

    splitPane.setLeftComponent(new JScrollPane(tree));
    splitPane.setRightComponent(rightPanel);
    splitPane.setDividerLocation(200);

    mainPanel = new JPanel();
    mainCardLayout = new CardLayout();
    mainPanel.setLayout(mainCardLayout);

    // set up blank panel  (shown when no project is open)
    JPanel blank = new JPanel();
    blank.setLayout(new java.awt.BorderLayout());
    ImageIcon icon = new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/blcc5.jpg"), "BLCC5");
    blank.add("Center", new JLabel(icon));
    blank.setBackground(Factory.makeBlueColor());
    mainPanel.add("blank", blank);
    mainPanel.add("split", splitPane);
    mainCardLayout.show(mainPanel, "blank");

    getContentPane().add("Center", mainPanel);

    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e) {
	setCursor(waitCursor);
  if (closeEvent("Would you like to save this project before you exit BLCC5?"))
	  System.exit(0);
	setCursor(normalCursor);
      }
    });
    createMenuBar();

    tabclass[BLCCTreeNode.PROJECT_NODE    ]="blcc.gui.ProjectTabbed";
    tabclass[BLCCTreeNode.ALTERNATIVE_NODE]="blcc.gui.AlternativeTabbed";
    tabclass[BLCCTreeNode.COMPONENT_NODE  ]="blcc.gui.ComponentTabbed";
    tabclass[BLCCTreeNode.ADD_NARC_NODE  ] ="blcc.gui.AddNonRecurringTabbed";
    tabclass[BLCCTreeNode.NARC_NODE       ]="blcc.gui.NonRecurringTabbed";
    tabclass[BLCCTreeNode.ADD_REPLACEMENT_NODE]="blcc.gui.AddReplacementTabbed";
    tabclass[BLCCTreeNode.REPLACEMENT_NODE]="blcc.gui.ReplacementTabbed";
    tabclass[BLCCTreeNode.ADD_ENERGY_NODE ]="blcc.gui.AddEnergyTabbed";
    tabclass[BLCCTreeNode.ENERGY_NODE     ]="blcc.gui.EnergyTabbed";
    tabclass[BLCCTreeNode.WATER_NODE      ]="blcc.gui.WaterTabbed";
    tabclass[BLCCTreeNode.ADD_WATER_NODE  ]="blcc.gui.AddWaterTabbed";
    tabclass[BLCCTreeNode.ADD_ARC_CONTRACT_NODE]="blcc.gui.AddRecurringContractTabbed";
    tabclass[BLCCTreeNode.ARC_CONTRACT_NODE   ]="blcc.gui.RecurringContractTabbed";
    tabclass[BLCCTreeNode.ADD_NARC_CONTRACT_NODE]="blcc.gui.AddNonRecurringContractTabbed";
    tabclass[BLCCTreeNode.NARC_CONTRACT_NODE   ]="blcc.gui.NonRecurringContractTabbed";
    tabclass[BLCCTreeNode.ARC_NODE         ]="blcc.gui.RecurringTabbed";
    tabclass[BLCCTreeNode.ADD_ARC_NODE     ]="blcc.gui.AddRecurringTabbed";
    tabclass[BLCCTreeNode.INVESTMENT_NODE ]="blcc.gui.InvestmentTabbed";
    tabclass[BLCCTreeNode.ROUTINE_ARC_NODE ]="blcc.gui.RecurringTabbed";
    tabclass[BLCCTreeNode.ADD_ROUTINE_ARC_NODE ]="blcc.gui.AddRecurringTabbed";
    tabclass[BLCCTreeNode.ROUTINE_NARC_NODE ]="blcc.gui.NonRecurringTabbed";
    tabclass[BLCCTreeNode.ADD_ROUTINE_NARC_NODE ]="blcc.gui.AddNonRecurringTabbed";
    tabclass[BLCCTreeNode.MAJOR_REPAIR_REPLACEMENT_NODE ]="blcc.gui.ReplacementTabbed";
    tabclass[BLCCTreeNode.ADD_MAJOR_REPAIR_REPLACEMENT_NODE ]="blcc.gui.AddReplacementTabbed";
    tabclass[BLCCTreeNode.ALTERNATIVE_SAVINGS_NODE] = "blcc.gui.AlternativeTabbed";
    tabclass[BLCCTreeNode.COMPONENT_SAVINGS_NODE] = "blcc.gui.ComponentTabbed";
    tabclass[BLCCTreeNode.ADD_ARC_SAVINGS_NODE]="blcc.gui.AddRecurringTabbed";
    tabclass[BLCCTreeNode.ARC_SAVINGS_NODE]="blcc.gui.RecurringTabbed";
    tabclass[BLCCTreeNode.ADD_NARC_SAVINGS_NODE]="blcc.gui.AddNonRecurringTabbed";
    tabclass[BLCCTreeNode.NARC_SAVINGS_NODE]="blcc.gui.NonRecurringTabbed";
    tabclass[BLCCTreeNode.ADD_ENERGY_SAVINGS_NODE]="blcc.gui.AddEnergyTabbed";
    tabclass[BLCCTreeNode.ENERGY_SAVINGS_NODE]="blcc.gui.EnergyTabbed";
    tabclass[BLCCTreeNode.ADD_WATER_SAVINGS_NODE]="blcc.gui.AddWaterTabbed";
    tabclass[BLCCTreeNode.WATER_SAVINGS_NODE]="blcc.gui.WaterTabbed";
    tabclass[BLCCTreeNode.ECIP_INVESTMENT_NODE]="blcc.gui.ECIPInvestmentTabbed";
    }



  public boolean closeEvent(String message) {
    boolean closeOrExit = true;

    if (splitPane.isVisible()&& needsSave == true) {
      Object[] options = {"Yes",
			  "No",
			  "Cancel"};
      int n =  JOptionPane.showOptionDialog(this,
					    message,
					    "Save Project?",
					    JOptionPane.YES_NO_CANCEL_OPTION,
					    JOptionPane.QUESTION_MESSAGE,
					    null,
					    options,
					    options[0]);
      if (n == JOptionPane.YES_OPTION) {
	closeOrExit = true;
	int j = saveProject();
	if (j == JFileChooser.CANCEL_OPTION)  //cancelled hit on file choose, don't exit/close project
	  closeOrExit = false;
      }
      else if (n == JOptionPane.CANCEL_OPTION)
	closeOrExit = false;
    }
    return closeOrExit; }

  public int confirmDelete(String name) {
    Object[] options = {"Yes",
			"No"};
    int n =  JOptionPane.showOptionDialog(this,
            "Are you sure you want to delete this " + name + "?",
            "Delete "+name+"?",
					  JOptionPane.YES_NO_OPTION,
					  JOptionPane.QUESTION_MESSAGE,
					  null,
					  options,
					  options[0]);
    return n; }


  public void createMenuBar() {
  // create Actions
 actionNewAgency = new AbstractAction(Project.analysisNames[Project.AGENCYFUNDEDANALYSIS],
        new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/new.gif"), "New")){
   public void actionPerformed(ActionEvent e) {
     setCursor(waitCursor);
     if (closeEvent("Would you like to save your project before starting a new one?")){
      analysisType = Project.AGENCYFUNDEDANALYSIS;
      closeOpenReports();
      createNewProject(analysisType);
      }
     setCursor(normalCursor);
   }};

 actionNewFinanced = new AbstractAction(Project.analysisNames[Project.FINANCEDANALYSIS],
   new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/new.gif"), "New")){
   public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
	  if (closeEvent("Would you like to save your project before starting a new one?")){
      analysisType = Project.FINANCEDANALYSIS;
      closeOpenReports();
      createNewProject(analysisType);}
	  setCursor(normalCursor);
   }};


 actionNewMilconEnergy = new AbstractAction(Project.analysisNames[Project.MILCONENERGYANALYSIS],
   new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/new.gif"), "New")){
   public void actionPerformed(ActionEvent e) {
    setCursor(waitCursor);
    if (closeEvent("Would you like to save your project before starting a new one?")){
      analysisType= Project.MILCONENERGYANALYSIS;
      closeOpenReports();
      createNewProject(analysisType);}
    setCursor(normalCursor);
   }};

 actionNewMilconECIP = new AbstractAction(Project.analysisNames[Project.MILCONECIPANALYSIS],
   new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/new.gif"), "New")){
   public void actionPerformed(ActionEvent e) {
    setCursor(waitCursor);
    if (closeEvent("Would you like to save your project before starting a new one?")){
      analysisType= Project.MILCONECIPANALYSIS;
      closeOpenReports();
      createNewProject(analysisType);}
    setCursor(normalCursor);
   }};


	 //LIS 5.3-05 addition
	 actionNewMilconNonEnergy = new AbstractAction(Project.analysisNames[Project.MILCONNONENERGYANALYSIS],
   new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/new.gif"), "New")){
   public void actionPerformed(ActionEvent e) {
    setCursor(waitCursor);
    if (closeEvent("Would you like to save your project before starting a new one?")){
      analysisType= Project.MILCONNONENERGYANALYSIS;
      closeOpenReports();
      createNewProject(analysisType);}
    setCursor(normalCursor);
   }};



		//LIS 5.2-04 additionj
 actionNewOMB = new AbstractAction(Project.analysisNames[Project.OMBANALYSIS],
        new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/new.gif"), "New")){
   public void actionPerformed(ActionEvent e) {
     setCursor(waitCursor);
     if (closeEvent("Would you like to save your project before starting a new one?")){
      analysisType = Project.OMBANALYSIS;
      closeOpenReports();
      createNewProject(analysisType);
      }
     setCursor(normalCursor);
   }};


 actionOpen = new AbstractAction("Open",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/open.gif"), "Open")) {
   public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
	  if (closeEvent("Would you like to save your project before opening a new one?")){
     // disable actions now, if valid project is opened, they will be enabled
     actionSave.setEnabled(false);
     saveButton.setEnabled(false);
     actionSaveAs.setEnabled(false);
     actionClose.setEnabled(false);
     closeButton.setEnabled(false);
     actionDetailed.setEnabled(false);
     actionCashFlow.setEnabled(false);
     actionInput.setEnabled(false);
     actionSummary.setEnabled(false);
     actionCompare.setEnabled(false);
     actionECIP.setEnabled(false);
     actionExpandAll.setEnabled(false);
     expandAllButton.setEnabled(false);
     actionCollapseAll.setEnabled(false);
     collapseAllButton.setEnabled(false);
     actionLowest.setEnabled(false);
     closeOpenReports();
     mainCardLayout.show(mainPanel, "blank");
     setTitle("BLCC5");
     createOpenProject();
     setNeedsSave(false); }
    setCursor(normalCursor);
    }};

 actionClose = new AbstractAction("Close",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/folderout.gif"), "Close")) {
   public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
	  if (closeEvent("Would you like to save this project before closing it?")){
	    mainCardLayout.show(mainPanel, "blank");
      actionSave.setEnabled(false);
      saveButton.setEnabled(false);
      actionSaveAs.setEnabled(false);
      actionClose.setEnabled(false);
      closeButton.setEnabled(false);
      actionDetailed.setEnabled(false);
      actionCashFlow.setEnabled(false);
      actionInput.setEnabled(false);
      actionSummary.setEnabled(false);
      actionCompare.setEnabled(false);
      actionECIP.setEnabled(false);
      actionLowest.setEnabled(false);
     actionExpandAll.setEnabled(false);
     expandAllButton.setEnabled(false);
     actionCollapseAll.setEnabled(false);
     collapseAllButton.setEnabled(false);
    closeOpenReports();
    setTitle("BLCC5");}
    setCursor(normalCursor);
    }};

 actionSave = new AbstractAction("Save",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/save.gif"), "Save")) {
   public void actionPerformed(ActionEvent e) {
     setCursor(waitCursor);
     saveProject();
     setCursor(normalCursor);
    }};

 actionSaveAs = new AbstractAction("Save As"){
   public void actionPerformed(ActionEvent e) {
     setCursor(waitCursor);
	  fileName = null;
	  saveProject();
    setCursor(normalCursor);
    }};

 actionExit = new AbstractAction("Exit",
   new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/exit.gif"), "Exit")) {
    public void actionPerformed(ActionEvent e) {
     setCursor(waitCursor);
      if (closeEvent("Would you like to save this project before you exit BLCC5?"))
       System.exit(0);
      setCursor(normalCursor);
     }};

 actionDetailed = new AbstractAction("Detailed LCC",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/sheet.gif"), "LCC Report")) {
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
    ReportDialog report;
	  doTreeEvent(false);
	  if (reportValidate())  // there were no errors in validate
      report = new ReportDialog(getProject(), "Detailed LCC", fileName);
	  setCursor(normalCursor);
     }};

 actionCashFlow = new AbstractAction("Cash Flow",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/sheet.gif"), "Cash Flow Report")) {
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
	  ReportDialog report;
	  doTreeEvent(false);
	  if (reportValidate())  // there were no errors in validate
      report = new ReportDialog(getProject(), "Cash Flow", fileName);
	  setCursor(normalCursor);
     }};

 actionInput = new AbstractAction("Input",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/sheet.gif"), "Input Report")) {
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
	  ReportDialog report;
	  doTreeEvent(false);
    if (reportValidate())  // there were no errors in validate
     report = new ReportDialog(getProject(), "Input", fileName);
    setCursor(normalCursor);
     }};

 actionSummary = new AbstractAction("Summary LCC",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/sheet.gif"), "Summary Report")) {
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
	  ReportDialog report;
	  doTreeEvent(false);
		if (reportValidate())
		  report = new ReportDialog(getProject(), "Summary", fileName);
    setCursor(normalCursor);}};

 actionCompare = new AbstractAction("Comparative Analysis",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/sheet.gif"), "Comparative Analysis Report")) {
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
    Vector alts = getProject().getAlternativeChoices();
    if(alts.size() >= 2){
      doTreeEvent(false);
		 	if (reportValidate())
       compareReport(alts);
		}
    else
      JOptionPane.showMessageDialog(BLCC5.this,
        "You must defined 2 or more alternatives before generating this report.",
         "Error",
         JOptionPane.ERROR_MESSAGE);
    setCursor(normalCursor);}};

    actionECIP = new AbstractAction("ECIP",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/sheet.gif"), "ECIP Report")) {
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
	  ReportDialog report;
	  doTreeEvent(false);
		if (reportValidate())
      report = new ReportDialog(getProject(), "ECIP", fileName);
    setCursor(normalCursor);}};


   actionLowest = new AbstractAction("Lowest LCC",
  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/sheet.gif"), "Lowest LCC Report")) {
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
    if(getProject().getAlternativeChoices().size() >= 2){
      ReportDialog report;
      doTreeEvent(false);
			if (reportValidate())
       report = new ReportDialog(getProject(), "Lowest", fileName);
		}
    else
     JOptionPane.showMessageDialog(BLCC5.this,
        "You must defined 2 or more alternatives before generating this report.",
         "Error",
         JOptionPane.ERROR_MESSAGE);
    setCursor(normalCursor);}};

 actionHelp = new AbstractAction("BLCC5 Help",
   new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/help.gif"), "Help")){
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
	  if (help == null)
      help = new Help("BLCC5 Help");
	  help.setSize(new java.awt.Dimension(750, 525));
	  help.show();
	  setCursor(normalCursor);
     }};

   Action actionAbout = new AbstractAction("About BLCC5"){
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
    about = getAbout();
    about.pack();
    about.show();
	  setCursor(normalCursor);
     }};

   /*Action actionCredits = new AbstractAction("Credits"){
    public void actionPerformed(ActionEvent e) {
	  setCursor(waitCursor);
    credits = getCredits();
    credits.show();
	  setCursor(normalCursor);
     }};*/


    actionCollapseAll = new AbstractAction("Collapse All",
      new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/up.gif"), "Collapse All")){
    public void actionPerformed(ActionEvent e) {
     collapseAllNodes();
     }};

    actionExpandAll = new AbstractAction("Expand All",
      new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/down.gif"), "Expand All")){
    public void actionPerformed(ActionEvent e) {
     expandAllNodes();
     }};

 // main menu
 JMenuBar menuBar = new JMenuBar();
 setJMenuBar(menuBar);

 // file menu
 JMenu fileMenu = menuBar.add(new JMenu("File"));
 fileMenu.setMnemonic('f');

 JMenu newMenu = new JMenu("New");
 JMenuItem noFinancingMenuItem = newMenu.add(actionNewAgency);
 noFinancingMenuItem.setMnemonic('f');
 JMenuItem financingMenuItem = newMenu.add(actionNewFinanced);
 financingMenuItem.setMnemonic('e');
 JMenuItem OMBMenuItem = newMenu.add(actionNewOMB);
 OMBMenuItem.setMnemonic('b');
 fileMenu.add(newMenu);
 JMenuItem milconEnergyMenuItem = newMenu.add(actionNewMilconEnergy);
 milconEnergyMenuItem.setMnemonic('m');
 JMenuItem milconECIPMenuItem = newMenu.add(actionNewMilconECIP);
 milconECIPMenuItem.setMnemonic('i');
 JMenuItem milconNonEnergyMenuItem = newMenu.add(actionNewMilconNonEnergy);
 milconNonEnergyMenuItem.setMnemonic('r');


 JMenuItem openMenuItem = fileMenu.add(actionOpen);
 openMenuItem.setMnemonic('o');

 JMenuItem closeMenuItem = fileMenu.add(actionClose);
 closeMenuItem.setMnemonic('c');
 actionClose.setEnabled(false);

 fileMenu.addSeparator();

 JMenuItem saveMenuItem = fileMenu.add(actionSave);
 saveMenuItem.setMnemonic('s');
 actionSave.setEnabled(false);

 JMenuItem saveAsMenuItem = fileMenu.add(actionSaveAs);
 saveAsMenuItem.setMnemonic('a');
 actionSaveAs.setEnabled(false);

 fileMenu.addSeparator();

 JMenuItem exitMenuItem = fileMenu.add(actionExit);
 exitMenuItem.setMnemonic('e');

 // report menu
 JMenu reportsMenu = menuBar.add(new JMenu("Reports"));
 reportsMenu.setMnemonic(KeyEvent.VK_R);

 JMenuItem inputMenuItem = reportsMenu.add(actionInput);
 inputMenuItem.setMnemonic('i');
 actionInput.setEnabled(false);

 JMenuItem lccMenuItem = reportsMenu.add(actionDetailed);
 lccMenuItem.setMnemonic('d');
 actionDetailed.setEnabled(false);

 JMenuItem flowMenuItem = reportsMenu.add(actionCashFlow);
 flowMenuItem.setMnemonic('c');
 actionCashFlow.setEnabled(false);

 JMenuItem summaryMenuItem = reportsMenu.add(actionSummary);
 summaryMenuItem.setMnemonic('s');
 actionSummary.setEnabled(false);

 JMenuItem lowestMenuItem = reportsMenu.add(actionLowest);
 lowestMenuItem.setMnemonic('l');
 actionLowest.setEnabled(false);

 JMenuItem compareMenuItem = reportsMenu.add(actionCompare);
 compareMenuItem.setMnemonic('o');
 actionCompare.setEnabled(false);

 JMenuItem ecipMenuItem = reportsMenu.add(actionECIP);
 ecipMenuItem.setMnemonic('e');
 actionECIP.setEnabled(false);


 //when reports are ready, need to finish actions and add to ReportDialog
 actionLowest.setEnabled(false);



 // tree menu

 JMenu treeMenu = menuBar.add(new JMenu("Tree"));
 treeMenu.setMnemonic('t');
 JMenuItem expandAllMenuItem = treeMenu.add(actionExpandAll);
 expandAllMenuItem.setMnemonic('e');
 actionExpandAll.setEnabled(false);
 JMenuItem collapseAllMenuItem = treeMenu.add(actionCollapseAll);
 collapseAllMenuItem.setMnemonic('c');
 actionCollapseAll.setEnabled(false);



 // help menu
 JMenu helpMenu = menuBar.add(new JMenu("Help"));
 helpMenu.setMnemonic('h');

 JMenuItem blccHelpMenuItem = helpMenu.add(actionHelp);
 blccHelpMenuItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_F1, 0));
 blccHelpMenuItem.setMnemonic('b');
 helpMenu.addSeparator();
 JMenuItem aboutMenuItem = helpMenu.add(actionAbout);
 aboutMenuItem.setMnemonic('a');
 /*JMenuItem creditsMenuItem = helpMenu.add(actionCredits);
 creditsMenuItem.setMnemonic('c');*/


//toolbar
 JToolBar toolBar = new JToolBar();
 toolBar.add(Factory.makeSmallButton(actionOpen));
 toolBar.addSeparator();
 toolBar.add(saveButton=Factory.makeSmallButton(actionSave));
 saveButton.setEnabled(false);
 toolBar.add(closeButton=Factory.makeSmallButton(actionClose));
 closeButton.setEnabled(false);
 toolBar.addSeparator();
 toolBar.add(expandAllButton=Factory.makeSmallButton(actionExpandAll));
 expandAllButton.setEnabled(false);
 toolBar.add(collapseAllButton=Factory.makeSmallButton(actionCollapseAll));
 collapseAllButton.setEnabled(false);
 toolBar.addSeparator();
 toolBar.add(Factory.makeSmallButton(actionExit));
 toolBar.addSeparator();
 toolBar.add(Factory.makeSmallButton(actionHelp));
 getContentPane().add(toolBar, java.awt.BorderLayout.NORTH);




setCursor(normalCursor);  // set to waitCursor in constructor
  }

  public void createNewProject(int analysis) {
    project = new Project();
    projectNode.setElement(project);

    projectNode.removeAllChildren();
    projectNode.setUserObject("Project:  ");
    previousNode = null;
    treeModel.reload();
    fileName = null;

    setTitle(Project.analysisNames[analysis]);
    project.setAnalysisType(analysis);
		project.setDiscountRate();

    // set current/constant & end-year/mid-year in project
    if (analysis == Project.FINANCEDANALYSIS)
     project.setDollarMethod(Project.CURRENTDOLLARMETHOD);

    else //  Agency-Funded or Milcon Energy
     project.setDollarMethod(Project.CONSTANTDOLLARMETHOD);

    if (analysis == Project.MILCONENERGYANALYSIS || analysis==Project.MILCONECIPANALYSIS|| analysis==Project.MILCONNONENERGYANALYSIS)
     project.setDiscountingMethod(Project.MIDYEARDISCOUNTING);

    reset();

    if(analysis==Project.MILCONECIPANALYSIS){  // if MILCON ECIP, there is only 1 alt
     Alternative alternative = new Alternative();
     project.addAlternative(alternative);
     CapitalComponent component = new CapitalComponent();
     alternative.addCapitalComponent(component);
     createAlternativeNode(alternative, false, false);}

    setNeedsSave(true);
  }

    public void createOpenProject() {
    Alternative alternative;
    BLCCFileFilter filter;
    JFileChooser chooser = new JFileChooser(defaultDirectory);
    chooser.setMultiSelectionEnabled(false);  // not implemented yet in the current LFs
    chooser.setFileFilter(filter=new BLCCFileFilter(BLCCFileFilter.XML));
    int returnVal = chooser.showOpenDialog(BLCC5.this);

    if (returnVal == JFileChooser.APPROVE_OPTION){
      fileName = chooser.getSelectedFile().toString();
    if (filter.getExtension(chooser.getSelectedFile()) == null) // user didn't type in ext
       fileName = fileName + ".xml";
      try {
      project = (Project) new XMLParser(fileName).parse();
      projectNode.setElement(project);
      } catch(Exception e){
         e.printStackTrace(System.out);  // comment this out
         JOptionPane.showMessageDialog(this,
           "There's been an error opening " + fileName + ".  Please try again.",
           "Error",
            JOptionPane.ERROR_MESSAGE); return; }
      projectNode.removeAllChildren();
      projectNode.setUserObject("Project:  " + project.getName());
      previousNode = null;
      treeModel.reload();

    analysisType = project.getAnalysisType();
    setTitle(Project.analysisNames[analysisType] + " - " + fileName);
    reset();

      for (java.util.Enumeration enum1 = project.enumerateAlternatives();
	   enum1.hasMoreElements();) { // go through alts
	alternative = (Alternative)enum1.nextElement();
  createAlternativeNode(alternative,false, true);
      }
    }
  }

  public void setNeedsSave(boolean needsave){
    if(needsSave != needsave){
      needsSave = needsave;
      actionSave.setEnabled(needsSave);
      saveButton.setEnabled(needsSave); }}

  // Implementation of ChangedListener
  public boolean allowChange(ChangedEvent e){ return true; }
  public void noteChange(ChangedEvent e){
     setNeedsSave(true); }

  public void doTreeEvent(boolean validate) {
    int altIndex;
    BLCCTreeNode node = (BLCCTreeNode) tree.getLastSelectedPathComponent();
    if (node == null)
      return;
    //set information on previous node
    if (previousNode != null){
      TabbedPane tabbed = tabcache[previousNode.getNodeType()];
      try {
	tabbed.setInformation(previousNode.getElement());
	if (validate)
	  if (! tabbed.guiValidate(previousNode.getElement()).booleanValue())
	    return; // don't setInformation --> just return
      } catch(Exception e){
	e.printStackTrace(System.out); }
      previousNode.resetName();
      treeModel.nodeChanged(previousNode);
    } // end of if previous not null

    previousNode = node;
    //get information on new node
    TabbedPane tabbed=tabcache[node.getNodeType()];
    if (tabbed == null){
      String classname = tabclass[node.getNodeType()];
      try{
	Class parms[]={blcc.gui.BLCC5.class};
	Object args[]={this};
	tabbed = (TabbedPane) Class.forName(classname)
	  .getConstructor(parms).newInstance(args);
      } catch(Exception e){
	System.err.println("Failed to create Tabbed Pane for "+classname);
	e.printStackTrace(); }
      rightPanel.add(tabbed, tabbed.getClass().getName());
      tabcache[node.getNodeType()] = tabbed;
    }
    tabbed.setAnalysisSpecific(analysisType);
    tabbed.setSelectedIndex(0);
    try {
      tabbed.getInformation(node.getElement());
    } catch(Exception e){
      e.printStackTrace(System.out); }
    rightLayout.show(rightPanel, tabbed.getClass().getName());
  }

  public JDialog getAbout() {
    if (about == null){
      about = new JDialog(this, "About BLCC5");
      JLabel iconLabel = new JLabel(new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/smallblcc5.jpg"), "BLCC5"));
      JPanel p = new JPanel();
      Border b1 = new BevelBorder(BevelBorder.LOWERED);
      Border b2 = new EmptyBorder(5, 5, 5, 5);
      iconLabel.setBorder(new CompoundBorder(b1, b2));
      p.add(iconLabel);
      about.getContentPane().add(p, BorderLayout.WEST);
      String message = "BLCC " + blcc.util.Defaults.getStringItem("version") + "\n"+
      "Building Life-Cycle Cost";
      JTextArea txt = new JTextArea(message);
      txt.setBorder(new EmptyBorder(5, 10, 5, 10));
      txt.setEditable(false);
      txt.setBackground(getBackground());
      p = new JPanel();
      p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
      p.add(txt);
      message = "Applied Economics Office\n"+  // asr 10-23-11 changed to reflect new office and lab names
                "Engineering Laboratory\n"+
                "National Institute of Standards and Technology\n\n"+
                "April " + blcc.util.Defaults.getStringItem("default year");
      txt = new JTextArea(message);
      txt.setBorder(new EmptyBorder(5, 10, 5, 10));
      txt.setEditable(false);
      txt.setBackground(getBackground());
      p.add(txt);
      about.getContentPane().add(p, BorderLayout.CENTER);
      JButton btOK = new JButton("OK");
      ActionListener lst = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          about.setVisible(false);}};

      btOK.addActionListener(lst);
      p = new JPanel();
      p.add(btOK);
      about.getContentPane().add(p, BorderLayout.SOUTH);
      about.setResizable(false); }

    return about; }

 /* public JDialog getCredits() {
    if (credits == null){
      credits = new JDialog(this, "Credits");
      JEditorPane text = new JEditorPane();
      text.setEditable(false);
      try{
        text.setPage(BLCC5.class.getResource("/blcc/resources/credits.html"));}
      catch(Exception e){System.out.println("Error loading credits");}
      credits.getContentPane().add(new JScrollPane(text), BorderLayout.CENTER);
      JButton btOK = new JButton("OK");
      ActionListener lst = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          credits.setVisible(false);}};

      btOK.addActionListener(lst);
      JPanel p = new JPanel();
      p.add(btOK);
      credits.getContentPane().add(p, BorderLayout.SOUTH);
      credits.setSize(new Dimension (500, 300));}

    return credits; }  */


  public BLCCTreeNode getPreviousNode() {
    return previousNode; }

  public Project getProject() {
    return project; }

  public JTree getTree() {
    return tree; }

  public BLCCTreeNode getCurrentNode(){
    return (BLCCTreeNode) getTree().getSelectionPath().getLastPathComponent(); }

  public void openNode(BLCCTreeNode node, boolean select){
    TreePath path = new TreePath(node.getPath());
    tree.expandPath(path);
    if(select)
      tree.setSelectionPath(path);
  }

  public void closeNode(BLCCTreeNode node){
    tree.collapsePath(new TreePath(node.getPath()));}

  public void collapseAllNodes() {
   for (int i=tree.getRowCount(); i>=0; --i)
     tree.collapseRow(i);
    tree.setSelectionRow(0);
		tree.expandRow(0);}                 // per Linde, expand Project Node to show alternatives

  public void expandAllNodes() {
    for (int i=0; i<tree.getRowCount(); i++)
       tree.expandRow(i);}

  /* This isn't quite the right thing, but always used this way.*/
  public void addChildNode(BLCCTreeNode parent, BLCCTreeNode child,
			   boolean select){
    treeModel.insertNodeInto(child, parent, parent.getChildCount());
    openNode(child,select);  }

  public DefaultTreeModel getTreeModel() {
    return treeModel; }

  public static void main(String args[]) {
   // set some defaults
    Color blue = Factory.makeBlueColor();

    ImageIcon leaf =  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/document.gif"), "Leaf Icon");
    java.awt.Image temp = leaf.getImage();
    leaf.setImage(temp.getScaledInstance(15, 15, java.awt.Image.SCALE_DEFAULT));

    ImageIcon collapsed =  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/plus.gif"), "Collapsed Icon");
    temp = collapsed.getImage();
    collapsed.setImage(temp.getScaledInstance(12, 12, java.awt.Image.SCALE_DEFAULT));

    ImageIcon expanded =  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/minus.gif"), "Expanded Icon");
    temp = expanded.getImage();
    expanded.setImage(temp.getScaledInstance(12, 12, java.awt.Image.SCALE_DEFAULT));

    ImageIcon open =  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/openarrow.gif"), "Open Icon");
    temp = open.getImage();
    open.setImage(temp.getScaledInstance(15, 15, java.awt.Image.SCALE_DEFAULT));

    ImageIcon closed =  new ImageIcon(BLCC5.class.getResource("/blcc/resources/images/folder.gif"), "Closed Icon");
    temp = closed.getImage();
    closed.setImage(temp.getScaledInstance(15, 15, java.awt.Image.SCALE_DEFAULT));


    Object defaultColors[] = {"TitledBorder.titleColor", blue,
                              "Tree.selectionForeground", Color.white,
                              "Tree.selectionBackground", blue,
                              "Menu.selectionForeground", Color.white,
                              "Menu.selectionBackground", blue,
                              "MenuItem.selectionForeground", Color.white,
                              "MenuItem.selectionBackground", blue,
                              "MenuItem.acceleratorForeground", blue,
                              "TextField.selectionForeground", Color.white,
                              "TextField.selectionBackground", blue,
                              "TextArea.selectionForeground", Color.white,
                              "TextArea.selectionBackground", blue,
                              "EditorPane.selectionForeground", Color.white,
                              "EditorPane.selectionBackground", blue,
                              "ComboBox.selectionForeground", Color.white,
                              "ComboBox.selectionBackground", blue,
                              "ScrollBar.thumb", blue,
                              "Button.focus", blue,
                              "TabbedPane.focus", blue,
                              "Table.selectionForeground", Color.white,
                              "Table.selectionBackground", blue,
                              "Label.foreground", Color.black,  // for file chooser
                              "List.selectionBackground", blue,
                              "List.selectionForeground", Color.white,
                              "Tree.leafIcon", leaf,
                              "Tree.collapsedIcon", collapsed,
                              "Tree.expandedIcon", expanded,
                              "Tree.openIcon", open,
                              "Tree.closedIcon", closed,
                              "ToolTip.background", Color.white};

    UIManager.getDefaults().putDefaults(defaultColors);
    BLCC5 blcc5 = new BLCC5("BLCC5");
    blcc5.setSize(new Dimension(800, 600));
    blcc5.show();

  }

  public boolean reportValidate() {
    String message = "";
    boolean noErrors = true;

   try{project.validate(true);}
   catch(ValidationException ve){
    ModelElement element = ve.getElement();
    ModelElement owner = element.getOwner();
    String name = null;

    if (owner == null) name = "Project "; // + element.getName();
    else if (owner.getClass() == Alternative.class) name = "Alternative " + owner.getName();
    else if (owner.getClass() == CapitalComponent.class) name = "Component "  + owner.getName();
    else name = element.getName();

    message = "Report can't be generated because of an error in " + name +
      ".  \nPlease check your information and try again.";

    noErrors = false;
    JOptionPane.showMessageDialog(this,
				    message,
				    "Error",

            JOptionPane.ERROR_MESSAGE);
    }

    return noErrors;  }

  public void reset() {

   //asr - 10/16/01 clear out cache to prevent problems in setAnalysisSpecific()
   for(int i=0; i<BLCCTreeNode.MAXTYPES; i++)
     tabcache[i]=null;

    if(tabcache[BLCCTreeNode.PROJECT_NODE] !=null)
      ((ProjectTabbed)tabcache[BLCCTreeNode.PROJECT_NODE])
	    .getEndYearInput().setSelected(true);
    actionSaveAs.setEnabled(true);
    actionClose.setEnabled(true);
    closeButton.setEnabled(true);
    actionDetailed.setEnabled(true);
    actionCashFlow.setEnabled(true);
    actionInput.setEnabled(true);
    actionSummary.setEnabled(true);
    actionLowest.setEnabled(true);
    actionCompare.setEnabled(true);
    if(project.getAnalysisType()==blcc.model.Project.MILCONECIPANALYSIS) {
      actionECIP.setEnabled(true);
      actionDetailed.setEnabled(false);
      actionCashFlow.setEnabled(false);
      actionSummary.setEnabled(false);
      actionLowest.setEnabled(false);
      actionCompare.setEnabled(false);}
    else {actionECIP.setEnabled(false);}
    actionExpandAll.setEnabled(true);
    expandAllButton.setEnabled(true);
    actionCollapseAll.setEnabled(true);
    collapseAllButton.setEnabled(true);

    mainCardLayout.show(mainPanel, "split");
    tree.setSelectionRow(0);
    validate();
  }

  public int saveProject() {
    int returnVal =0;
    doTreeEvent(false);

    if (fileName != null) {
      try{
       new XMLFormatter(new PrintWriter(new FileOutputStream(fileName), true)).format(project);
       //it was saved --> disable save stuff
       setNeedsSave(false);
       returnVal = JFileChooser.APPROVE_OPTION;
        } catch(Exception f){System.out.println(f); }
    }
    else { // show chooser box
      JFileChooser chooser = new JFileChooser(defaultDirectory);
      chooser.setMultiSelectionEnabled(false);  // not implemented yet in the current LFs
      BLCCFileFilter filter = new BLCCFileFilter(BLCCFileFilter.XML);
      chooser.setFileFilter(filter);
      returnVal = chooser.showSaveDialog(BLCC5.this);

      if (returnVal == JFileChooser.APPROVE_OPTION) {
       // first, does it already exist
       java.io.File temp=chooser.getSelectedFile();
       // does it have an extension?
       if(filter.getExtension(temp) == null)
        temp=new java.io.File(temp.toString() + ".xml");
       if(temp.exists()){
         int n=replaceFile(temp);
         if(n==JOptionPane.CANCEL_OPTION)
           return JFileChooser.CANCEL_OPTION;
         if(n==JOptionPane.NO_OPTION)
           return saveProject();
         // if YES_OPTION, continue with method
        }

       fileName = chooser.getSelectedFile().toString();
      if (filter.getExtension(chooser.getSelectedFile()) == null) // user didn't type in ext
       fileName = fileName + ".xml";

      try {
         new XMLFormatter(new PrintWriter(new FileOutputStream(fileName), true)).format(project);
        } catch(Exception e){e.printStackTrace(System.out);}
       //it was saved --> disable save stuff
       setNeedsSave(false);

       setTitle(Project.analysisNames[analysisType] + " - " + fileName);
      }
          }
    return returnVal; }

  public int replaceFile(java.io.File file){
   Object[] options = {"Yes",
          "No",
          "Cancel"};
    int n =  JOptionPane.showOptionDialog(this,
            "Do you want to replace " + file.toString() + " ?",
             "Replace?",
              JOptionPane.YES_NO_CANCEL_OPTION,
              JOptionPane.QUESTION_MESSAGE,
              null,
              options,
              options[0]);
  return n;}



  public void setPreviousNode(BLCCTreeNode newPrevious) {
    previousNode = newPrevious; }

  /* ********************************************************************** */

  public void createAlternativeNode(Alternative alt,boolean select, boolean opening) {
    BLCCTreeNode altNode;
    if(analysisType==Project.MILCONECIPANALYSIS){altNode = new BLCCTreeNode(BLCCTreeNode.ALTERNATIVE_SAVINGS_NODE,alt);}
    else{altNode = new BLCCTreeNode(BLCCTreeNode.ALTERNATIVE_NODE,alt);}
    // add new nodes to tree
    addChildNode(projectNode, altNode, select);

    if (analysisType == Project.FINANCEDANALYSIS) {
      BLCCTreeNode addRC=new BLCCTreeNode(BLCCTreeNode.ADD_ARC_CONTRACT_NODE,alt);
      addChildNode(altNode,addRC,false);
      for (Enumeration e=alt.enumerateRecurringContractCosts();e.hasMoreElements(); )
         createRecurringContractSubNode(addRC,(RecurringContractCost)e.nextElement(),false);
      if(opening)closeNode(addRC);
      BLCCTreeNode addNRC=new BLCCTreeNode(BLCCTreeNode.ADD_NARC_CONTRACT_NODE,alt);
      addChildNode(altNode,addNRC,false);
      for (Enumeration e=alt.enumerateNonRecurringContractCosts();e.hasMoreElements(); )
         createNonRecurringContractSubNode(addNRC,(NonRecurringContractCost)e.nextElement(),false);
      if(opening)closeNode(addNRC);}


    BLCCTreeNode adde;
    if(analysisType==Project.MILCONECIPANALYSIS){adde=new BLCCTreeNode(BLCCTreeNode.ADD_ENERGY_SAVINGS_NODE,alt);}
    else {adde=new BLCCTreeNode(BLCCTreeNode.ADD_ENERGY_NODE,alt);}
    addChildNode(altNode,adde,false);
    if(opening)closeNode(adde);
    for(Enumeration e=alt.enumerateEnergyUsages(); e.hasMoreElements();)
    createEnergySubNode(adde,(EnergyUsage)e.nextElement(),false);

    BLCCTreeNode addw;
    if(analysisType==Project.MILCONECIPANALYSIS){addw=new BLCCTreeNode(BLCCTreeNode.ADD_WATER_SAVINGS_NODE, alt);}
    else{addw=new BLCCTreeNode(BLCCTreeNode.ADD_WATER_NODE, alt);}
    addChildNode(altNode,addw,false);
    if(opening)closeNode(addw);
    for(Enumeration e=alt.enumerateWaterUsages(); e.hasMoreElements();)
      createWaterSubNode(addw,(WaterUsage)e.nextElement(),false);

		//if (analysisType == Project.OMBANALYSIS) {
      //BLCCTreeNode OMBaddRC=new BLCCTreeNode(BLCCTreeNode.ADD_ARC_CONTRACT_NODE,alt);
      //addChildNode(altNode,OMBaddRC,false);
      //for (Enumeration e=alt.enumerateRecurringContractCosts();e.hasMoreElements(); )
       //  createRecurringContractSubNode(OMBaddRC,(RecurringContractCost)e.nextElement(),false);
      //if(opening)closeNode(OMBaddRC);
      //BLCCTreeNode OMBaddNRC=new BLCCTreeNode(BLCCTreeNode.ADD_NARC_CONTRACT_NODE,alt);
      //addChildNode(altNode,OMBaddNRC,false);
      //for (Enumeration e=alt.enumerateNonRecurringContractCosts();e.hasMoreElements(); )
        // createNonRecurringContractSubNode(OMBaddNRC,(NonRecurringContractCost)e.nextElement(),false);
      //if(opening)closeNode(OMBaddNRC);}


    for(Enumeration e=alt.enumerateCapitalComponents(); e.hasMoreElements();)
  createComponentNode(altNode,(CapitalComponent)e.nextElement(),false,opening);
    }

  public void createEnergySubNode(BLCCTreeNode node, EnergyUsage energy,
          boolean select) {
    if (energy.getName().equals("")) energy.setName(energy.getFuelType().getPrettyName());

    if(analysisType==Project.MILCONECIPANALYSIS){addChildNode(node,new BLCCTreeNode(BLCCTreeNode.ENERGY_SAVINGS_NODE, energy), select);}
    else {addChildNode(node,new BLCCTreeNode(BLCCTreeNode.ENERGY_NODE, energy), select);}
   }


  public void createWaterSubNode(BLCCTreeNode node, WaterUsage water,
          boolean select) {
    if(analysisType==Project.MILCONECIPANALYSIS){addChildNode(node,new BLCCTreeNode(BLCCTreeNode.WATER_SAVINGS_NODE, water),select);}
    else {addChildNode(node,new BLCCTreeNode(BLCCTreeNode.WATER_NODE, water),select);}
  }

  public void createComponentNode(BLCCTreeNode parent, CapitalComponent comp,
          boolean select, boolean opening) {
    BLCCTreeNode compNode;
    if(analysisType==Project.MILCONECIPANALYSIS){
      compNode=new BLCCTreeNode(BLCCTreeNode.COMPONENT_SAVINGS_NODE,comp);}
    else {compNode=new BLCCTreeNode(BLCCTreeNode.COMPONENT_NODE,comp);}
    addChildNode(parent,compNode,select);

    if(analysisType==Project.MILCONECIPANALYSIS){addChildNode(compNode,new BLCCTreeNode(BLCCTreeNode.ECIP_INVESTMENT_NODE,comp),false);}
    else{addChildNode(compNode,new BLCCTreeNode(BLCCTreeNode.INVESTMENT_NODE,comp),false);}

    if(analysisType!=Project.MILCONECIPANALYSIS){ // ECIP does not have replacements
     BLCCTreeNode addr;
     if(analysisType==Project.MILCONENERGYANALYSIS || analysisType==Project.MILCONNONENERGYANALYSIS)
     {addr=new BLCCTreeNode(BLCCTreeNode.ADD_MAJOR_REPAIR_REPLACEMENT_NODE,comp);}
     else{addr=new BLCCTreeNode(BLCCTreeNode.ADD_REPLACEMENT_NODE,comp);}
      addChildNode(compNode,addr,false);
     for(Enumeration e=comp.enumerateCapitalReplacements(); e.hasMoreElements();)
      createReplacementSubNode(addr,(CapitalReplacement)e.nextElement(),false);
    }

    BLCCTreeNode addc;
    if(analysisType==Project.MILCONENERGYANALYSIS||analysisType==Project.MILCONNONENERGYANALYSIS){addc=new BLCCTreeNode(BLCCTreeNode.ADD_ROUTINE_ARC_NODE, comp);}
    else if(analysisType==Project.MILCONECIPANALYSIS){addc=new BLCCTreeNode(BLCCTreeNode.ADD_ARC_SAVINGS_NODE, comp);}
    else{addc=new BLCCTreeNode(BLCCTreeNode.ADD_ARC_NODE, comp);}
    addChildNode(compNode,addc,false);
    for(Enumeration e=comp.enumerateRecurringCosts(); e.hasMoreElements();)
     createRecurringSubNode(addc,(RecurringCost)e.nextElement(),false);

    BLCCTreeNode addn;
    if(analysisType==Project.MILCONENERGYANALYSIS||analysisType==Project.MILCONNONENERGYANALYSIS){addn=new BLCCTreeNode(BLCCTreeNode.ADD_ROUTINE_NARC_NODE, comp);}
    else if(analysisType==Project.MILCONECIPANALYSIS){addn=new BLCCTreeNode(BLCCTreeNode.ADD_NARC_SAVINGS_NODE, comp);}
    else{addn=new BLCCTreeNode(BLCCTreeNode.ADD_NARC_NODE, comp);}
    addChildNode(compNode,addn,false);
    for(Enumeration e=comp.enumerateNonRecurringCosts(); e.hasMoreElements();)
      createNonRecurringSubNode(addn,(NonRecurringCost)e.nextElement(),false);


    if(opening)closeNode(compNode);
    }

  public void createReplacementSubNode(BLCCTreeNode parent,
				       CapitalComponent replacement,
				       boolean select) {
     if(analysisType==Project.MILCONENERGYANALYSIS ||analysisType==Project.MILCONNONENERGYANALYSIS){addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.MAJOR_REPAIR_REPLACEMENT_NODE,replacement),select);}
     else{addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.REPLACEMENT_NODE,replacement),select);}
   }


  public void createRecurringContractSubNode(BLCCTreeNode parent,RecurringContractCost contract,
				    boolean select) {
    addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.ARC_CONTRACT_NODE, contract),
     select);}
  public void createNonRecurringContractSubNode(BLCCTreeNode parent,NonRecurringContractCost contract,
				    boolean select) {
    addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.NARC_CONTRACT_NODE, contract),
     select);}


  public void createRecurringSubNode(BLCCTreeNode parent,
					      RecurringCost recurring,
					      boolean select) {
    if(analysisType==Project.MILCONENERGYANALYSIS||analysisType==Project.MILCONNONENERGYANALYSIS){ addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.ROUTINE_ARC_NODE,recurring),select); }
    else if(analysisType==Project.MILCONECIPANALYSIS){addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.ARC_SAVINGS_NODE,recurring),select); }
    else{addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.ARC_NODE,recurring),select); }
  }

  public void createNonRecurringSubNode(BLCCTreeNode parent,
                NonRecurringCost nonRecurring,
					      boolean select) {
    if(analysisType==Project.MILCONENERGYANALYSIS||analysisType==Project.MILCONNONENERGYANALYSIS){ addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.ROUTINE_NARC_NODE,nonRecurring),select); }
    else if(analysisType==Project.MILCONECIPANALYSIS){addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.NARC_SAVINGS_NODE,nonRecurring),select); }
    else{addChildNode(parent,new BLCCTreeNode(BLCCTreeNode.NARC_NODE,nonRecurring),select); }
  }

 public void compareReport(Vector alts){

   box = new JDialog(this, "Alternatives to Compare");
   FormPanel form = new FormPanel();
   JButton ok;
   JButton cancel;
   base = new Chooser();
   base.setChoices(alts);
   alt = new Chooser();
   alt.setChoices(alts);
   alt.setChoice(1);                    // so alt shows second alt in project
   form.addField(Factory.makeLabel("Base Case:"), base);
   form.addField(Factory.makeLabel("Alternative:"), alt);

   box.getContentPane().add(form, BorderLayout.CENTER);

   JPanel buttonPanel = new JPanel();
   buttonPanel.add(ok=new JButton("OK"));
   buttonPanel.add(cancel=new JButton("Cancel"));
   box.getContentPane().add(buttonPanel, BorderLayout.SOUTH);

   ok.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {
    setCursor(waitCursor);
    ReportDialog report = new ReportDialog(getProject(), "Comparative Analysis", fileName,
                          (Alternative)base.getChoice(), (Alternative)alt.getChoice());
    box.setVisible(false);
    setCursor(normalCursor);}});

   cancel.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {
    box.setVisible(false);}});
    box.setSize(400,200);
    box.show();
 }


 // for now, keep as is; might want to re-do so code for ecip and compare is not repeated
  public void ecipReport(Vector alts){

   box = new JDialog(this, "Alternatives to Compare");
   FormPanel form = new FormPanel();
   JButton ok;
   JButton cancel;
   base = new Chooser();
   base.setChoices(alts);
   alt = new Chooser();
   alt.setChoices(alts);
   alt.setChoice(1);                    // so alt shows second alt in project
   form.addField(Factory.makeLabel("Base Case:"), base);
   form.addField(Factory.makeLabel("Alternative:"), alt);

   box.getContentPane().add(form, BorderLayout.CENTER);

   JPanel buttonPanel = new JPanel();
   buttonPanel.add(ok=new JButton("OK"));
   buttonPanel.add(cancel=new JButton("Cancel"));
   box.getContentPane().add(buttonPanel, BorderLayout.SOUTH);

   ok.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {
    setCursor(waitCursor);
    ReportDialog report = new ReportDialog(getProject(), "ECIP", fileName,
                          (Alternative)base.getChoice(), (Alternative)alt.getChoice());
    box.setVisible(false);
    setCursor(normalCursor);}});

   cancel.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {
    box.setVisible(false);}});
    box.setSize(400,200);
    box.show();
   }


 public void closeOpenReports(){
  // close any open reports
   java.awt.Frame[] reportWindows = java.awt.Frame.getFrames();
   for(int i=0; i<reportWindows.length; i++){
     if(reportWindows[i] instanceof ReportDialog)
      reportWindows[i].dispose();}
 }


}

