package blcc.gui;

import javax.swing.*;
import javax.swing.table.TableModel;
import javax.swing.table.AbstractTableModel;
import blcc.gui.widgets.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Calendar;
import blcc.util.DateDiff;
import blcc.model.RecurringCost;
import blcc.model.ModelElement;
import blcc.model.CapitalComponent;
import blcc.model.SimpleEscalation;
import javax.swing.tree.TreePath;

public class ECIPInvestmentTabbed extends TabbedPane {
  CapitalComponent component;
  DoubleField constructionInput, siohInput, designInput, totalCostInput, salvageInput, rebateInput, totalInvestmentInput;
  JLabel constructionLabel, siohLabel, designLabel, total1Label, salvageLabel, rebateLabel, total2Label;
  TipsSubPanel investmentTips;

  public ECIPInvestmentTabbed(BLCC5 blcc) {
    super(blcc);
    addTab("Investment Cost", getInvestmentTab()); }

  public void getInformation (ModelElement element) {
    component = (CapitalComponent) element;
    constructionInput.setValue(component.getConstructionCost());
    siohInput.setValue(component.getSIOH());
    designInput.setValue(component.getDesignCost());
    salvageInput.setValue(component.getSalvageValue());
    rebateInput.setValue(component.getUtilityRebate());

    double temp;
    totalCostInput.setValue(temp=component.getConstructionCost()+component.getSIOH()+component.getDesignCost());
    totalInvestmentInput.setValue(temp - component.getSalvageValue() - component.getUtilityRebate());
  }

  public JPanel getInvestmentTab() {
    String tips[] = {"Enter the differences in construction cost, SIOH and design cost for alternative relative to base case.  "
			               +"Suggested default for SIOH is 6%, for Design Cost 10% of construction cost.",
                     "Enter the salvage value of the existing equipment and the utility rebate, if any, for the alternative."};
    TabPanel tab = new TabPanel();
    FormPanel panel = new FormPanel("Initial Cost");

    panel.addField(Factory.makeLabel("Construction Cost:"),
       constructionInput = new DoubleField("$#,##0.00",true));
    constructionInput.addChangedListener(owner);
    constructionInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
    component.setConstructionCost(constructionInput.getValue());
    totalCostInput.setValue(returnTotal("cost"));}});
   constructionInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {siohInput.requestFocus(); }});

    panel.addField(Factory.makeLabel("SIOH:"),
       siohInput = new DoubleField("$#,##0.00",true));
    siohInput.addChangedListener(owner);
    siohInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
    component.setSIOH(siohInput.getValue());
    totalCostInput.setValue(returnTotal("cost"));}});
  siohInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {designInput.requestFocus(); }});

   panel.addField(Factory.makeLabel("Design Cost:"),
       designInput = new DoubleField("$#,##0.00",true));
    designInput.addChangedListener(owner);
    designInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
    component.setDesignCost(designInput.getValue());
    totalCostInput.setValue(returnTotal("cost"));}});
  designInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) { salvageInput.requestFocus(); }});


    panel.addField(Factory.makeLabel("     Total Cost:"),
       totalCostInput = new DoubleField("$#,##0.00",true));
    totalCostInput.setEnabled(false);

    panel.addField(Factory.makeLabel("Salvage Value of Existing Equipment:"),
       salvageInput = new DoubleField("$#,##0.00",true));
    salvageInput.addChangedListener(owner);
    salvageInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
    component.setSalvageValue(salvageInput.getValue());
    totalInvestmentInput.setValue(returnTotal("investment"));}});
   salvageInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {rebateInput.requestFocus(); }});

   panel.addField(Factory.makeLabel("Public Utility Company Rebate:"),
       rebateInput = new DoubleField("$#,##0.00",true));
    rebateInput.addChangedListener(owner);
    rebateInput.addChangedListener(new DefaultChangedListener(){
	public void noteChange(ChangedEvent e){
    component.setUtilityRebate(rebateInput.getValue());
    totalInvestmentInput.setValue(returnTotal("investment"));}});
   rebateInput.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {constructionInput.requestFocus(); }});

   panel.addField(Factory.makeLabel("     Total Investment:"),
       totalInvestmentInput = new DoubleField("$#,##0.00",true));
    totalInvestmentInput.setEnabled(false);

    tab.addSubPanel(panel);
    tab.addSpacerPanel();
    tab.addSubPanel(investmentTips = new TipsSubPanel(tips));
    return tab; }


  public Boolean guiValidate(ModelElement element) {
    boolean show = true;
    try{element.validate(false);}
    catch(blcc.model.ValidationException e){
      // go back to node with validation exception
      TreePath newPath = new TreePath(owner.getTreeModel()
				      .getPathToRoot(owner.getPreviousNode()));
      // set previousNode to null so it won't reset (and revalidate) the node
      owner.setPreviousNode(null);
      owner.getTree().setSelectionPath(newPath);
      JOptionPane.showMessageDialog(owner, e.getMessage(),
            "Error",
				    JOptionPane.ERROR_MESSAGE);
      show = false; }
    return new Boolean(show);
  }

  public double returnTotal(String total){
    if(total.equals("cost"))
     return constructionInput.getValue()+siohInput.getValue()+designInput.getValue();
   else
    return constructionInput.getValue()+siohInput.getValue()+designInput.getValue()-salvageInput.getValue()-rebateInput.getValue();
  }

}
