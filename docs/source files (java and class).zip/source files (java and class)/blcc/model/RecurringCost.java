package blcc.model;

import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.util.Choosable;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.ParseException;

/** RecurringCost represents a cost incurred at regular intervals within
	the study period. */
public class RecurringCost extends ModelElement implements Choosable {

  double amount = 0.0;
  Category category = Category.COST_OMR_RECURRING;
  UsageIndex index;

  public RecurringCost(){
    UsageIndex v = new UsageIndex();
    v.setValue(0,1.0);
    setIndex(v);
    setEscalation(new SimpleEscalation(0.0));}

  public DateDiff defaultInterval(){
    return DateDiff.YEAR; }

  /** Get the amount for this (non-recurring) cost.*/
  public double getAmount() {
    return amount; }

  /** Set the amount for this (non-recurring) cost.
    * The default is 0.0. */
  public void setAmount(double amount) {
    this.amount = amount; }

  public Category defaultCategory(){
    return Category.COST_OMR_RECURRING; }

  /** Get the category for costs that this cost incurs. */
  public Category getCategory(){
    return category; }

  /** Set the category for costs that this cost incurs. */
  public void setCategory(Category category){
    this.category = category; }

  /** Get the Index that shows how the cost varies over time. */
  public Varying getIndex(){
    return index; }

  /** Set the Index that shows how the cost varies over time. */
  public void setIndex(UsageIndex index){
    if (index != null)
      index.setOwner(this);
    this.index = index; }

  public RecurringCost copyRecurringCost(){
    RecurringCost newRC = new RecurringCost();
    newRC.setName("Copy of: " + getName());
    newRC.setComment(getComment());
    newRC.setStart(getStart());
    newRC.setDuration(getDuration());
    newRC.setInterval(getInterval());
    newRC.setAmount(getAmount());
    newRC.setEscalation(((SimpleEscalation)getEscalation()).copySimpleEscalation());
    newRC.setCategory(getCategory());

    UsageIndex copy = new UsageIndex();
    getIndex().copyInto(copy);
    newRC.setIndex(copy);
    return newRC;}

  public String getPrettyName(){
    return (name.equals("") ? "Unnamed Cost" : name); }



  /* ______________________________________________________________________
     IO */
  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    setStart(p.parseDateDiff(this,"Start",null));
    setDuration(p.parseDateDiff(this,"Duration",null));
    setInterval(p.parseDateDiff(this,"Interval",null));
    setAmount(p.parseDouble(this,"Amount",0.0));
    setEscalation((Escalation)p.parse(this,"Escalation",escalation));
    setCategory((Category) p.parseChoice(this,"Category",
				 Category.allCategories(),defaultCategory()));
    setIndex((UsageIndex) p.parse(this,"Index",index));
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatDateDiff(level,"Start",getStart(),defaultStart());
    fmt.formatDateDiff(level,"Duration",getDuration(),null);
    fmt.formatDateDiff(level,"Interval",getInterval(),defaultInterval());
    fmt.formatDouble(level,"Amount",getAmount(),0.0);
    fmt.formatElement(level,"Escalation",getEscalation(),null);
    fmt.formatChoice(level,"Category",getCategory(),defaultCategory());
    fmt.formatElement(level,"Index",index,null);
  }

  /* ______________________________________________________________________
     Validation */
  public void validate(boolean recursive) throws ValidationException {
    Project p = getProject();
    // Uhmm check interval ?
    if (escalation != null) escalation.validate(recursive);
  }
  /* ______________________________________________________________________
     Analysis */

  public void analyze(Analysis analysis) {
    Escalation esc = getEscalation();
    int method = getProject().getDiscountingMethod();
    Date date  = getStartDate();
    Date end   = getEndDate().min(getProject().getEndDate());
    DateDiff interval = getInterval();
    Units money = getMonetaryUnits();
    while(date.before(end)){
      Date next = date.add(interval).min(end);
      double a = amount*index.average(date,next);
      if (method == Project.ENDYEARDISCOUNTING)   date = next.previousDay();
      else if(method==Project.MIDYEARDISCOUNTING) date = date.midpoint(next);
      analysis.addAmount(this,category, esc.escalate(a,date), money,date);
      date = next;
    }
  }
}
