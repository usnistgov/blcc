package blcc.model;

/** An Exception signalled when a ModelElement's attribute is not valid.
  * It provides pointers to the element and the name of the attribute. */
public class ValidationException extends Exception {
  ModelElement element;
  String attribute;

public ValidationException(String message, ModelElement element, String attribute){
    super(message);
    this.element = element;
    this.attribute = attribute;}

  /** Return the attribute of the ModelElement which is invalid.*/
  public String getAttribute(){
    return attribute; }

  /** Return the ModelElement which has an invalid attribute.*/
  public ModelElement getElement(){
    return element; }

  public String getMessage(){
    return super.getMessage();} //+" : in "+attribute+" of "+element; }

}
