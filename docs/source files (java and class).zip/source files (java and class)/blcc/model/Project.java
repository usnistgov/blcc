package blcc.model;

import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import java.util.Vector;
import java.util.Enumeration;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.ParseException;
import blcc.util.Choosable;

/** Project represents a whole BLCC project comprising one or more alternative
  * construction cases.  Contains general information applicable to all energy
  * conservation alternatives that constitute the project.
  */

public class Project extends ModelElement {

  public static final int NODISCOUNTING=0;
  public static final int ENDYEARDISCOUNTING=1;
  public static final int MIDYEARDISCOUNTING=2;

  public static final String[] discountingMethodNames={"None","End-of-Year", "Mid-Year"};

  public static final int CONSTANTDOLLARMETHOD=0;
  public static final int CURRENTDOLLARMETHOD=1;

  public static final int AGENCYFUNDEDANALYSIS=0;
  public static final int FINANCEDANALYSIS=1;
  public static final int MILCONENERGYANALYSIS=2;
  public static final int MILCONECIPANALYSIS=3;
	public static final int OMBANALYSIS=4;
	public static final int MILCONNONENERGYANALYSIS=5;

	public static final int INVEST_REGULATION=0;   //LIS addition
	public static final int COST_LEASE=1;
	public static final int IRRELEVANT=2;

  public static final String[] analysisNames ={"FEMP Analysis, Energy Project", "Federal Analysis, Financed Project", "MILCON Analysis, Energy Project", "MILCON Analysis, ECIP Project", "OMB Analysis, Non-Energy Project", "MILCON Analysis, Non-Energy Project"};
	public static final String[] analysisPurposes = {"Cost Effectiveness, Lease Purchase, Government Investment or Asset Sale Analysis","Public Investment or Regulatory Analysis"};

  /* General information */
  String location = null;
  String analyst="";
  Date studyDate = null;
  Date baseDate = null;
  DateDiff PCPeriod = new DateDiff(0,0,0);
  DateDiff installDuration = null;
  double discountRate = defaultDiscountRate(); //lis change
  int discountingMethod = ENDYEARDISCOUNTING;
  int dollarMethod;
	int analysisPurpose=COST_LEASE;   //LIS addition
  // 3-22-01
  double inflationRate;  // setInflationRate sets inflationRate to defaultInflationRate(), aka, always default rate
  Vector alternatives = new Vector();
  Units monetaryUnits = Units.USDOLLAR;
  int analysisType = AGENCYFUNDEDANALYSIS;

  /* ______________________________________________________________________
     Methods for Comparison between project alternatives. */

  public Project(){
    studyDate = new Date();
    baseDate = new Date(blcc.util.Defaults.getIntegerItem("default year"), Date.APRIL, 1);
    duration = new DateDiff(0,0,0);
    // 3-22-01
    inflationRate = defaultInflationRate();}


  public Project  getProject(){ return this; }

  public Units getMonetaryUnits(){
    return monetaryUnits; }

  //3-22-01
  //public double defaultInflationRate(){
   // return blcc.util.Defaults.getDoubleItem("inflation");}

  public void setMonetaryUnits(Units units){
    monetaryUnits = units; }

  /** Returns a brief description of the location of the Project site. */
  public String getLocation() {
    return (location == null ? blcc.util.DOEPrices.getStates()[0] : location); }
  /** Sets a brief description of the location of the project. */
  public void setLocation(String newlocation) {
    location = newlocation; }

  /** Returns the project's analyst */
  public String getAnalyst() {
    return analyst; }
  /** Sets project's analyst. */
  public void setAnalyst(String newanalyst) {
    analyst = newanalyst; }

 /** Returns the project's type */
  public int getAnalysisType() {
	 	//System.out.println(analysisType);
    return analysisType; }
  /** Sets the project's type */
  public void setAnalysisType(int newType) {
    analysisType = newType; }

	/*LIS addition:  Analysis Purpose is for OMB Projects
	 * Purpose can be Public Investment or Regulatory Analysis, or Cost Effectiveness, Lease Purchase, Interal Gov't Investment, or Asset Sale Analysis*/
  public int getAnalysisPurpose(){
		return analysisPurpose;}

	public void setAnalysisPurpose(int newPurpose){
		analysisPurpose = newPurpose;}
	//End LIS addition

  public Date getStudyDate() { return studyDate; }

  /** Return the Dollar Method used for recurring costs, energy and water.*/
  public int getDollarMethod(){
    return dollarMethod; }
  /** Set the Dollar Method used for recurring costs, energy and water.*/
  public void setDollarMethod(int method){
    dollarMethod=method; }

  /** Returns the BaseDate of the project study: the date at which all input
    * costs are relative. */
  public Date getBaseDate() {
    return baseDate; }
  /** Sets the BaseDate of the project study.
    * @see Project#getBaseDate */
  public void setBaseDate(Date newbasedate) {
    baseDate = newbasedate; }

  /** Returns the ServiceDate of the project study: the date at which the
   * project goes `into service'. */
  public Date getServiceDate() {
    return PCPeriod.addToDate(getBaseDate()); }

  /** Returns the length of the Planning & Construction Period.  This is the period between
   * the Base Date and Service Date.  (Note:  GUI asks for Service Date (from Base Date) to
   * get this value.)
   * @see Project#getServiceDate */
  public DateDiff getPCPeriod() {
    return PCPeriod; }

  /** Sets the length of the Planning & Construction Period.
    * @see Project#getServiceDate */
  public void setPCPeriod(DateDiff pcperiod) {
    PCPeriod = pcperiod; }

  /** Returns the EndDate of the project study: the last date of interest. */
  public Date getEndDate() {
   return getDuration().addToDate(getBaseDate()).previousDay(); }

  /** Returns the interest rate used throughout the study.  Any escalation rates (which
    * may vary per component or object) are in addition to this interest rate.
    * Average rate of annual inflation. */
  public double getInflationRate() {
    return inflationRate; }

  /** Return the effective Inflation rate; ie it is 0 for constant dollar analyses.*/
  public double getEffectiveInflation(){
	    return (dollarMethod == CONSTANTDOLLARMETHOD ? 0.0 : defaultInflationRate());
	}

  /** Sets the inflation rate used throughout the study.
    * @see Project#getInflationRate */
  //3-22-01
  public void setInflationRate(double newrate) {
     // ALWAYS use default inflation rate per SKF
     inflationRate = defaultInflationRate();}
    //inflationRate = newrate; }

  /** Returns the discount rate used throughout the study.
    * Discount rate used to convert amounts to present values at the Base
    * Date.
    * This rate is nominal if CurrentDollar analysis is in effect */
  public double getDiscountRate() {
     return (1.0 + discountRate)*(1.0 + getEffectiveInflation()) - 1.0; }


	 public double defaultDiscountRate(){
		double defdiscountRate;
		if ( analysisType==MILCONNONENERGYANALYSIS ) {
			defdiscountRate = interpolate("Discount");		}
		else if ( analysisType!= OMBANALYSIS) {
			defdiscountRate = blcc.util.Defaults.getDoubleItem("real discount");
		}else{
			if ( analysisPurpose == INVEST_REGULATION ) {
				defdiscountRate=blcc.util.Defaults.getDoubleItem("invest");
			}else{
					defdiscountRate = interpolate("Discount");
				}
		}
		return defdiscountRate;
	 }
	 //lis change 2/16/04
	 //asr change 3/13/06 - per Linde, INVEST_REGULATION analysis should also use interpolated inflation rates
	 public double defaultInflationRate(){
		double defInflationRate;
		if ( analysisType == OMBANALYSIS || analysisType == MILCONNONENERGYANALYSIS ) {
	         defInflationRate = interpolate("Inflation");}
		else{
		 defInflationRate = blcc.util.Defaults.getDoubleItem("inflation");}

		return defInflationRate;
	 }



	 public double interpolate(String type){
		double threeyear;
		double fiveyear;
		double sevenyear;
		double tenyear;
		double thirtyyear;
		if ( type=="Discount" ) {
			threeyear = blcc.util.Defaults.getDoubleItem("three year");
			fiveyear = blcc.util.Defaults.getDoubleItem("five year");
			sevenyear = blcc.util.Defaults.getDoubleItem("seven year");
			tenyear = blcc.util.Defaults.getDoubleItem("ten year");
			thirtyyear = blcc.util.Defaults.getDoubleItem("thirty year");
		}else{
			threeyear = blcc.util.Defaults.getDoubleItem("three year inflation");
			fiveyear = blcc.util.Defaults.getDoubleItem("five year inflation");
			sevenyear = blcc.util.Defaults.getDoubleItem("seven year inflation");
			tenyear = blcc.util.Defaults.getDoubleItem("ten year inflation");
			thirtyyear = blcc.util.Defaults.getDoubleItem("thirty year inflation");}

		int year = duration.getYears();
		if ( year<=3 ) {
			return threeyear;
 		}else if ( year==4) {
			return ((threeyear*.5)+(fiveyear*.5));
		}else if ( year==5 ) {
			return fiveyear;
		}else if ( year==6) {
			return ((fiveyear*.5)+(sevenyear*.5));
		}else if ( year==7 ) {
			return sevenyear;
		}else if ( year==8 ) {
			return ((sevenyear*.667)+(tenyear*.333));
		}else if ( year==9 ) {
			return ((sevenyear*.333)+(tenyear*.667));
		}else if ( year==10 ) {
			return tenyear;
		}else if (year<=30){
			double top = year-10;
			double factor = (top*.05);
			//System.out.println("Factor:  "+factor);
			double one = tenyear*(1-factor);
			double two = thirtyyear*factor;
			//System.out.println(one);
			//System.out.println(two);
			return (one+two);
	  }else {
			return thirtyyear;
		}
	 }


  /** Sets the discount rate used throughout the study.
   * Give the nominal rate (if CurrentDollar analysis)
   * the real rate will be stored internally
    * @see Project#getDiscountRate */
  public void setDiscountRate(double newrate) {
     discountRate = (1.0+newrate)/(1.0+ getEffectiveInflation()) - 1.0;
	}

	public void setDiscountRate(){
		 discountRate = defaultDiscountRate();
	}


  /** Return the Discounting Method used for recurring costs, energy and water.*/
  public int getDiscountingMethod(){
    return discountingMethod; }
  /** Set the Discounting Method used for recurring costs, energy and water.*/
  public void setDiscountingMethod(int method){
    discountingMethod=method; }

  /** Adds an Alternative to be studied for the project.  */
  public void addAlternative(Alternative alt){
    if(alt != null){
      alt.setOwner(this);
      alternatives.addElement(alt); }}
  /** Returns an enumeration allowing iteration through all Alternatives being studied.*/
  public Enumeration enumerateAlternatives() {
    return alternatives.elements(); }
  /** Removes an Alternative from the project.  */
  public void removeAlternative(Alternative alt){
    alt.setOwner(null);
    alternatives.removeElement(alt); }


  // methods that return a vector containing all the instances of that particular item for the entire project

   public Vector getAlternativeChoices(){
     Vector alt = new Vector();
    for (java.util.Enumeration enum1 = enumerateAlternatives(); enum1.hasMoreElements();) { // go through alts
      alt.addElement((Alternative)enum1.nextElement());}
    return alt;}

   public Vector getComponentChoices(){
     Vector comp = new Vector();

    for (Enumeration anum = enumerateAlternatives(); anum.hasMoreElements();){
      Alternative alt = (Alternative) anum.nextElement();
     for (Enumeration enum1 = alt.enumerateCapitalComponents(); enum1.hasMoreElements();) {
          comp.addElement((CapitalComponent)enum1.nextElement());}}
    return comp;}

   public Vector getEnergyChoices(){
     Vector energy = new Vector();

    for (Enumeration anum = enumerateAlternatives(); anum.hasMoreElements();){
      Alternative alt = (Alternative) anum.nextElement();
     for (Enumeration enum1 = alt.enumerateEnergyUsages(); enum1.hasMoreElements();) {
          energy.addElement((EnergyUsage)enum1.nextElement());}}
    return energy;}

   public Vector getWaterChoices(){
     Vector water = new Vector();
    for (Enumeration anum = enumerateAlternatives(); anum.hasMoreElements();){
      Alternative alt = (Alternative) anum.nextElement();
     for (Enumeration enum1 = alt.enumerateWaterUsages(); enum1.hasMoreElements();) {
          water.addElement((WaterUsage)enum1.nextElement());}}
    return water;}

   public Vector getRecurringContractChoices(){
     Vector cost = new Vector();
    for (Enumeration anum = enumerateAlternatives(); anum.hasMoreElements();){
      Alternative alt = (Alternative) anum.nextElement();
     for (Enumeration enum1 = alt.enumerateRecurringContractCosts(); enum1.hasMoreElements();) {
          cost.addElement((RecurringContractCost)enum1.nextElement());}}
    return cost;}

   public Vector getNonRecurringContractChoices(){
     Vector cost = new Vector();
    for (Enumeration anum = enumerateAlternatives(); anum.hasMoreElements();){
      Alternative alt = (Alternative) anum.nextElement();
     for (Enumeration enum1 = alt.enumerateNonRecurringContractCosts(); enum1.hasMoreElements();) {
          cost.addElement((NonRecurringContractCost)enum1.nextElement());}}
    return cost;}

   public Vector getRecurringOMRChoices(){
    Vector cost = new Vector();
    for (Enumeration anum = enumerateAlternatives(); anum.hasMoreElements();){
      Alternative alt = (Alternative) anum.nextElement();
      for (Enumeration cnum = alt.enumerateCapitalComponents();cnum.hasMoreElements();){
         CapitalComponent comp = (CapitalComponent) cnum.nextElement();
         for (Enumeration enum1 = comp.enumerateRecurringCosts(); enum1.hasMoreElements();) {
          cost.addElement((RecurringCost)enum1.nextElement());}}}
    return cost;}

   public Vector getNonRecurringOMRChoices(){
    Vector cost = new Vector();
    for (Enumeration anum = enumerateAlternatives(); anum.hasMoreElements();){
      Alternative alt = (Alternative) anum.nextElement();
      for (Enumeration cnum = alt.enumerateCapitalComponents();cnum.hasMoreElements();){
         CapitalComponent comp = (CapitalComponent) cnum.nextElement();
         for (Enumeration enum1 = comp.enumerateNonRecurringCosts(); enum1.hasMoreElements();) {
          cost.addElement((NonRecurringCost)enum1.nextElement());}}}
    return cost;}


   public Vector getReplacementChoices(){
    Vector cost = new Vector();
    for (Enumeration anum = enumerateAlternatives(); anum.hasMoreElements();){
      Alternative alt = (Alternative) anum.nextElement();
      for (Enumeration cnum = alt.enumerateCapitalComponents();cnum.hasMoreElements();){
         CapitalComponent comp = (CapitalComponent) cnum.nextElement();
         for (Enumeration enum1 = comp.enumerateCapitalReplacements(); enum1.hasMoreElements();) {
          cost.addElement((CapitalReplacement)enum1.nextElement());}}}
    return cost;}











  /* ______________________________________________________________________
     IO */
  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    setLocation(p.parseString(this,"Location",""));
    setAnalyst(p.parseString(this,"Analyst",""));
    setAnalysisType(p.parseInt(this,"AnalysisType", 0));
		setAnalysisPurpose(p.parseInt(this,"AnalysisPurpose",0));
    setDollarMethod(p.parseInt(this,"DollarMethod",0));
    setBaseDate(p.parseDate(this,"BaseDate",baseDate));
    setPCPeriod(p.parseDateDiff(this,"PCPeriod",PCPeriod));
    setDuration(p.parseDateDiff(this,"Duration",duration));
    setInflationRate(p.parseDouble(this,"InflationRate",inflationRate));
    setDiscountingMethod(p.parseInt(this,"DiscountingMethod",0));
    discountRate = (p.parseDouble(this,"DiscountRate",0.0));

    for(Enumeration e=p.getContents(this,"Alternatives"); e.hasMoreElements();)
      addAlternative((Alternative) p.parseNext(this,e));
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatString(level,"Location",getLocation(),"");
    fmt.formatString(level,"Analyst",getAnalyst(),"");
    fmt.formatInt(level,"AnalysisType",getAnalysisType(), 0);
		fmt.formatInt(level,"AnalysisPurpose",getAnalysisPurpose(),0);
    fmt.formatInt   (level,"DollarMethod",getDollarMethod(),0);
    fmt.formatDate  (level,"BaseDate", getBaseDate(),null);
    fmt.formatDateDiff(level,"PCPeriod",getPCPeriod(),null);
    fmt.formatDateDiff(level,"Duration", getDuration(),null);
    // 3-22-01
    fmt.formatDouble(level,"InflationRate",getInflationRate(),defaultInflationRate());
    fmt.formatInt   (level,"DiscountingMethod",getDiscountingMethod(),0);
    fmt.formatDouble(level,"DiscountRate", discountRate,0.0);
    fmt.formatElements(level,"Alternatives",enumerateAlternatives()); }

  /* ______________________________________________________________________
     Validation */

  /** Validate the attributes of the Project.
    * @exception ValidationException for invalid attributes of the project.*/
  public void validate(boolean recursive) throws ValidationException {
    Date base = getBaseDate();
    Date svc  = getServiceDate();
    Date end  = getEndDate();

    if(base.before(new Date(blcc.util.Defaults.getIntegerItem("default year"), Date.APRIL, 1)))
      throw new ValidationException("Base Date must be April " +
             blcc.util.Defaults.getIntegerItem("default year")+" or later.", this, "Base Date");
    if(!(base.before(end)))
      throw new ValidationException("Study Period Length is not valid.",this,"Duration");
    if(!svc.between(base,end))
      throw new ValidationException("Service Date is not in Study Period.",this,"Service Date");

		if (analysisType == FINANCEDANALYSIS && (!end.between(svc, svc.add(new DateDiff(25,0,0))))){  // 10-29-11 per Bobbie, Financed project should still have 25 year max
		    throw new ValidationException("Study Period length is more than 25 years.",this,"Duration");}
		else if (!end.between(svc, svc.add(new DateDiff(40,0,0)))){  // 40 year max in rest except for OMB and MILCON Non-Energy
      if(analysisType == AGENCYFUNDEDANALYSIS){ // FEMP project, SERVICE period can't exceed 40 years, need different wording for error msg
				throw new ValidationException("Study Period extends more than 40 years beyond Service Date.",this,"Duration");}
      else if(analysisType!=OMBANALYSIS && analysisType!= MILCONNONENERGYANALYSIS ){  // MILCON Energy and MILCON ECIP, study period can't exceed 40 years, need different wording for error msg
				throw new ValidationException("Study Period length is more than 40 years.",this,"Duration");}}

		if ((-0.02 > getDiscountRate()) || (getDiscountRate() > 0.25)) //changed 0.0 to -0.02  3/23/21
      throw new ValidationException("Discount Rate is not between -2.0% and 25%.",
            this,"DiscountRate");
    if ((-0.02 > inflationRate) || (inflationRate > 2.00)) //changed -0.01 to -0.02  3/19/21
      throw new ValidationException("Inflation Rate is not between -2.0% and 200%.",this,
            "InflationRate");  //changed -1.0 to -2.0 3/19/21
    if(!Category.COST.isValidUnits(monetaryUnits))
      throw new ValidationException("Not valid monetary units."+monetaryUnits,
				    this,"MonetaryUnits");
    if (recursive)
      mapValidation(enumerateAlternatives());
  }
  /* ______________________________________________________________________
     Analysis */

  /** Multiply a PresentValue amount by this to get Annual Value. */
  public double getCapitalRecoveryFactor(){
    double nomRate = getDiscountRate();
    double period=DateDiff.diffInYears(getBaseDate(),getEndDate());
    if (nomRate == 0.0)
      return 1/period;
    else {
      double iperiod = Math.floor(period);
      double fperiod = period - iperiod;
      double disc1=Math.pow(1+nomRate,iperiod);
      double u = (iperiod > 0 ? (disc1-1.0)/nomRate/disc1 : 0.0);
      return 1/(u+fperiod/Math.pow(1+nomRate,period)); }
  }

  public void analyze(Analysis analysis) {
    for(Enumeration e=enumerateAlternatives(); e.hasMoreElements(); )
      ((Alternative) e.nextElement()).analyze(analysis);
  }
}
