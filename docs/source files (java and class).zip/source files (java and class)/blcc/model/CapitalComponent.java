package blcc.model;

import blcc.util.Units;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.util.Vector;
import java.util.Enumeration;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import java.text.ParseException;
import blcc.util.Choosable;

/** A component is part of a project alternative (case).  The project
  * alternative may or may not be divided into components to be evaluated
  * individually.  Components of a building may be land, building, roof;
  * components of a building system may be air conditioners, compressors,
  * fans. */
public class CapitalComponent extends ModelElement implements Choosable{
  /* ______________________________________________________________________
     General Internal state */

  double initialCost = 0.0;
  double resaleValueFactor = 0.0;
  Vector capitalReplacements = new Vector();
  Vector recurring = new Vector();
  Vector nonrecurring = new Vector();
  PhaseIn phaseIn = null;
  Escalation resaleEscalation = null;
  double amountFinanced=0.0;
  double constructionCost=0.0, sioh=0.0, designCost=0.0, salvageValue=0.0, utilityRebate=0.0;


  /* ----------------------------------------
     Depreciation related info */
  DateDiff depreciation_life = null;
  double salvageValueFactor = 0.0;

  /* ________________________________________
     Tax related info */

  /* ... AND MORE ACCESSORS !!! */

  /** The percentage of the initial component cost to which the Property Tax
    * Rate for the overall project is applied in order to calculate the actual
    * property tax obligation. */
  double tax_assessment_rate;	// (% of initial cost)

  /** Tax credit rate as percent of the initial component cost that can be
    * claimed as an income tax credit in the first year of the service period.
    * The IRS may require a reduction in the depreciation basis by some
    * percentage of this credit.  (The percentage of the tax credit by which
    * the depreciation basis is to be reduced can be specified using the
    * Depreciation Basis Adjustment Factor in the Project class.) */
  double tax_credit_factor;      // (% of actual cost)


  /** Create a Capital Component. */
  public CapitalComponent() {
    setPhaseIn(new PhaseIn());
    setEscalation(new SimpleEscalation(0.0));
    setResaleEscalation(new SimpleEscalation(0.0));
    setDuration(new DateDiff(0,0,0));}

 // public Date getReferenceDate(){
   // return getProject().getBaseDate(); }

  /** Returns the initial cost of the component (as of BaseDate).
    * Installed (capital investment) cost of the component, unadjusted for
    * price escalation.  If Service Date is later than Base Date, BLCC4 uses
    * a cost-phasing schedule to determine actual component cost during the
    * P/C period and at the Service Date. */
  public double getInitialCost() {
    return initialCost; }

  /** Sets the initial cost of the component (as of BaseDate). */
  public void setInitialCost(double newcost) {
    initialCost = newcost; }


  /** Returns the amount financed; this amount is NOT used in the LCC calculations -
   * it is already included in the Contract Payment.  The amount is needed, however, to
   * calculated the residual value */
  public double getAmountFinanced() {
    return amountFinanced; }

  public void setAmountFinanced(double newamount) {
    amountFinanced = newamount; }

  /** Get the phase-in of the purchase of the Component.
    * This is an array specifying the portion of the InitialCost which is
    * incurred in each year from the StartDate.*/
  public PhaseIn getPhaseIn(){
    return phaseIn; }

  /** Set the phase-in of the purchase of the Component.*/
  public void setPhaseIn(PhaseIn phasein){
    if(phasein != null)
      phasein.setOwner(this);
    phaseIn = phasein; }

  /** Get the escalation rate used for resale values*/
  public Escalation getResaleEscalation(){
    return resaleEscalation; }

 /** Set the escalation rate used for phased-in costs*/
  public void setResaleEscalation(Escalation esc){
    if (esc != null) esc.setOwner(this);
    resaleEscalation = esc; }

  /** Return the resale value of the component.
    * This factor multiplies the (escalated) cost of the component to determine the
    * remaining value of the component.  If the resale value is negative, it
    * represents a disposal Cost. */
  public double getResaleValueFactor() {
    return resaleValueFactor; }

  /** Sets the resale value of the component.  */
  public void  setResaleValueFactor(double newfactor) {
    resaleValueFactor = newfactor; }

  /* The number of years over which a component will be depreciated. */
  /* (Additional info for depreciation:
     depreciation_type;	[C!(I,3)]
     acceleration_rate, if declining balance method [C!(I,4)]
     percent of initial cost allowable as 1st year depreciation)[C!(I,6)] */
  //  public DateDiff getDepriciationLife() ...

  /** Returns the salvage value of the component.
    * This combines any salvage/resale values of the left-over parts of the
    * Component, as well as any costs of disposal (the latter being a negative
    * contribution.)
    * Percent of initial component cost to be deducted as salvage value from
    * initial asset cost before calculating depreciation.  (This is only for
    * depreciation purposes, if required by the IRS; it is not the same as
    * the Resale Value Factor.) */
  public double getSalvageValueFactor() {
    return salvageValueFactor; }

  /** Sets the salvage value of the component.  */
  public void  setSalvageValueFactor(double newfactor) {
    salvageValueFactor = newfactor; }


  /** Gets construction cost - ECIP. */
  public double getConstructionCost() {
    return constructionCost; }

  /** Sets construction cost - ECIP. */
  public void setConstructionCost(double cost) {
    constructionCost = cost; }

  /** Gets SIOH - ECIP. */
  public double getSIOH() {
    return sioh; }

  /** Sets SIOH - ECIP. */
  public void setSIOH(double cost) {
    sioh = cost; }

  /** Gets design cost - ECIP. */
  public double getDesignCost() {
    return designCost; }

  /** Sets design cost - ECIP. */
  public void setDesignCost(double cost) {
    designCost = cost; }

  /** Gets salvage value - ECIP. */
  public double getSalvageValue() {
    return salvageValue; }

  /** Sets salvage value - ECIP. */
  public void setSalvageValue(double value) {
    salvageValue = value; }

  /** Gets utility rebate - ECIP. */
  public double getUtilityRebate() {
    return utilityRebate; }

  /** Sets utility rebate - ECIP. */
  public void setUtilityRebate (double rebate) {
    utilityRebate = rebate; }

  /** Adds a CapitalReplacement to this Component. */
  public void addCapitalReplacement(CapitalReplacement rep){
    if (rep != null) {
      rep.setOwner(this);
      capitalReplacements.addElement(rep); }}

  /** Removes a CapitalReplacement to this Component. */
  public void removeCapitalReplacement(CapitalReplacement rep){
    rep.setOwner(null);
    capitalReplacements.removeElement(rep); }

  /** Return an enumeration of the CapitalReplacements.*/
  public Enumeration enumerateCapitalReplacements() {
    return capitalReplacements.elements(); }

  /** Non-Annually Recurring OM&R Costs (NARCs).  They are minor, non-capital
    * repair or replacement costs financed out of current accounts.  Three
    * data entries -- amount, date, and rate of escalation -- are needed for
    * NARCs.  (In BLCC4, the rate of change entered for ARCs applies to these
    * costs also.) */
  public void addNonRecurringCost(NonRecurringCost cost){
    if (cost != null) {
      cost.setOwner(this);
      nonrecurring.addElement(cost); }}

  /** Non-Annually Recurring OM&R Costs (NARCs).  They are minor, non-capital
    * repair or replacement costs financed out of current accounts.  Three
    * data entries -- amount, date, and rate of escalation -- are needed for
    * NARCs.  (In BLCC4, the rate of change entered for ARCs applies to these
    * costs also.) */
  public void removeNonRecurringCost(NonRecurringCost cost){
    cost.setOwner(null);
    nonrecurring.removeElement(cost); }

  /** Remove all Non-Annually Recurring OM&R Costs (NARCs). */
  public void removeAllNonRecurringCosts(){
    for(Enumeration e=nonrecurring.elements(); e.hasMoreElements(); )
      ((NonRecurringCost) e.nextElement()).setOwner(null);
    nonrecurring.removeAllElements(); }

  /** Return an enumeration of the NonRecurringCosts.*/
  public Enumeration enumerateNonRecurringCosts() {
    return nonrecurring.elements(); }


  /** Annually recurring OM&R Costs (ARCs) of approximately the same amount
    * every year or changing at a (relatively) constant rate over the service
    * period.  Two data entries -- amount and rate of escalation -- are
    * needed for Annually Recurring Costs (ARCs).  (In BLCC4 the rate of
    * change is applied to Non-annually Recurring Costs also.) */
  public void addRecurringCost(RecurringCost cost){
    if (cost != null) {
      cost.setOwner(this);
      recurring.addElement(cost); }}

  /** Annually recurring OM&R Costs (ARCs) of approximately the same amount
    * every year or changing at a (relatively) constant rate over the service
    * period.  Two data entries -- amount and rate of escalation -- are
    * needed for Annually Recurring Costs (ARCs).  (In BLCC4 the rate of
    * change is applied to Non-annually Recurring Costs also.) */
  public void removeRecurringCost(RecurringCost cost){
    cost.setOwner(null);
    recurring.removeElement(cost); }

  /** Remove all Annually Recurring OM&R Costs (ARCs). */
  public void removeAllRecurringCosts(){
    for(Enumeration e=recurring.elements(); e.hasMoreElements(); )
      ((RecurringCost) e.nextElement()).setOwner(null);
    recurring.removeAllElements(); }

  /** Return an enumeration of the RecurringCosts.*/
  public Enumeration enumerateRecurringCosts() {
    return recurring.elements(); }

  public CapitalComponent copyCapitalComponent(){
    CapitalComponent newCC = new CapitalComponent();
    newCC.setName("Copy of: " + getName());
    newCC.setComment(getComment());
    newCC.setInitialCost(getInitialCost());
    newCC.setAmountFinanced(getAmountFinanced());
    newCC.setStart(getStart());
    newCC.setEscalation(((SimpleEscalation)getEscalation()).copySimpleEscalation());
    newCC.setResaleEscalation(((SimpleEscalation)getResaleEscalation()).copySimpleEscalation());
    newCC.setPhaseIn(getPhaseIn().copyPhaseIn());
    newCC.setResaleValueFactor(getResaleValueFactor());
    newCC.setDuration(getDuration());

    for(Enumeration e=enumerateCapitalReplacements(); e.hasMoreElements();)
      newCC.addCapitalReplacement(((CapitalReplacement) e.nextElement()).copyCapitalReplacement());

    for(Enumeration e=enumerateNonRecurringCosts(); e.hasMoreElements();)
      newCC.addNonRecurringCost(((NonRecurringCost) e.nextElement()).copyNonRecurringCost());

    for(Enumeration e=enumerateRecurringCosts(); e.hasMoreElements();)
      newCC.addRecurringCost(((RecurringCost) e.nextElement()).copyRecurringCost());

    return newCC;}


  public String getPrettyName(){
    return (name.equals("") ? "Unnamed Component" : name); }



  /* ______________________________________________________________________
     IO */
  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    setInitialCost(p.parseDouble(this,"InitialCost",0.0));
    setAmountFinanced(p.parseDouble(this,"AmountFinanced",0.0));
    setStart(p.parseDateDiff(this,"Start",null));
    setEscalation((Escalation)p.parse(this,"Escalation",escalation));
    setPhaseIn((PhaseIn)p.parse(this,"PhaseIn",phaseIn));
    setResaleValueFactor(p.parseDouble(this,"ResaleValueFactor",0.0));
    setResaleEscalation((Escalation)p.parse(this,"ResaleEscalation",resaleEscalation));
    setDuration(p.parseDateDiff(this,"Duration",duration));
    setConstructionCost(p.parseDouble(this,"ConstructionCost",0.0));
    setSIOH(p.parseDouble(this,"SIOH",0.0));
    setDesignCost(p.parseDouble(this,"DesignCost",0.0));
    setSalvageValue(p.parseDouble(this,"SalvageValue",0.0));
    setUtilityRebate(p.parseDouble(this,"UtilityRebate",0.0));
    for(Enumeration e=p.getContents(this,"CapitalReplacements"); e.hasMoreElements(); )
      addCapitalReplacement((CapitalReplacement) p.parseNext(this,e));
    for(Enumeration e=p.getContents(this,"RecurringCosts"); e.hasMoreElements(); )
      addRecurringCost((RecurringCost) p.parseNext(this,e));
    for(Enumeration e=p.getContents(this,"NonRecurringCosts"); e.hasMoreElements(); )
      addNonRecurringCost((NonRecurringCost) p.parseNext(this,e));


  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatDouble(level,"InitialCost",getInitialCost(),0.0);
    fmt.formatDouble(level,"AmountFinanced",getAmountFinanced(),0.0);
    fmt.formatDateDiff(level,"Start",getStart(),defaultStart());
    fmt.formatDateDiff(level,"Duration",getDuration(),null);
    fmt.formatElement(level+1,"Escalation",getEscalation(),null);
    fmt.formatElement(level,"PhaseIn",getPhaseIn(),null);
    fmt.formatDouble(level,"ResaleValueFactor",getResaleValueFactor(),0.0);
    fmt.formatElement(level,"ResaleEscalation",resaleEscalation,null);

    fmt.formatDouble(level,"ConstructionCost",getConstructionCost(),0.0);
    fmt.formatDouble(level,"SIOH",getSIOH(),0.0);
    fmt.formatDouble(level,"DesignCost",getDesignCost(),0.0);
    fmt.formatDouble(level,"SalvageValue",getSalvageValue(),0.0);
    fmt.formatDouble(level,"UtilityRebate",getUtilityRebate(),0.0);
    fmt.formatElements(level,"CapitalReplacements",enumerateCapitalReplacements());
    fmt.formatElements(level,"RecurringCosts",enumerateRecurringCosts());
    fmt.formatElements(level,"NonRecurringCosts",enumerateNonRecurringCosts());
      }

  /* ______________________________________________________________________
     Validation */

  public void validate(boolean recursive) throws ValidationException {
    Project project = getProject();
    if (initialCost < 0.0)
      throw new ValidationException("Initial Cost can't be negative.",this,"InitialCost");
    if(!getStartDate().between(project.getBaseDate(),project.getEndDate()))
      throw new ValidationException("Start Date is not in Study Period.",
				    this,"Start");
    if (escalation != null) escalation.validate(recursive);
    // Validate Duration ???
    if ((-2.0 > resaleValueFactor) || (resaleValueFactor > +2.0))
      throw new ValidationException("Residual value factor is not between -200% and 200%.",
            this,"ResaleValueFactor");
    if (recursive){
      mapValidation(enumerateCapitalReplacements());
      mapValidation(enumerateRecurringCosts());
      mapValidation(enumerateNonRecurringCosts());}

  }

  /* ______________________________________________________________________
     Analysis */

  public void analyze(Analysis analysis) {
    Escalation esc = getEscalation();
    Escalation resc = getResaleEscalation();
    Units money=getMonetaryUnits();
    int n=phaseIn.getIntervalCount();

    analysis.addAmount(this,Category.AMOUNT_FINANCED,amountFinanced,money,getBaseDate());
    double tempAmount = constructionCost+sioh-salvageValue-utilityRebate;
    analysis.addAmount(this,Category.ECIP_TOTAL_INVESTMENT,tempAmount,money,getBaseDate());

    for(int i=0; i<n; i++){
      Date date = phaseIn.getDate(i);
      double portion = phaseIn.getPortion(i);
      analysis.addAmount(this,Category.COST_CAPITAL_INITIAL,
      esc.escalate(initialCost*portion,date),
      money,date);}

    if (resaleValueFactor != 0.0) {
      double totalAmount = initialCost+amountFinanced;  // total for residual purposes ONLY
      Date junkdate = getEndDate().min(getProject().getEndDate());
      analysis.addAmount(this, Category.COST_CAPITAL_RESIDUAL,
       //resc.escalate(-initialCost*resaleValueFactor,junkdate),
      resc.escalate(-totalAmount*resaleValueFactor,junkdate),
       money,junkdate);
        }

    // Add something here? May depend on enddate if salvaged, or residual value...
    mapAnalysis(enumerateCapitalReplacements(),analysis);
    mapAnalysis(enumerateRecurringCosts(),analysis);
    mapAnalysis(enumerateNonRecurringCosts(),analysis);
          }

}
