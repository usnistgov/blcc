package blcc.model;

import blcc.util.Date;
import blcc.analysis.Analysis;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import java.text.ParseException;
import java.util.Vector;
import java.util.Enumeration;
import blcc.util.Choosable;

/** Case represents an alternative for construction or implementation of a Project.
 */
public class Alternative extends ModelElement implements Choosable {

  public Alternative() {}
  /* ________________________________________
     Internal State */
  Vector capitalComponents = new Vector();
  Vector recurringContractCosts = new Vector();
  Vector nonRecurringContractCosts = new Vector();
  Vector energyUsages = new Vector();
  Vector waterUsages = new Vector();

  /* ________________________________________*/

  /** Add a Capital Component to the Alternative.*/
  public void addCapitalComponent(CapitalComponent component) {
    if (component != null){
      component.setOwner(this);
      capitalComponents.addElement(component); }}

  /** Add an EnergyUsage object to the alternative.*/
  public void addEnergyUsage(EnergyUsage energyUsage) {
    if(energyUsage != null){
      energyUsage.setOwner(this);
      energyUsages.addElement(energyUsage); }}

  /** Add a recurring contract cost to the alternative.*/
  public void addRecurringContractCost(RecurringContractCost cost) {
    if (cost != null){
      cost.setOwner(this);
      recurringContractCosts.addElement(cost); }}

  /** Add a non recurring contract cost to the alternative.*/
  public void addNonRecurringContractCost(NonRecurringContractCost cost) {
    if (cost != null){
      cost.setOwner(this);
      nonRecurringContractCosts.addElement(cost); }}

  /** Add a WaterUsage object to the alternative.*/
  public void addWaterUsage(WaterUsage waterUsage) {
    if(waterUsage != null){
      waterUsage.setOwner(this);
      waterUsages.addElement(waterUsage); }}

  /** Return an enumeration of all capital components in the alternative.*/
  public Enumeration enumerateCapitalComponents() {
    return capitalComponents.elements(); }

  /** Return an enumeration of the EnergyUsages of the alternative.*/
  public Enumeration enumerateEnergyUsages() {
    return energyUsages.elements(); }

  /** Return an enumeration of all recurring contract costs in the alternative.*/
  public Enumeration enumerateRecurringContractCosts() {
    return recurringContractCosts.elements(); }

  /** Return an enumeration of all non recurring contract costs in the alternative.*/
  public Enumeration enumerateNonRecurringContractCosts() {
    return nonRecurringContractCosts.elements(); }


  /** Return an enumeration of WaterUsage's of the alternative.*/
  public Enumeration enumerateWaterUsages() {
    return waterUsages.elements(); }

  /** Remove a Capital Component object from the alternative.*/
  public void removeCapitalComponent(CapitalComponent component) {
    component.setOwner(null);
    capitalComponents.removeElement(component); }

  /** Remove an EnergyUsage object from the alternative.*/
  public void removeEnergyUsage(EnergyUsage energyUsage) {
    energyUsage.setOwner(null);
    energyUsages.removeElement(energyUsage); }

  /** Remove a Recurring Contract Cost object from the alternative.*/
  public void removeRecurringContractCost(RecurringContractCost cost) {
    cost.setOwner(null);
    recurringContractCosts.removeElement(cost); }

  /** Remove a Non Recurring Contract Cost object from the alternative.*/
  public void removeNonRecurringContractCost(NonRecurringContractCost cost) {
    cost.setOwner(null);
    nonRecurringContractCosts.removeElement(cost); }


  /** Remove a WaterUsage object from the alternative.*/
  public void removeWaterUsage(WaterUsage waterUsage) {
    waterUsage.setOwner(null);
    waterUsages.removeElement(waterUsage); }

  public Alternative copyAlternative(){
    Alternative newAlt = new Alternative();
    newAlt.setName("Copy of: " + getName());
    newAlt.setComment(getComment());
    for(Enumeration e=enumerateEnergyUsages(); e.hasMoreElements();)
      newAlt.addEnergyUsage(((EnergyUsage) e.nextElement()).copyEnergyUsage());
    for(Enumeration e=enumerateWaterUsages(); e.hasMoreElements();)
      newAlt.addWaterUsage(((WaterUsage) e.nextElement()).copyWaterUsage());
    for(Enumeration e=enumerateRecurringContractCosts(); e.hasMoreElements();)
      newAlt.addRecurringContractCost(((RecurringContractCost) e.nextElement()).copyRecurringContractCost());
    for(Enumeration e=enumerateNonRecurringContractCosts(); e.hasMoreElements();)
      newAlt.addNonRecurringContractCost(((NonRecurringContractCost) e.nextElement()).copyNonRecurringContractCost());
    for(Enumeration e=enumerateCapitalComponents(); e.hasMoreElements();)
      newAlt.addCapitalComponent(((CapitalComponent) e.nextElement()).copyCapitalComponent());
    return newAlt;}

  /* ______________________________________________________________________
     IO */

  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    for(Enumeration e=p.getContents(this,"CapitalComponents"); e.hasMoreElements(); )
      addCapitalComponent((CapitalComponent) p.parseNext(this,e));
    for(Enumeration e=p.getContents(this,"EnergyUsages"); e.hasMoreElements();)
      addEnergyUsage((EnergyUsage) p.parseNext(this,e));
    for(Enumeration e=p.getContents(this,"WaterUsages"); e.hasMoreElements(); )
      addWaterUsage((WaterUsage) p.parseNext(this,e));
    for(Enumeration e=p.getContents(this,"RecurringContractCosts"); e.hasMoreElements(); )
      addRecurringContractCost((RecurringContractCost) p.parseNext(this,e));
    for(Enumeration e=p.getContents(this,"NonRecurringContractCosts"); e.hasMoreElements(); )
      addNonRecurringContractCost((NonRecurringContractCost) p.parseNext(this,e));

  }
  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatElements(level,"CapitalComponents",enumerateCapitalComponents());
    fmt.formatElements(level,"EnergyUsages",enumerateEnergyUsages());
    fmt.formatElements(level,"WaterUsages",enumerateWaterUsages());
    fmt.formatElements(level,"RecurringContractCosts",enumerateRecurringContractCosts());
    fmt.formatElements(level,"NonRecurringContractCosts",enumerateNonRecurringContractCosts());

  }
  /* ______________________________________________________________________
     Validation */

  public void validate(boolean recursive) throws ValidationException {
    if (recursive){
      mapValidation(enumerateCapitalComponents());
      mapValidation(enumerateEnergyUsages());
      mapValidation(enumerateWaterUsages());
      mapValidation(enumerateRecurringContractCosts());
      mapValidation(enumerateNonRecurringContractCosts());}

  }
   /* ______________________________________________________________________
     Analysis */

  public void analyze(Analysis analysis) {
    mapAnalysis(enumerateCapitalComponents(),analysis);
    mapAnalysis(enumerateEnergyUsages(),analysis);
    mapAnalysis(enumerateWaterUsages(),analysis);
    mapAnalysis(enumerateRecurringContractCosts(),analysis);
    mapAnalysis(enumerateNonRecurringContractCosts(),analysis);
  }

  public String getPrettyName(){
    return (name.equals("") ? "Unnamed Alternative" : name); }

}
