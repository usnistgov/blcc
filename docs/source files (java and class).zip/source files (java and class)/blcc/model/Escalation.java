package blcc.model;

import blcc.util.Date;
import blcc.analysis.Analysis;

/** An  Escalation is responsible for adjusting a cost from the BaseDate to 
	a future date,  to account for inflation and price escalation.
   */
public interface Escalation {
  /** Escalate the amount (in BaseDate dollars) to the date when,
   * accounting for both escalation and inflation. */
  public double escalate(double amount, Date when);
  /* An Escalation must also be a ModelElement */
  public void setOwner(ModelElement owner);
  public void validate(boolean recursive) throws ValidationException;
  public void analyze(Analysis analysis);
}
