package blcc.model;

import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.analysis.Analysis;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import java.text.ParseException;

/** An  Escalation is responsible for adjusting a cost from the BaseDate to
	a future date,  to account for inflation and price escalation.
   */
public class SimpleEscalation extends ModelElement implements Escalation {
  double rate = 0.0;
  /** Create an Escalation object which uses a single fixed escalation rate effective
    * over the entire study period. */
  public SimpleEscalation(){ }

  /** Create an Escalation object with a single fixed escalation rate effective
    * over the entire study period. */
  public SimpleEscalation(double rate){
    this.rate= rate; }

  // Let escalations be owned by multiple.
  public void setOwner(ModelElement owner) {
    this.owner = owner; }

  /** Escalate the amount (in BaseDate dollars) to the date when, accounting for
    * both escalation and inflation. */
  public double escalate(double amount, Date when){
		  return amount * Math.pow((1.0 + rate)*(1.0 + getEffectiveInflation()),
		      DateDiff.diffInYears(getBaseDate(), when)); }


  /** Get the escalation rate.
   * This rate is nominal if CurrentDollar analysis is in effect */
  public double getRate(){
    return (1.0 + rate)*(1.0 + getEffectiveInflation()) - 1.0; }

		//public double round (double number, int precision) {
   		//return new BigDecimal(number).setScale(precision, BigDecimal.ROUND_HALF_UP).doubleValue();}

  public double getRateWithoutInflation(){  // used when creating VaryingEscalation from SimpleEscalation; without this method, the rate can be
																						// inflated twice (once in this method and again in setValue in VaryingEscalation)
    return rate; }

  /** Set the escalation rate.
   * Give the nominal rate (if CurrentDollar analysis);
   * the real rate will be stored internally. */
  public void setRate(double rate){
    this.rate = (1.0+rate)/(1.0+ getEffectiveInflation()) - 1.0; }

  public String getDescription(){
    return new java.text.DecimalFormat("##.#%").format(rate); }

  /* Disabled Stubs. */
  public void setEscalation(Escalation escalation) {}
  public Escalation getEscalation(){ return this; }
  public void validate(boolean recursive) throws ValidationException{}
  public void analyze(Analysis analysis) {}


  public SimpleEscalation copySimpleEscalation(){
    SimpleEscalation esc = new SimpleEscalation(this.rate);
    esc.setName(this.name);
    esc.setComment(this.comment);
    return esc;}



  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    rate = p.parseDouble(this,"Rate",0.0);
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatDouble(level,"Rate",rate,0.0); }

}
