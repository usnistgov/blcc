package blcc.model;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.analysis.Analysis;
import blcc.parser.XMLIO;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import java.text.ParseException;

/** Varying represents a quantity varying discretely over time,
    with values given for a sequence of time intervals.
    The intervals can be given as sequence of DateDifferences, or default to yearly.
    The values must be supplied as an array of N+1 values,
    Values[N] applies to all times after the last interval.

    The intervals can be extended, incrementally, by replacing the last
    terminating interval (which should be DateDiff.FOREVER), by a finite value.
    (this should be done before setting the corresponding value).
*/

public class Varying extends ModelElement implements XMLIO {
  Date startDate = null;
  protected DateDiff I[] = {DateDiff.FOREVER};
  protected double V[] = {0.0};
  protected Date D[] = new Date[2];
  protected int N = 0;

  protected Date cachedate;

  public Date getStartDate(){
    return (startDate == null ? defaultStartDate() : startDate); }

  public Date defaultStartDate(){
    return getProject().getBaseDate(); }

  public void setStartDate(Date d){
    startDate = d; }

  //----------------------------------------------------------------------

  public int getIntervalCount(){
    return N; }

  public DateDiff getInterval(int i){
    if ((i < 0) || (i > N)) return DateDiff.FOREVER;
    return I[i]; }

  public DateDiff[] getIntervals(){
    return I; }

  public void setIntervals(DateDiff intervals[]){
    I=intervals;
    int n = -1;			// Find terminator (FOREVER)
    for(int i=0; i < intervals.length; i++)
      if(intervals[i]==DateDiff.FOREVER) { n=i; break; }
    if (n == -1){		// Didn't find terminator; append one.
      n = intervals.length;
      I = new DateDiff[n+1];
      for(int i=0; i<n; i++)
	I[i]=intervals[i];
      I[n]=DateDiff.FOREVER; }
    if (N < n)			// Need to extend values too.
      extendValues(n);
    N=n;
    uncache(); }

  // Extend the values array to accomodate n intervals.
  private void extendValues(int n){
    if(n+1 > V.length){	// Array too short, besides!  New array!
      double v[] = new double[n+1];
      for(int i=0; i<=N; i++) v[i]=V[i]; // copy
      V=v; }
    for(int i=N+1; i<=n; i++) V[i]=V[N]; // extend by copying last value.
    }

  public void setInterval(int i, DateDiff dur){
    if ((i < 0) || (i > N)) return;
    if (i == N){		// Changing last value?
      if(dur != DateDiff.FOREVER){ // Removing terminator? Need to extend!
	extendValues(N+1);
	if (N+2 > I.length) {	// I is too short, besides.
	  DateDiff ii[]=new DateDiff[N+2];
	  for(int j=0; j<=N; j++) ii[j]=I[j];
	  I=ii; }
	N++;
	I[i]= dur;
	I[N] = DateDiff.FOREVER;
      }}
    else if (dur == DateDiff.FOREVER){ // Possibly truncating!
      I[i]=dur;
      N=i; }
    else
      I[i]=dur;
    uncache();
  }

  //----------------------------------------------------------------------
  public double[] getValues(){
    return V; }

  public void setValues(double values[]){
    V=values;
    int n = values.length-1;
    if ((N==0) && (n > 0)){	// If I hasn't been set up yet.
      N=n;
      I = new DateDiff[N+1];
      DateDiff d = getInterval();
      for(int i=0; i<N; i++)
	I[i]=d;
      I[N]=DateDiff.FOREVER;
      uncache(); }
  }

  public double getValue(int i){
    return (i<0 ? 0.0 : V[i]); }

  public double getValue(Date date){
    return getValue(findIndex(date)); }

  public void setValue(int i, double v){
    if ((i < 0) || (i > N)) return;		// Well, what ???
    V[i]=v;
  }

  //----------------------------------------------------------------------
  public Date getDate(int i){
    cacheDates();
    return (i<0 ? null : D[i]); }

  //----------------------------------------------------------------------
  public void copyInto(Varying varying){
    double v[]=new double[N+1];
    for(int i=0; i<=N; i++)
      v[i]=V[i];
    DateDiff ii[]=new DateDiff[N+1];
    for(int i=0; i<=N; i++)
      ii[i]=I[i];
    varying.startDate = startDate;
    varying.N=N;
    varying.V=v;
    varying.I=ii;
    varying.uncache(); }

  //----------------------------------------------------------------------
  protected void uncache(){
    cachedate=null; }

  protected void cacheDates(){
    Date s=getStartDate();
    if(!s.equals(cachedate)) {
      cachedate=s;
      if (D.length < N+2) D=new Date[N+2];
      D[0]=s;
      for(int i=0; i<=N; i++)
	D[i+1]=I[i].addToDate(D[i]);
    }}

  /** Find smallest i such that date <= t[i+1]. */
  public int findIndex(Date date){
    cacheDates();
    int i=-1;
    while(!date.before(D[i+1])) i++;
    return i; }

  //----------------------------------------------------------------------

  /** Compute the sum of values between date0 and date1, weighted by
   * the portion of each time interval that is covered. */
  public double sum(Date date0, Date date1){
    int i0=findIndex(date0);
    int i1=findIndex(date1);
    double f=0;			// Compute effective factor
    Date d = date0;
    for(int i=i0; i<i1; i++){
      f += V[i]*DateDiff.diffInYears(d,D[i+1])/DateDiff.diffInYears(D[i],D[i+1]);
      d = D[i+1]; }
    // Pick up remaining portion.
    f += V[i1]*DateDiff.diffInYears(d,date1)/DateDiff.diffInYears(D[i1],D[i1+1]);
    return f; }

  /** Compute the average of the values between date0 and date1. */
  public double average(Date date0, Date date1){
    int i0=findIndex(date0);
    int i1=findIndex(date1);
    double f=0;			// Compute effective factor
    Date d = date0;
    for(int i=i0; i<i1; i++){
      f += V[i]*DateDiff.diffInYears(d,D[i+1]);
      d = D[i+1]; }
    // Pick up remaining portion.
    f += V[i1]*DateDiff.diffInYears(d,date1);
    return f/DateDiff.diffInYears(date0,date1); }

  /** Compute the escalation-like factor (1+v[i])^d[i] for values between
   * date0 and date1. */
  public double factor(Date date0, Date date1){
    int i0=findIndex(date0);
    int i1=findIndex(date1);
    double f=1.0;			// Compute effective factor
    Date d = date0;
    for(int i=i0; i<i1; i++){
      f *= Math.pow(1+V[i],DateDiff.diffInYears(d,D[i+1]));
      d = D[i+1]; }
    // Pick up remaining portion.
    f *= Math.pow(1+V[i1],DateDiff.diffInYears(d,date1));
    return f; }

  public void analyze(Analysis analysis){}

  public void validate(boolean recursive) throws ValidationException{}

  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    setStartDate(p.parseDate(this,"StartDate",null));
    setInterval(p.parseDateDiff(this,"Interval",null));
    setIntervals(p.parseDateDiffs(this,"Intervals",I));
    setValues(p.parseDoubles(this,"Values",V));
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatDate(level,"StartDate",getStartDate(),defaultStartDate());  // don't save date if it's the default start
    if (I != null)
      fmt.formatDateDiffs(level,"Intervals",I,N+1);
    else
      fmt.formatDateDiff(level,"Interval",getInterval(),defaultInterval());
    fmt.formatDoubles(level,"Values",V,N+1);
  }

}
