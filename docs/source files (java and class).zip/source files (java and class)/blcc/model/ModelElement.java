package blcc.model;

import blcc.analysis.Analysis;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import java.util.Enumeration;
import blcc.reports.Table;
import blcc.parser.XMLIO;

/** ModelElement is an abstract class which all classes used to represent a BLCC Model
  * should inherit. Model Classes are classes used to form the Model of the project.
  * Each ModelElement has an owner who is `responsible' for whether changes can be
  * made to an element.  For example, one might only be able to edit parameters on the
  * GUI page of the owner.
  */
public abstract class ModelElement implements XMLIO {
  ModelElement owner;
  Project theproject = null;
  String name = "";
  String comment = "";
  /* For the majority of ModelElements that have one. */
  Escalation escalation = null;
  DateDiff relativeStart = null;
  DateDiff duration = DateDiff.FOREVER;
  DateDiff interval = null;

  public String getType(){
    String classname = getClass().getName();
    return classname.substring(classname.lastIndexOf('.')+1); }

  /** Return the default name. */
  public String defaultName(){
    return ""; }

  /** Returns the name of the ModelElement. */
  public String getName() {
    return name; }

  /** Sets the name of the ModelElement. */
  public void setName(String newname) {
    name = newname; }

  /** Return the default Comment. */
  public String defaultComment(){
    return ""; }

  /** Returns a comment about this ModelElement. */
  public String getComment() {
    return comment; }

  /** sets a comment about this ModelElement. */
  public void setComment(String newcomment) {
    comment = newcomment; }

  /** Return the Project that this Model element is part of.
    * This normally should NOT be treated as an accessor. */
  public Project  getProject(){
    if (theproject == null)
      theproject = owner.getProject();
    return theproject; }

  /** Return the Owner of this Model element.
    * The owner of an element determines from where attributes of
    * the element can be changed in the case of a SharedModelElement.
    * This normally should NOT be treated as an accessor. */
  public ModelElement getOwner(){
    return owner; }

  /** Set the owner of this Model element.
    * This will signal an exception if the element is already owned.*/
  public void setOwner(ModelElement owner) {
    if ((owner != this.owner) && (owner != null) && (this.owner != null))
      throw new Error("Element "+this+" is already owned by "+this.owner+
		      " Cannot set to "+owner);
    this.owner = owner; }

  /** Is this element contained in element (or equal to it). */
  public boolean containedIn(ModelElement element){
    return (element == this) ||
	((owner != null) && owner.containedIn(element)); }

  /** Get the Escalation used for costs in this ModelElement.
    * It describes the average annual rate at which cost is
    * expected to change throughout the study period.
    * Includes inflation rate if the study is performed in current dollars. */
  public Escalation getEscalation() {
    return escalation; }

  /** Set the Escalation used for this costs in this ModelElement.*/
  public void setEscalation(Escalation escalation) {
    if(escalation != null) escalation.setOwner(this);
    this.escalation = escalation; }

  /** Get the Discount rate that applies to costs in this element.
    * Typically (always?) defaults to that of the containing Project. */
  public double getDiscountRate(){
    return getProject().getDiscountRate(); }

  /** Get the Inflation rate that applies to costs in this element.
    * Typically (always?) defaults to that of the containing Project. */
  public double getInflationRate(){
    return getProject().getInflationRate(); }

  /** Get the Effective Inflation rate that applies to costs in this element.
    * This gets the Project's inflation rate, or 0% for Constant Dollar analysis. */
  public double getEffectiveInflation(){
    return getProject().getEffectiveInflation(); }

  /** Get the Monetary Units that costs in this element are expressed in.
    * Typically (always?) defaults to that of the containing Project. */
  public Units getMonetaryUnits() {
    return getProject().getMonetaryUnits(); }

  public Units getUnitCostMonetaryUnits() {
   if (getMonetaryUnits() == Units.USDOLLAR)
     return Units.USUNIT;
   else return getProject().getMonetaryUnits(); }

  /** Get the BaseDate rate that applies to events in this element.
    * Typically (always?) defaults to that of the containing Project. */
  public Date getBaseDate(){
    return getProject().getBaseDate(); }

  /** Get the reference date for this object (default is project's ServiceDate).
    * The reference date is the date against which relative dates (DateDiff)
    * are resolved for this ModelElement.  */
  public Date getReferenceDate (){
    return getProject().getServiceDate(); }

  /** Get the `Starting' date of activities (if any) associated with this element.
    * The start is (relative to ReferenceDate. */
  public DateDiff getStart(){
    return (relativeStart != null ? relativeStart : defaultStart()); }

  /** Get the default `Starting' date of activities (if any) associated with this
    * element. The start is (relative to ReferenceDate. */
  public DateDiff defaultStart(){
    return DateDiff.ZERO; }

  /** Set the `Starting' date of activities (if any) associated with this element.
    * The start is (relative to ReferenceDate. */
  public void setStart(DateDiff start){
    if((start==null) || (start == defaultStart())) relativeStart=null;
    else relativeStart = start; }

  /** Get the absolute `Starting' date for activities (if any) associated with this
    * element.  If no relative start has been specified: defaults to the
    * Reference Date. */
  public Date getStartDate(){
    return (getStart().addToDate(getReferenceDate())); }

  /** Get the Duration or lifetime of activity (if any) for this element,
    * beginning with Start date.*/
  public DateDiff getDuration(){
    return duration; }

  /** Set the Duration or lifetime of activity (if any) for this element,
    * beginning with Start date.*/
  public void setDuration(DateDiff duration){
    this.duration = duration; }

  /** Get the absolute `Ending' date for activity (if any) in this element.
   * It is computed from the start date and duration, if given, or defaults
   * to the project's end date.*/
  public Date getEndDate(){
    return (duration == null ? getProject().getEndDate() :
	    duration.addToDate(getStartDate())); }

  /** Get the default interval of activity for elements with periodic activities.*/
  public DateDiff defaultInterval(){
    return DateDiff.YEAR; }

  /** Get the interval of activity for elements with periodic activities.*/
  public DateDiff getInterval(){
    return (interval != null ? interval : defaultInterval()); }

  /** Set the interval of activity for elements with periodic activities.*/
  public void setInterval(DateDiff interval){
    if((interval==null) || (interval == defaultInterval()))
      this.interval = null;
    else
      this.interval = interval; }

  public void describe(Table desc, int level, boolean recursive){
    String classname = getClass().getName();
    classname = classname.substring(classname.lastIndexOf('.')+1);

    desc.addRow(level,classname,Table.ROWHEADING,name,Table.LEFT);
    desc.addRow(level+1,"Comment",Table.ROWHEADING,comment,Table.LEFT);
  }

  public abstract void validate(boolean recursive) throws ValidationException;

  /** Convenience method to (recursively) validate children elements. */
  public void mapValidation(Enumeration enum1) throws ValidationException {
    for( ; enum1.hasMoreElements() ; )
      ((ModelElement) enum1.nextElement()).validate(true);
  }

  public abstract void analyze(Analysis analysis);

  /** Convenience method to (recursively) analyze children elements. */
  public void mapAnalysis(Enumeration enum1, Analysis analysis) {
    for( ; enum1.hasMoreElements() ; )
      ((ModelElement) enum1.nextElement()).analyze(analysis);
  }

}


