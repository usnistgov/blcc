package blcc.model;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.analysis.Analysis;
import blcc.parser.XMLIO;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import java.text.ParseException;

public class PhaseIn extends ModelElement implements XMLIO {
  protected DateDiff intervals[] = {DateDiff.ZERO};
  protected double portions[] = {1.0};
  protected Date dates[] = new Date[1];
  protected int N = 1;

  protected Date cachedate;

  public Date getStartDate(){
    return getProject().getBaseDate();}

  //----------------------------------------------------------------------

  public int getIntervalCount(){
    return N; }

  public DateDiff getInterval(int i){
    return ((i < 0) || (i >= N) ? null : intervals[i]); }

  public DateDiff[] getIntervals(){
    return intervals; }

  public void setIntervals(DateDiff ints[]){
    if(ints.length < N){
      intervals = new DateDiff[N];
      for(int i=0; i<ints.length; i++)
	intervals[i]=ints[i];
      for(int i=ints.length; i<N; i++)
	intervals[i]=getInterval();
    }
    else
      intervals = ints;
    uncache(); }

  public void setInterval(int i, DateDiff dur){
    if ((i < 0) || (i > N)) return;
    intervals[i]=dur;
    uncache();
  }

  //----------------------------------------------------------------------
  public double[] getPortions(){
    return portions; }

  public void setPortions(double portions[]){
    this.portions=portions;
    N=portions.length;
    adjustPortions(); }

  public double getPortion(int i){
    return ((i<0) || (i >= N) ? 0.0 : portions[i]); }

  public double getPortion(Date date){
    return getPortion(findIndex(date)); }

  public void setPortion(int i, double v){
    if ((i < 0) || (i >= N)) return;    // Well, what ???
    portions[i]=v;
    adjustPortions(); }

  //----------------------------------------------------------------------

  public Date getDate(int i){
    cacheDates();
    return ((i<0) || (i>=N) ? null : dates[i]); }
  //----------------------------------------------------------------------
  void adjustPortions(){
    double sum = 0.0;
    for(int i=0; i<N; i++)
      sum += portions[i];
    if(sum > 1.0){		// Too much! gotta shorten.
     double x=sum-1.0;
     for( ; (N > 0) && (sum > 1.0);) {
       if(portions[N-1]> x){ portions[N-1]-= x; sum-=x; x=0.0;}
       else { x -= portions[N-1]; sum-=portions[N-1]; portions[N-1]=0.0;  N--;}
      }
    }
    else if(sum < 1.0){		// Too little, gotta extend
      if(portions.length < N+1) { // Extend arrays, if needed.
	double p[]=new double[N+1];
	for(int i=0; i<N; i++)
	  p[i]=portions[i];
	portions=p; }
      if(intervals.length < N+1){
	DateDiff ii[]=new DateDiff[N+1];
	for(int i=0; i<N; i++)
	  ii[i]=intervals[i];
	intervals = ii; }
      N++;			// Now add extra element.
      portions[N-1]=1.0-sum;
      intervals[N-1]=getInterval();
      uncache();
    }
  }
  //----------------------------------------------------------------------
  protected void uncache(){
    cachedate=null; }

  protected void cacheDates(){
    Date d=getStartDate();
    if(!d.equals(cachedate)) {
      cachedate=d;
      if(dates.length < N) dates= new Date[N];
      for(int i=0; i<N; i++)
	dates[i]= ( d=intervals[i].addToDate(d));
    }}

  /** Find smallest i such that date <= t[i+1]. */
  public int findIndex(Date date){
    cacheDates();
    int i=0;
    while((i<N) && !date.before(dates[i])) i++;
    return i; }

  public PhaseIn copyPhaseIn(){
    PhaseIn newPI = new PhaseIn();
    newPI.setName(getName());
    newPI.setComment(getComment());

    double[] port = new double[getPortions().length];
    for ( int i=0; i<port.length; i++ )
    {port[i] = getPortions()[i]; }
    newPI.setPortions(port);

    DateDiff[] intev = new DateDiff[getIntervals().length];
    for ( int i=0; i<intev.length; i++ )
    {intev[i] = getIntervals()[i]; }
    newPI.setIntervals(intev);

    newPI.setInterval(getInterval());

    return newPI;}



  public void analyze(Analysis analysis){}

  public void validate(boolean recursive) throws ValidationException{}

  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    //setStartDate(p.parseDate(this,"StartDate",null));
    setPortions(p.parseDoubles(this,"Portions",portions));
    setInterval(p.parseDateDiff(this,"Interval",null));
    setIntervals(p.parseDateDiffs(this,"Intervals",intervals));
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    //fmt.formatDate(level,"StartDate",getStartDate(),null);
    fmt.formatDoubles(level,"Portions",portions,N);
    fmt.formatDateDiffs(level,"Intervals",intervals,N);
  }
}
