package blcc.model;

import blcc.analysis.Analysis;
import blcc.analysis.Category;
import blcc.util.Units;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.FuelType;
import blcc.util.Emissions;
import blcc.util.DOEPrices;
import blcc.util.EmissionsRates;
import blcc.parser.XMLParser;
import blcc.util.Choosable;
import blcc.parser.XMLFormatter;
import java.text.ParseException;
import java.text.DecimalFormat;
import java.awt.*;


/** EnergyUsage represents a usage of energy within a case or component.
    It is responsible for determining the energy usage during each
    time interval of the study period, as well as the cost and emissions.
*/
public class EnergyUsage extends ModelElement implements Choosable {

  FuelType fueltype = null;
  Units units = Units.KWH;
  // Usage related variables
  double yearlyUsage = 0.0;
  UsageIndex usageIndex;

  // Cost related variables.
  double demandCharge = 0.0;
  double utilityRebate = 0.0;
  String state;
  String rateSchedule;
  double unitCost=0.0;

  // Emissions related variables
  Emissions emissions = null;

  VaryingEscalation defaultEscalation = null;

  public EnergyUsage() {
    setUsageIndex(UsageIndex.createUsageIndex());}

  /** Return the type energy used. */
  public FuelType getFuelType(){
    return fueltype; }

  /** Return the type of energy used. */
  public void setFuelType(FuelType fueltype){
    defaultEscalation = null;
    this.fueltype = fueltype; }

  /** Return the name of the units used. */
  public Units getUnits(){
    return units; }

  /** Return the name of the units used. */
  public void setUnits(Units units){
    this.units = units; }

  // ----------------------------------------------------------------------
  // Usage related accessors

  /** Return the number of units used yearly. */
  public double getYearlyUsage() {
    return yearlyUsage; }

  /** Set the number of units used yearly. */
  public void setYearlyUsage(double usage){
    yearlyUsage = usage; }

  /** Return the usage index for this energy. */
  public UsageIndex getUsageIndex(){
      return usageIndex; }

  /** Return the usage index for this energy. */
  public void setUsageIndex(UsageIndex usageIndex){
    if (usageIndex != null)
      usageIndex.setOwner(this);
    this.usageIndex = usageIndex; }

  // ----------------------------------------------------------------------
  // Cost related accessors

  public double getUnitCost(){
    return unitCost; }

  public void setUnitCost(double cost){
    unitCost=cost; }

  /** Get the state this fuel will be used in, for pricing & emissions.*/
  public String getState(){
    return (state == null ? getProject().getLocation() : state); }

  /** Set the state this fuel will be used in, for pricing & emissions.*/
  public void setState(String state){
    defaultEscalation = null;
    this.state=state; }

  /** Get the RateSchedule to be used for pricing.*/
  public String getRateSchedule(){
    return (rateSchedule == null ? DOEPrices.defaultRateSchedule(fueltype)
      : rateSchedule); }

  /** Set the RateSchedule to be used for pricing.*/
  public void setRateSchedule(String schedule){
    defaultEscalation = null;
    this.rateSchedule=schedule; }

  /** Get the set of RateSchedule that apply for this fuel.*/
  public String[] getRateSchedules() {
    return DOEPrices.getRateSchedules(fueltype); }

  public Escalation defaultEscalation(){
    // Cache a copy so we dont recreate it everytime we're asked.
    if (defaultEscalation == null){
      defaultEscalation = DOEPrices.getEscalation(fueltype,getState(),getRateSchedule());
      if (defaultEscalation != null)
	defaultEscalation.setOwner(this); }
    return defaultEscalation; }

  public Escalation getEscalation() {
    return (escalation != null ? escalation : defaultEscalation()); }

  /** Set the Escalation used for this costs in this ModelElement.*/
  public void setEscalation(Escalation escalation) {
    if(escalation != null) escalation.setOwner(this);
    if((escalation == null) || (escalation == defaultEscalation()))
      this.escalation =null;
    else
      this.escalation = escalation; }

  /** Return the annual demand charge. */
  public double getDemandCharge() {
    return demandCharge; }

  /** Set the annual demand charge. */
  public void setDemandCharge(double charge){
    demandCharge = charge; }

  /** Return the annual utility rebate. */
  public double getUtilityRebate() {
    return utilityRebate; }

  /** Set the annual utility rebage. */
  public void setUtilityRebate(double rebate){
    utilityRebate = rebate; }

  // ----------------------------------------------------------------------
  // Emissions related accessors

  public Emissions getEmissions(){
    return (emissions == null ? defaultEmissions() : emissions); }

  public void setEmissions(Emissions emissions){
    this.emissions = emissions; }

  public Emissions defaultEmissions(){
    return  EmissionsRates.defaultEmissions(fueltype); }

  public Emissions[] getEmissionsChoices(){
    return EmissionsRates.getEmissionsChoices(fueltype); }

  public EnergyUsage copyEnergyUsage(){
    EnergyUsage newEU = new EnergyUsage();
    newEU.setFuelType(getFuelType());
    newEU.setName("Copy of: " + getName());
    newEU.setComment(getComment());
    newEU.setStart(getStart());
    newEU.setDuration(getDuration());
    newEU.setInterval(getInterval());
    newEU.setYearlyUsage(getYearlyUsage());
    newEU.setUnits(getUnits());
    newEU.setUnitCost(getUnitCost());
    newEU.setDemandCharge(getDemandCharge());
    newEU.setDemandCharge(getDemandCharge());
    newEU.setUtilityRebate(getUtilityRebate());

    UsageIndex newIndex = getUsageIndex().copy();
    newEU.setUsageIndex(newIndex);

    newEU.setState(getState());
    newEU.setRateSchedule(getRateSchedule());

		if (getEscalation() != defaultEscalation()){    // 	if default, no need to copy
			VaryingEscalation newEsc = ((VaryingEscalation)getEscalation()).copy();
			newEsc.setName(((VaryingEscalation)getEscalation()).getName());
      newEU.setEscalation(newEsc);}

    newEU.setEmissions(getEmissions());
    return newEU;}

  public String getPrettyName(){
    return (name.equals("") ? "Unnamed Cost" : name); }



  /* ______________________________________________________________________
     IO */

  public void parseXMLFields(XMLParser p) throws ParseException {
    setFuelType((FuelType)p.parseChoice(this,"FuelType",
					FuelType.allFuels(),null));
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    setStart(p.parseDateDiff(this,"Start",null));
    setDuration(p.parseDateDiff(this,"Duration",null));
    setInterval(p.parseDateDiff(this,"Interval",null));
    setYearlyUsage(p.parseDouble(this,"YearlyUsage",0.0));
    setUnits((Units)p.parseChoice(this,"Units",fueltype.getUnits(),null));
    setUnitCost(p.parseDouble(this,"UnitCost",0.0));
    setDemandCharge(p.parseDouble(this,"DemandCharge",0.0));
    setUtilityRebate(p.parseDouble(this,"UtilityRebate",0.0));
    setUsageIndex((UsageIndex)p.parse(this,"UsageIndex",getUsageIndex()));

    setState(p.parseString(this,"State",""));
    setRateSchedule(p.parseString(this,"RateSchedule",""));
    setEscalation((Escalation)p.parse(this,"Escalation",defaultEscalation()));
    // starting in version 5.3-10, only states are used for emissions with electricity; some users
    // may still have a region or US Average saved in a project file; check here to see if ParseException
    // is thrown, if so, use the default emissions
    try{setEmissions((Emissions)p.parseChoice(this,"Emissions",
					  getEmissionsChoices(),
					  defaultEmissions()));}
    catch (ParseException pe){setEmissions(defaultEmissions());}

  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatChoice(level,"FuelType",getFuelType(),null);
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatDateDiff(level,"Start",getStart(),defaultStart());
    fmt.formatDateDiff(level,"Duration",getDuration(),null);
    fmt.formatDateDiff(level,"Interval",getInterval(),defaultInterval());
    fmt.formatDouble(level,"YearlyUsage",getYearlyUsage(),0.0);
    fmt.formatChoice(level,"Units",getUnits(),null);
    fmt.formatDouble(level,"UnitCost",getUnitCost(),0.0);
    fmt.formatDouble(level,"DemandCharge",getDemandCharge(),0.0);
    fmt.formatDouble(level,"UtilityRebate",getUtilityRebate(),0.0);
    fmt.formatElement(level,"UsageIndex",getUsageIndex(),null);
    fmt.formatString(level,"State",getState(),"");
    fmt.formatString(level,"RateSchedule",getRateSchedule(),"");
    fmt.formatElement(level,"Escalation",getEscalation(),defaultEscalation());
    fmt.formatChoice(level,"Emissions",getEmissions(),defaultEmissions());
  }

  /* ______________________________________________________________________
     Validation */

  public void validate(boolean recursive) throws ValidationException {
    /*    if(!Category.RESOURCE_USAGE_ENERGY.isValidUnits(units))
      throw new ValidationException("Not a valid Unit for Energy."+units,
				    this,"Units");
    */
  }
  /* ______________________________________________________________________
     Analysis Section */

  public void analyze(Analysis analysis) {
    int method = getProject().getDiscountingMethod();
    Date date  = getStartDate();
    Date end   = getEndDate().min(getProject().getEndDate());
    DateDiff interval = getInterval();
    Units money = getMonetaryUnits();
    Escalation esc = getEscalation();
    Emissions emissions=getEmissions();
    double co2f = emissions.getCO2Factor();
    double soxf = emissions.getSOxFactor();
    UsageIndex soxIndex = emissions.getSOxIndex();
    double noxf = emissions.getNOxFactor();
    double factor=emissions.conversionFactor(units);
    double toGJ  =emissions.conversionFactor(Units.GJ);
    double demand = demandCharge;
    double rebate = utilityRebate;
    double usage=0.0;
    double soxUsage=0.0;

    while(date.before(end)){
      Date next = date.add(interval).min(end);

      if(usageIndex != null){
        usage = usageIndex.indexedAmount(yearlyUsage,date,next);
        demand = usageIndex.indexedAmount(demandCharge,date,next);
        rebate = usageIndex.indexedAmount(utilityRebate,date,next); }

      // Usage in the fuel's standard units.
      double stdusage = usage*factor;
      // Effective date depending on the Discounting method.
      if (method == Project.ENDYEARDISCOUNTING)   date = next.previousDay();
      else if(method==Project.MIDYEARDISCOUNTING) date = date.midpoint(next);

      // Record the usage.
      analysis.addAmount(this,Category.RESOURCE_USAGE_ENERGY,
			 stdusage/toGJ,Units.GJ,date);

      // Record the emissions.
      analysis.addAmount(this,Category.EMISSIONS_CO2,
       co2f*stdusage,Units.KG,date);

       if(soxIndex !=null)
         soxUsage = soxIndex.indexedAmount(stdusage,date,next);
       else soxUsage = stdusage;

       analysis.addAmount(this,Category.EMISSIONS_SOx,
       //soxf*stdusage,Units.KG,date);
       soxf*soxUsage,Units.KG,date);

      analysis.addAmount(this,Category.EMISSIONS_NOx,
			 noxf*stdusage,Units.KG,date);

      FuelType fuelType = getFuelType();
      int numberOfFuels = FuelType.FUELS.length;
      for (int i=0; i < numberOfFuels; i++)
        if (fuelType == FuelType.FUELS[i]){
          analysis.addAmount(this,Category.SUBCONSUMPTION[i],
          esc.escalate(usage*unitCost,date), money,date);
          break;}

			//analysis.addAmount(this,Category.COST_OMR_ENERGY_CONSUMPTION,
      // esc.escalate(usage*unitCost,date),
      // money,date);

      analysis.addAmount(this,Category.COST_OMR_ENERGY_DEMAND,
       esc.escalate(demand,date),
       money,date);


			if (getProject().getAnalysisType() !=Project.MILCONECIPANALYSIS){rebate = -rebate;}  // asr 10-23-11 rebate is negative unless it is an ECIP project

			analysis.addAmount(this,Category.COST_OMR_ENERGY_REBATE,
       esc.escalate(rebate,date),
       money,date);

      date = next;
    }
  }
}
