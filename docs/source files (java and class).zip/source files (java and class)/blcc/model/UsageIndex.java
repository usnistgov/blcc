package blcc.model;
import blcc.util.Date;

public class UsageIndex extends Varying {
  public UsageIndex(){}

  public static UsageIndex createUsageIndex(){
    UsageIndex ui=new UsageIndex();
    ui.setValue(0,1.0);
    return ui; }

  public Date defaultStartDate(){
    return getProject().getServiceDate(); }

  public double indexedAmount(double amount, Date date0, Date date1){
    return amount*average(date0,date1); }

  public UsageIndex copy(){
    UsageIndex index = new UsageIndex();
    copyInto(index);
    return index; }

}
