package blcc.model;

import blcc.util.Units;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Choosable;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import java.text.ParseException;


public class CapitalReplacement extends CapitalComponent implements Choosable{
  public CapitalReplacement(){
    relativeStart = DateDiff.ZERO;}

  public DateDiff defaultStart(){
    CapitalComponent parent = (CapitalComponent) owner;
    DateDiff life = (parent == null ? null : parent.getDuration());
     return (life == null ? null : parent.getStart().add(life)); }

 //public Date getReferenceDate (){
   // return getProject().getServiceDate(); }

  public void validate(boolean recursive) throws ValidationException {
	//super.validate(recursive);   test here to customize error message for GUI
	Project p = getProject();
  //if(!getStartDate().between(p.getBaseDate(),p.getEndDate()))
    //throw new ValidationException("Start is not in Study Period.",this,"Start");
	if(0.0 > getInitialCost())
    throw new ValidationException("Amount can't be negative.",this,"Amount");
  if (capitalReplacements.size() > 0)
      throw new ValidationException("A Replacement cannot have Replacements!",
				    this,"CapitalReplacement"); }

  public void analyze(Analysis analysis) {
    Units money=getMonetaryUnits();

    Date date = getStartDate();
     analysis.addAmount(this,Category.COST_CAPITAL_REPLACEMENT,
     getEscalation().escalate(initialCost,date),money,date);
    //analysis.addAmount(this,Category.FINANCEABLE, amt, money,date);

    if (resaleValueFactor != 0.0) {
      Date junkdate = getEndDate().min(getProject().getEndDate());
      analysis.addAmount(this, Category.COST_CAPITAL_REPLACEMENT_RESIDUAL,
       getEscalation().escalate(-initialCost*resaleValueFactor,junkdate),
			 money,junkdate); }

    // Add something here? May depend on enddate if salvaged, or residual value...
    mapAnalysis(enumerateRecurringCosts(),analysis);
    mapAnalysis(enumerateNonRecurringCosts(),analysis);
  }

  public CapitalReplacement copyCapitalReplacement(){
    CapitalReplacement newCR = new CapitalReplacement();
    newCR.setName("Copy of: " + getName());
    newCR.setInitialCost(getInitialCost());
    newCR.setStart(getStart());
    newCR.setEscalation(((SimpleEscalation)getEscalation()).copySimpleEscalation());
    newCR.setResaleValueFactor(getResaleValueFactor());
    newCR.setDuration(getDuration());
    return newCR;}

  public String getPrettyName(){
    return (name.equals("") ? "Unnamed Cost" : name); }



  /* ______________________________________________________________________
     IO */
  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setInitialCost(p.parseDouble(this,"InitialCost",0.0));
    setStart(p.parseDateDiff(this,"Start",null));
    setEscalation((Escalation)p.parse(this,"Escalation",escalation));
    setResaleValueFactor(p.parseDouble(this,"ResaleValueFactor",0.0));
    setDuration(p.parseDateDiff(this,"Duration",duration));
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatDouble(level,"InitialCost",getInitialCost(),0.0);
    fmt.formatDateDiff(level,"Start",getStart(),defaultStart());
    fmt.formatDateDiff(level,"Duration",getDuration(),null);
    fmt.formatElement(level+1,"Escalation",getEscalation(),null);
    fmt.formatDouble(level,"ResaleValueFactor",getResaleValueFactor(),0.0);
   }

}
