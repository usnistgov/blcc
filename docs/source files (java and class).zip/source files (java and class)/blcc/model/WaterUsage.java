package blcc.model;

import blcc.util.Units;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Choosable;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import java.text.ParseException;
/**
	A WaterUsage represents usage of water by a Case or Component. */
public class WaterUsage extends ModelElement implements Choosable{

  double winterYearlyUsage = 0.0;
  double summerYearlyUsage = 0.0;
  double winterYearlyDisposal = 0.0;
  double summerYearlyDisposal = 0.0;
  double winterUsageUnitCost = 0.0;
  double summerUsageUnitCost = 0.0;
  double winterDisposalUnitCost = 0.0;
  double summerDisposalUnitCost = 0.0;
  Units units = Units.LITER;
  Escalation usageEscalation = null;
  Escalation disposalEscalation = null;
  UsageIndex usageIndex;
  UsageIndex disposalIndex;

  /** Create a WaterUsage object */
  public WaterUsage(){
    setUsageIndex(UsageIndex.createUsageIndex());
    setDisposalIndex(UsageIndex.createUsageIndex());
    setUsageEscalation(new VaryingEscalation());
    setDisposalEscalation(new VaryingEscalation());}

  /** Return the number of units of water used yearly at Summer Rates. */
  public double getSummerYearlyUsage() {
    return summerYearlyUsage; }

  /** Set the number of units of water used yearly at Summer Rates. */
  public void setSummerYearlyUsage(double usage){
    summerYearlyUsage = usage; }

  /** Return the number of units of water used yearly at Winter Rates. */
  public double getWinterYearlyUsage() {
    return winterYearlyUsage; }

  /** Set the number of units of water used yearly at Winter Rates. */
  public void setWinterYearlyUsage(double usage){
    winterYearlyUsage = usage; }

  /** Return the name of the water units used. */
  public Units getUnits(){
    return units; }

  /** Return the name of the water units used. */
  public void setUnits(Units units){
    this.units = units; }

  /** Return the unit cost of water usage at Summer Rates. */
  public double getSummerUsageUnitCost() {
    return summerUsageUnitCost; }

  /** Set the unit cost of water usage at Summer Rates. */
  public void setSummerUsageUnitCost(double cost){
    summerUsageUnitCost = cost; }

  /** Return the unit cost of water usage at Winter Rates. */
  public double getWinterUsageUnitCost() {
    return winterUsageUnitCost; }

  /** Set the unit cost of water usage at Winter Rates. */
  public void setWinterUsageUnitCost(double cost){
    winterUsageUnitCost = cost; }

  /** Return the number of units of water disposed yearly at Summer Rates. */
  public double getSummerYearlyDisposal() {
    return summerYearlyDisposal; }

  /** Set the number of units of water disposed yearly at Summer Rates. */
  public void setSummerYearlyDisposal(double disposal){
    summerYearlyDisposal = disposal; }

  /** Return the number of units of water disposed yearly at Winter Rates. */
  public double getWinterYearlyDisposal() {
    return winterYearlyDisposal; }

  /** Set the number of units of water disposed yearly at Winter Rates. */
  public void setWinterYearlyDisposal(double disposal){
    winterYearlyDisposal = disposal; }

  /** Return the unit cost of water disposal at Summer Rates. */
  public double getSummerDisposalUnitCost() {
    return summerDisposalUnitCost; }

  /** Set the unit cost of water disposal at Summer Rates. */
  public void setSummerDisposalUnitCost(double cost){
    summerDisposalUnitCost = cost; }

  /** Return the unit cost of water disposal at Winter Rates. */
  public double getWinterDisposalUnitCost() {
    return winterDisposalUnitCost; }

  /** Set the unit cost of water disposal at Winter Rates. */
  public void setWinterDisposalUnitCost(double cost){
    winterDisposalUnitCost = cost; }

  /** Get the escalation rate used for water usage.*/
  public Escalation getUsageEscalation(){
    return usageEscalation; }

  /** Set the escalation rate used for water usage.*/
  public void setUsageEscalation(Escalation usageEscalation){
    if(usageEscalation != null)
      usageEscalation.setOwner(this);
    this.usageEscalation = usageEscalation; }

  /** Get the escalation rate used for water disposal.*/
  public Escalation getDisposalEscalation(){
    return disposalEscalation; }

  /** Set the escalation rate used for water disposal.*/
  public void setDisposalEscalation(Escalation disposalEscalation){
    if(disposalEscalation != null)
      disposalEscalation.setOwner(this);
    this.disposalEscalation = disposalEscalation; }

  /** Get the Usage Index used for computing yearly usage costs. */
  public UsageIndex getUsageIndex(){
    return usageIndex; }
  /** Set the Usage Index used for computing yearly usage costs. */
  public void setUsageIndex(UsageIndex index){
    if(index != null)
      index.setOwner(this);
    this.usageIndex = index; }

  /** Get the Disposal Index used for computing yearly disposal costs. */
  public UsageIndex getDisposalIndex(){
    return disposalIndex; }
  /** Set the Disposal Index used for computing yearly disposal costs. */
  public void setDisposalIndex(UsageIndex index){
    if(index != null)
      index.setOwner(this);
    this.disposalIndex = index; }

  public WaterUsage copyWaterUsage(){
    WaterUsage newWU = new WaterUsage();
    newWU.setName("Copy of: " + getName());
    newWU.setComment(getComment());
    newWU.setUnits(getUnits());
    newWU.setWinterYearlyUsage(getWinterYearlyUsage());
    newWU.setWinterYearlyDisposal(getWinterYearlyDisposal());
    newWU.setWinterUsageUnitCost(getWinterUsageUnitCost());
    newWU.setWinterDisposalUnitCost(getWinterDisposalUnitCost());
    newWU.setSummerYearlyUsage(getSummerYearlyUsage());
    newWU.setSummerYearlyDisposal(getSummerYearlyDisposal());
    newWU.setSummerUsageUnitCost(getSummerUsageUnitCost());
    newWU.setSummerDisposalUnitCost(getSummerDisposalUnitCost());

    VaryingEscalation newEsc = ((VaryingEscalation) getUsageEscalation()).copy();
    newWU.setUsageEscalation(newEsc);

    newEsc = ((VaryingEscalation) getDisposalEscalation()).copy();
    newWU.setDisposalEscalation(newEsc);

    UsageIndex newIndex = getUsageIndex().copy();
    newWU.setUsageIndex(newIndex);

    newIndex = getDisposalIndex().copy();
    newWU.setDisposalIndex(newIndex);

    return newWU;}

  public String getPrettyName(){
    return (name.equals("") ? "Unnamed Cost" : name); }





  /* ______________________________________________________________________
     IO */
  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    setUnits((Units)p.parseChoice(this,"Units",Units.VOLUMES,null));
    setWinterYearlyUsage(p.parseDouble(this,"WinterYearlyUsage",0.0));
    setWinterYearlyDisposal(p.parseDouble(this,"WinterYearlyDisposal",0.0));
    setWinterUsageUnitCost(p.parseDouble(this,"WinterUsageUnitCost",0.0));
    setWinterDisposalUnitCost(p.parseDouble(this,"WinterDisposalUnitCost",0.0));
    setSummerYearlyUsage(p.parseDouble(this,"SummerYearlyUsage",0.0));
    setSummerYearlyDisposal(p.parseDouble(this,"SummerYearlyDisposal",0.0));
    setSummerUsageUnitCost(p.parseDouble(this,"SummerUsageUnitCost",0.0));
    setSummerDisposalUnitCost(p.parseDouble(this,"SummerDisposalUnitCost",0.0));
    setUsageEscalation((Escalation)p.parse(this,"UsageEscalation",usageEscalation));
    setDisposalEscalation((Escalation)p.parse(this,"DisposalEscalation",disposalEscalation));
    setUsageIndex((UsageIndex)p.parse(this,"UsageIndex",getUsageIndex()));
    setDisposalIndex((UsageIndex)p.parse(this,"DisposalIndex",getDisposalIndex()));
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatChoice(level,"Units",getUnits(),null);
    fmt.formatDouble(level,"WinterYearlyUsage",getWinterYearlyUsage(),0.0);
    fmt.formatDouble(level,"WinterYearlyDisposal",getWinterYearlyDisposal(),0.0);
    fmt.formatDouble(level,"WinterUsageUnitCost",getWinterUsageUnitCost(),0.0);
    fmt.formatDouble(level,"WinterDisposalUnitCost",getWinterDisposalUnitCost(),0.0);
    fmt.formatDouble(level,"SummerYearlyUsage",getSummerYearlyUsage(),0.0);
    fmt.formatDouble(level,"SummerYearlyDisposal",getSummerYearlyDisposal(),0.0);
    fmt.formatDouble(level,"SummerUsageUnitCost",getSummerUsageUnitCost(),0.0);
    fmt.formatDouble(level,"SummerDisposalUnitCost",getSummerDisposalUnitCost(),0.0);
    fmt.formatElement(level,"UsageEscalation",getUsageEscalation(),null);
    fmt.formatElement(level,"DisposalEscalation",getDisposalEscalation(),null);
    fmt.formatElement(level,"UsageIndex",getUsageIndex(),null);
    fmt.formatElement(level,"DisposalIndex",getDisposalIndex(),null);
  }


  /* ______________________________________________________________________
     Validation */

  public void validate(boolean recursive) throws ValidationException {
    if(!Category.RESOURCE_USAGE_WATER.isValidUnits(units))
      throw new ValidationException("Not a valid Unit for Water Usage."+units,
				    this,"Units");
    if(!Category.EMISSIONS_WASTEWATER.isValidUnits(units))
      throw new ValidationException("Not a valid Unit for Water Disposal."+units,
				    this,"Units");
  }

  /* ______________________________________________________________________
     Analysis section */

  public void analyze(Analysis analysis) {
    int method = getProject().getDiscountingMethod();
    Date date  = getStartDate();
    Date end   = getEndDate().min(getProject().getEndDate());
    DateDiff interval = getInterval();

    double summerUsage=0.0;
    double winterUsage=0.0;
    double summerDisposal=0.0;
    double winterDisposal=0.0;

    while(date.before(end)){
      Date next = date.add(interval).min(end);
      if(usageIndex != null) {
       summerUsage = usageIndex.indexedAmount(summerYearlyUsage,date,next);
       winterUsage = usageIndex.indexedAmount(winterYearlyUsage,date,next); }
      if(disposalIndex != null) {
       summerDisposal = disposalIndex.indexedAmount(summerYearlyDisposal,date,next);
       winterDisposal = disposalIndex.indexedAmount(winterYearlyDisposal,date,next); }

      if (method == Project.ENDYEARDISCOUNTING)   date = next.previousDay();
      else if(method==Project.MIDYEARDISCOUNTING) date = date.midpoint(next);

      analysis.addAmount(this,Category.RESOURCE_USAGE_WATER, summerUsage,units,date);
      analysis.addAmount(this,Category.RESOURCE_USAGE_WATER, winterUsage,units,date);
      analysis.addAmount(this,Category.EMISSIONS_WASTEWATER, summerDisposal,units,date);
      analysis.addAmount(this,Category.EMISSIONS_WASTEWATER, winterDisposal,units,date);
      analysis.addAmount(this,Category.COST_OMR_WATER, usageEscalation.escalate(summerUsage*summerUsageUnitCost,date),
			 getMonetaryUnits(),date);
      analysis.addAmount(this,Category.COST_OMR_WATER, usageEscalation.escalate(winterUsage*winterUsageUnitCost,date),
			 getMonetaryUnits(),date);
      analysis.addAmount(this,Category.COST_OMR_WATERDISPOSAL,
			 disposalEscalation.escalate(summerDisposal*summerDisposalUnitCost,date),
			 getMonetaryUnits(),date);
      analysis.addAmount(this,Category.COST_OMR_WATERDISPOSAL,
			 disposalEscalation.escalate(winterDisposal*winterDisposalUnitCost,date),
			 getMonetaryUnits(),date);
      date = next;
    }
  }
}
