package blcc.model;

import blcc.util.Date;
import blcc.util.DateDiff;
import blcc.util.Units;
import blcc.util.Choosable;
import blcc.parser.XMLParser;
import blcc.parser.XMLFormatter;
import blcc.analysis.Analysis;
import blcc.analysis.Category;
import java.text.ParseException;

/** NonRecurringCost represents a cost to be incurred at some future date within
		the study period.  It occurs only once. */

public class NonRecurringCost extends ModelElement implements Choosable {
  double amount = 0.0;
  Category category = Category.COST_OMR_NONRECURRING;

  public NonRecurringCost(){
    setEscalation(new SimpleEscalation(0.0)); }

  /** Get the amount for this (non-recurring) cost. **/
  public double getAmount() {
    return amount; }

  /** Set the amount for this (non-recurring) cost.
    * The default is 0.0. */
  public void setAmount(double amount) {
    this.amount = amount; }

  public Category defaultCategory(){
    return Category.COST_OMR_NONRECURRING; }

  /** Get the category for costs that this cost incurs. */
  public Category getCategory(){
    return category; }

  /** Set the category for costs that this cost incurs. */
  public void setCategory(Category category){
    this.category = category; }

  public NonRecurringCost copyNonRecurringCost(){
    NonRecurringCost newNC = new NonRecurringCost();
    newNC.setName("Copy of: " + getName());
    newNC.setComment(getComment());
    newNC.setStart(getStart());
    newNC.setAmount(getAmount());
    newNC.setEscalation(((SimpleEscalation)getEscalation()).copySimpleEscalation());
    newNC.setCategory(getCategory());
    return newNC;}

  public String getPrettyName(){
    return (name.equals("") ? "Unnamed Cost" : name); }



  /* ______________________________________________________________________
     IO */
  public void parseXMLFields(XMLParser p) throws ParseException {
    setName(p.parseString(this,"Name",""));
    setComment(p.parseString(this,"Comment",""));
    setStart(p.parseDateDiff(this,"Start",null));
    setAmount(p.parseDouble(this,"Amount",0.0));
    setEscalation((Escalation)p.parse(this,"Escalation",escalation));
    setCategory((Category)p.parseChoice(this,"Category",
				  Category.allCategories(),defaultCategory()));
  }

  public void formatXMLFields(XMLFormatter fmt, int level){
    fmt.formatString(level,"Name",getName(),"");
    fmt.formatString(level,"Comment",getComment(),"");
    fmt.formatDateDiff(level,"Start",getStart(),defaultStart());
    fmt.formatDouble(level,"Amount",getAmount(),0.0);
    fmt.formatElement(level,"Escalation",getEscalation(),null);
    fmt.formatChoice(level,"Category",getCategory(),defaultCategory());
  }
  /* ______________________________________________________________________
     Validation */
  public void validate(boolean recursive) throws ValidationException {
    Project p = getProject();
    //if(!getStartDate().between(p.getBaseDate(),p.getEndDate()))
      //throw new ValidationException("Start is not in Study Period.",this,"Start");
    if (escalation != null) escalation.validate(recursive);
  }

  /* ______________________________________________________________________
     Analysis */

  /** Return a CashFlow representing the costs incurred by this Cost. */
  public void analyze(Analysis analysis) {
    Date date = getStartDate();
    analysis.addAmount(this,category,
		       getEscalation().escalate(amount,date),
		       getMonetaryUnits(),date);
  }
}
