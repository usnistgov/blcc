package blcc.model;

import blcc.util.Date;
import blcc.util.DateDiff;

/** 	*/
public class VaryingEscalation extends Varying implements Escalation {

  public VaryingEscalation(){}

  public Date defaultStartDate(){
    return getProject().getBaseDate(); }

  static public VaryingEscalation createVaryingEscalation(double realrate){
    VaryingEscalation esc = new VaryingEscalation();
    esc.setRealRate(0,realrate);
    return esc;   }

  public VaryingEscalation copy(){
    VaryingEscalation esc = new VaryingEscalation();
		copyInto(esc);
    return esc; }

  public double escalate(double amount, Date when){
    Date b = getBaseDate();
    double f = amount*factor(b, when);
    double i=getEffectiveInflation();
      return (i == 0.0 ? f : f*Math.pow(1+i,DateDiff.diffInYears(b,when))); }

  /** Get the nominal escalation rate for the i-th period. */
  public double getValue(int i){
		return (1.0+super.getValue(i))*(1.0+getEffectiveInflation()) - 1.0; }

  /** Set the nominal escalation rate for the i-th period. */
  public void setValue(int i, double v){
    super.setValue(i, (1.0+v)/(1.0+getEffectiveInflation()) - 1.0); }

  public double getRealRate(int i){
    return super.getValue(i); }

  public void setRealRate(int i, double v){
    super.setValue(i, v); }

  /* Disabled Stubs. */
  public void setEscalation(Escalation escalation) {}
  public Escalation getEscalation(){ return this; }
}
